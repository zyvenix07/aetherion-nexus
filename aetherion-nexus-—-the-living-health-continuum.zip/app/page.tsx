'use client';

import React, {useEffect, useState} from 'react';
import {motion, AnimatePresence} from 'motion/react';
import {PageView, CAMPUS_ZONES} from '@/lib/aetherion-data';
import EntryAnimationOverlay from '@/components/EntryAnimationOverlay';
import HeroBioSculpture3D from '@/components/HeroBioSculpture3D';
import HospitalDigitalTwin3D from '@/components/HospitalDigitalTwin3D';
import RegenerativeCareSimulator3D from '@/components/RegenerativeCareSimulator3D';
import PredictiveTrajectorySection from '@/components/PredictiveTrajectorySection';
import SpecialistSwarmSection from '@/components/SpecialistSwarmSection';
import SovereignHealthRecordSection from '@/components/SovereignHealthRecordSection';
import PatientStoriesAndTrustSection from '@/components/PatientStoriesAndTrustSection';
import {
  BookingAndTriageModal,
  ZeroUIAccessibilityOverlay,
} from '@/components/BookingAndAccessibilityModals';
import {
  ArrowRight,
  Building2,
  Calendar,
  Compass,
  Dna,
  HeartHandshake,
  KeyRound,
  PhoneCall,
  ShieldCheck,
  Sparkles,
  Stethoscope,
  TrendingUp,
  Users,
  Video,
  Volume2,
} from 'lucide-react';

export default function AetherionNexusApp() {
  const [entryCompleted, setEntryCompleted] = useState<boolean>(false);
  const [activePage, setActivePage] = useState<PageView>('overview');
  const [calmMode, setCalmMode] = useState<boolean>(false);
  const [stressDetectedBanner, setStressDetectedBanner] =
    useState<boolean>(false);
  const [zeroUiOpen, setZeroUiOpen] = useState<boolean>(false);

  // Booking / Virtual Visit / Emergency Modal state
  const [bookingModal, setBookingModal] = useState<{
    isOpen: boolean;
    mode: 'appointment' | 'virtual' | 'emergency';
    context?: string;
  }>({
    isOpen: false,
    mode: 'appointment',
  });

  // Keyboard shortcut Alt + A for Zero-UI Extreme Accessibility Mode
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.altKey && e.key.toLowerCase() === 'a') {
        e.preventDefault();
        setZeroUiOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Emotion-Aware Adaptive Interface: detect rapid scroll velocity burst
  useEffect(() => {
    let lastScrollY = window.scrollY;
    let lastTime = Date.now();
    let rapidCount = 0;

    const handleScroll = () => {
      const now = Date.now();
      const dt = now - lastTime;
      if (dt > 40) {
        const dy = Math.abs(window.scrollY - lastScrollY);
        const velocity = dy / dt;
        if (velocity > 4.2) {
          rapidCount += 1;
          if (rapidCount >= 4 && !calmMode) {
            setStressDetectedBanner(true);
          }
        } else {
          rapidCount = Math.max(0, rapidCount - 1);
        }
        lastScrollY = window.scrollY;
        lastTime = now;
      }
    };

    window.addEventListener('scroll', handleScroll, {passive: true});
    return () => window.removeEventListener('scroll', handleScroll);
  }, [calmMode]);

  const navigateToPage = (page: PageView) => {
    setActivePage(page);
    if (typeof window !== 'undefined') {
      window.scrollTo({top: 0, behavior: 'smooth'});
    }
  };

  const openBooking = (
    mode: 'appointment' | 'virtual' | 'emergency',
    context?: string
  ) => {
    setBookingModal({isOpen: true, mode, context});
  };

  return (
    <div
      className={`min-h-screen flex flex-col transition-colors duration-300 ${
        calmMode ? 'bg-[#F8FAFC] leading-relaxed' : 'bg-[#F8FAFC]'
      }`}
    >
      {/* Skip Link for Screen Readers & Keyboard Users */}
      <a
        href="#main-continuum-content"
        className="sr-only focus:not-sr-only focus:fixed focus:top-3 focus:left-3 focus:z-50 focus:px-4 focus:py-2 focus:rounded-lg focus:bg-[#0F766E] focus:text-white focus:text-xs focus:font-semibold"
      >
        Skip to main content
      </a>

      {/* Cinematic Entry Animation Overlay */}
      <EntryAnimationOverlay onComplete={() => setEntryCompleted(true)} />

      {/* =====================================================================
          SECTION 1: STICKY HEADER (Strict 3-Zone Top Bar Contract)
         ===================================================================== */}
      <header className="sticky top-0 z-40 bg-[#F8FAFC]/95 border-b border-slate-200/90 px-4 sm:px-8 py-4">
        <div className="max-w-[1360px] mx-auto flex items-center justify-between gap-8">
          {/* Zone 1: Brand Wordmark (Single clean text element) */}
          <button
            type="button"
            onClick={() => navigateToPage('overview')}
            className="text-lg sm:text-xl font-bold tracking-tight text-[#0F172A] whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-[#0F766E]"
          >
            Aetherion Nexus
          </button>

          {/* Zone 2: 5 Concise Single-Line Navigation Links */}
          <nav
            aria-label="Primary Navigation"
            className="hidden md:flex items-center gap-7 text-sm font-medium text-slate-600"
          >
            {(
              [
                {id: 'overview', label: 'Continuum'},
                {id: 'digital-twin', label: 'Digital Twin 3D'},
                {id: 'specialists', label: 'Specialists'},
                {id: 'regenerative', label: 'Regenerative 3D'},
                {id: 'sovereign-portal', label: 'Patients'},
              ] as {id: PageView; label: string}[]
            ).map((item) => {
              const isCurrent = activePage === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => navigateToPage(item.id)}
                  className={`whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors cursor-pointer ${
                    isCurrent
                      ? 'border-[#0F766E] text-[#0F172A] font-semibold'
                      : 'border-transparent hover:text-[#0F172A] hover:border-slate-300'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: 1 Primary Action Button */}
          <div className="flex items-center shrink-0">
            <button
              type="button"
              onClick={() => openBooking('appointment')}
              className="px-4 py-2 rounded-lg bg-[#0F766E] hover:bg-[#0D9488] text-white text-xs sm:text-sm font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0F766E]"
            >
              Book Care
            </button>
          </div>
        </div>
      </header>

      {/* =====================================================================
          ADAPTIVE CONTINUUM BAR (Page Switcher, Calm Mode, Virtual Visit & Zero-UI)
         ===================================================================== */}
      <div className="bg-[#F1F5F9] border-b border-slate-200/80 px-4 sm:px-8 py-2.5">
        <div className="max-w-[1360px] mx-auto flex flex-wrap items-center justify-between gap-3 text-xs">
          {/* Interactive Page / Feature View Tabs */}
          <div className="flex items-center gap-1 overflow-x-auto py-0.5">
            <span className="text-slate-500 font-medium mr-1.5 whitespace-nowrap shrink-0">
              Interactive Views:
            </span>
            {(
              [
                {id: 'overview', label: 'All Sections'},
                {id: 'digital-twin', label: '3D Hospital & Interior'},
                {id: 'regenerative', label: '3D Molecular Lab'},
                {id: 'trajectory', label: '12-Mo Trajectory'},
                {id: 'specialists', label: 'Swarm & Doctors'},
                {id: 'sovereign-portal', label: 'Sovereign Key'},
              ] as {id: PageView; label: string}[]
            ).map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => navigateToPage(tab.id)}
                className={`px-2.5 py-1 rounded-md font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  activePage === tab.id
                    ? 'bg-white text-[#0F766E] shadow-xs font-semibold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Right Controls: Emotion-Aware Calm Mode, Virtual Visit, Zero-UI Accessibility */}
          <div className="flex items-center gap-2 ml-auto">
            <button
              type="button"
              onClick={() => openBooking('virtual')}
              className="px-2.5 py-1 rounded-md bg-white border border-slate-200/90 text-slate-700 hover:text-[#0F766E] font-medium inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Video className="w-3.5 h-3.5 text-[#0F766E]" />
              <span>Virtual Visit</span>
            </button>

            <button
              type="button"
              role="switch"
              aria-checked={calmMode}
              onClick={() => {
                setCalmMode((c) => !c);
                setStressDetectedBanner(false);
              }}
              className={`px-2.5 py-1 rounded-md border font-medium inline-flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                calmMode
                  ? 'bg-[#0F766E] border-[#0F766E] text-white'
                  : 'bg-white border-slate-200/90 text-slate-700 hover:text-[#0F766E]'
              }`}
              title="Emotion-Aware Adaptive Interface: Softens clinical language and expands breathing room"
            >
              <HeartHandshake className="w-3.5 h-3.5" />
              <span>{calmMode ? 'Calm Mode: On' : 'Calm Mode'}</span>
            </button>

            <button
              type="button"
              onClick={() => setZeroUiOpen(true)}
              className="px-2.5 py-1 rounded-md bg-slate-900 text-white hover:bg-slate-800 font-medium inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
              title="Activate Voice + High-Contrast Large-Target Mode (Alt + A)"
            >
              <Volume2 className="w-3.5 h-3.5 text-teal-300" />
              <span>Zero-UI Voice</span>
            </button>
          </div>
        </div>
      </div>

      {/* Emotion-Aware Stress Signal Prompt Banner (if rapid scrolling detected) */}
      {stressDetectedBanner && !calmMode && (
        <div className="bg-teal-950 text-white px-4 sm:px-8 py-3 border-b border-teal-800">
          <div className="max-w-[1360px] mx-auto flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2">
              <HeartHandshake className="w-4 h-4 text-teal-300 shrink-0" />
              <span>
                Looking for urgent answers? We can simplify medical terms into
                calm, plain language or connect you with a human care navigator
                right away.
              </span>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  setCalmMode(true);
                  setStressDetectedBanner(false);
                }}
                className="px-3 py-1 rounded bg-[#0D9488] hover:bg-teal-500 text-white font-semibold cursor-pointer"
              >
                Enable Calm Mode
              </button>
              <button
                type="button"
                onClick={() => setStressDetectedBanner(false)}
                className="px-2 py-1 text-slate-300 hover:text-white cursor-pointer"
              >
                Dismiss
              </button>
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          MAIN CONTENT AREA (Multi-Page Views + Full Continuum Overview)
         ===================================================================== */}
      <main
        id="main-continuum-content"
        className={`flex-1 max-w-[1360px] w-full mx-auto px-4 sm:px-8 ${
          calmMode ? 'py-10 sm:py-16 space-y-24' : 'py-8 sm:py-12 space-y-20'
        }`}
      >
        <AnimatePresence mode="wait">
          {/* =================================================================
              DEDICATED PAGE 1: FULL-PAGE 3D HOSPITAL DIGITAL TWIN & INTERIOR
             ================================================================= */}
          {activePage === 'digital-twin' && (
            <motion.div
              key="page-digital-twin"
              initial={{opacity: 0, y: 12}}
              animate={{opacity: 1, y: 0}}
              exit={{opacity: 0, y: -12}}
              transition={{duration: 0.25}}
              className="space-y-10"
            >
              <div className="flex flex-wrap items-end justify-between gap-4">
                <div>
                  <div className="text-xs font-semibold text-[#0F766E]">
                    Living Digital Twin Campus · Exterior & Interior 3D Walkthrough
                  </div>
                  <h1 className="text-3xl sm:text-5xl font-bold tracking-tight text-slate-900 mt-1">
                    {calmMode
                      ? 'Walk Through Our Sunlit Campus & Private Suites Before You Arrive'
                      : 'Interactive 3D Hospital Architecture & Clinical Suites'}
                  </h1>
                  <p className="text-sm sm:text-base text-slate-600 mt-2 max-w-3xl">
                    Select any interior room tab at the bottom of the 3D viewport
                    — or slide the <strong>Interior Cutaway</strong> control — to
                    glide inside the Biophilic Atrium, 7-Tesla Hybrid MRI &
                    Neuro-Robotics Suite, GMP Cell Therapy Bio-Foundry, and
                    Circadian Recovery Suites.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => navigateToPage('overview')}
                  className="px-4 py-2 rounded-lg border border-slate-300 text-xs font-semibold text-slate-700 hover:text-slate-900 cursor-pointer"
                >
                  ← Back to Full Continuum
                </button>
              </div>

              <HospitalDigitalTwin3D
                calmMode={calmMode}
                initialZoneId="interior-mri-robotics"
                compactMode={false}
                onBookInZone={(zoneName) =>
                  openBooking('appointment', `Campus Suite: ${zoneName}`)
                }
              />

              {/* Architectural & Interior Suite Directory Cards */}
              <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
                {CAMPUS_ZONES.map((z) => (
                  <div
                    key={z.id}
                    className="p-4 rounded-xl border border-slate-200 bg-white flex flex-col justify-between"
                  >
                    <div>
                      <div className="text-[11px] font-mono text-[#0F766E]">
                        {z.floor}
                      </div>
                      <h3 className="text-sm font-bold text-slate-900 mt-1">
                        {z.name}
                      </h3>
                      <ul className="mt-2.5 space-y-1 text-xs text-slate-600">
                        {z.highlights.map((h, i) => (
                          <li key={i}>• {h}</li>
                        ))}
                      </ul>
                    </div>
                    <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] font-mono text-slate-500">
                      <span>Occupancy: {z.occupancyPct}%</span>
                      <span>{z.airChangesPerHour} ACH</span>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          )}

          {/* =================================================================
              DEDICATED PAGE 2: FULL-PAGE 3D REGENERATIVE CARE SIMULATOR
             ================================================================= */}
          {activePage === 'regenerative' && (
            <motion.div
              key="page-regenerative"
              initial={{opacity: 0, y: 12}}
              animate={{opacity: 1, y: 0}}
              exit={{opacity: 0, y: -12}}
              transition={{duration: 0.25}}
              className="space-y-10"
            >
              <div className="flex flex-wrap items-end justify-between gap-4">
                <div>
                  <div className="text-xs font-semibold text-[#0F766E]">
                    Interactive 3D Molecular & Tissue Explainer
                  </div>
                  <h1 className="text-3xl sm:text-5xl font-bold tracking-tight text-slate-900 mt-1">
                    Regenerative & Cellular Therapy Simulator
                  </h1>
                  <p className="text-sm sm:text-base text-slate-600 mt-2 max-w-3xl">
                    Explore how autologous iPSC heart matrices, CRISPR-Cas13
                    epigenetic silencing, and 3D bio-printed neuro-vascular
                    bridges repair tissue at the cellular level.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => navigateToPage('overview')}
                  className="px-4 py-2 rounded-lg border border-slate-300 text-xs font-semibold text-slate-700 hover:text-slate-900 cursor-pointer"
                >
                  ← Back to Full Continuum
                </button>
              </div>

              <RegenerativeCareSimulator3D
                calmMode={calmMode}
                onConsultPathway={(title) =>
                  openBooking('appointment', `Regenerative Pathway: ${title}`)
                }
              />
            </motion.div>
          )}

          {/* =================================================================
              DEDICATED PAGE 3: FULL-PAGE PREDICTIVE HEALTH TRAJECTORY
             ================================================================= */}
          {activePage === 'trajectory' && (
            <motion.div
              key="page-trajectory"
              initial={{opacity: 0, y: 12}}
              animate={{opacity: 1, y: 0}}
              exit={{opacity: 0, y: -12}}
              transition={{duration: 0.25}}
              className="space-y-10"
            >
              <div className="flex flex-wrap items-end justify-between gap-4">
                <div>
                  <div className="text-xs font-semibold text-[#0F766E]">
                    Longitudinal Biomarker & Longevity Modeling
                  </div>
                  <h1 className="text-3xl sm:text-5xl font-bold tracking-tight text-slate-900 mt-1">
                    Predictive Personal Health Trajectory
                  </h1>
                </div>
                <button
                  type="button"
                  onClick={() => navigateToPage('overview')}
                  className="px-4 py-2 rounded-lg border border-slate-300 text-xs font-semibold text-slate-700 hover:text-slate-900 cursor-pointer"
                >
                  ← Back to Full Continuum
                </button>
              </div>

              <PredictiveTrajectorySection
                calmMode={calmMode}
                onScheduleAssessment={(goal) =>
                  openBooking('appointment', `Baseline Trajectory Lab: ${goal}`)
                }
              />
            </motion.div>
          )}

          {/* =================================================================
              DEDICATED PAGE 4: FULL-PAGE SPECIALIST SWARM & DIRECTORY
             ================================================================= */}
          {activePage === 'specialists' && (
            <motion.div
              key="page-specialists"
              initial={{opacity: 0, y: 12}}
              animate={{opacity: 1, y: 0}}
              exit={{opacity: 0, y: -12}}
              transition={{duration: 0.25}}
              className="space-y-10"
            >
              <div className="flex flex-wrap items-end justify-between gap-4">
                <div>
                  <div className="text-xs font-semibold text-[#0F766E]">
                    Multi-Specialist Case Conference & Provider Directory
                  </div>
                  <h1 className="text-3xl sm:text-5xl font-bold tracking-tight text-slate-900 mt-1">
                    Specialist Swarm Matching & Clinicians
                  </h1>
                </div>
                <button
                  type="button"
                  onClick={() => navigateToPage('overview')}
                  className="px-4 py-2 rounded-lg border border-slate-300 text-xs font-semibold text-slate-700 hover:text-slate-900 cursor-pointer"
                >
                  ← Back to Full Continuum
                </button>
              </div>

              <SpecialistSwarmSection
                calmMode={calmMode}
                onBookDoctor={(name, spec) =>
                  openBooking('appointment', `${name} (${spec})`)
                }
              />
            </motion.div>
          )}

          {/* =================================================================
              DEDICATED PAGE 5: FULL-PAGE SOVEREIGN HEALTH RECORD PORTAL
             ================================================================= */}
          {activePage === 'sovereign-portal' && (
            <motion.div
              key="page-sovereign"
              initial={{opacity: 0, y: 12}}
              animate={{opacity: 1, y: 0}}
              exit={{opacity: 0, y: -12}}
              transition={{duration: 0.25}}
              className="space-y-10"
            >
              <div className="flex flex-wrap items-end justify-between gap-4">
                <div>
                  <div className="text-xs font-semibold text-[#0F766E]">
                    Patient-Held Cryptographic Custody & eVisit Portal
                  </div>
                  <h1 className="text-3xl sm:text-5xl font-bold tracking-tight text-slate-900 mt-1">
                    Sovereign Health Record Layer
                  </h1>
                </div>
                <button
                  type="button"
                  onClick={() => navigateToPage('overview')}
                  className="px-4 py-2 rounded-lg border border-slate-300 text-xs font-semibold text-slate-700 hover:text-slate-900 cursor-pointer"
                >
                  ← Back to Full Continuum
                </button>
              </div>

              <SovereignHealthRecordSection calmMode={calmMode} />
            </motion.div>
          )}

          {/* =================================================================
              MASTER OVERVIEW PAGE: ALL 10 REQUIRED SECTIONS IN PDF ORDER
             ================================================================= */}
          {activePage === 'overview' && (
            <motion.div
              key="page-overview"
              initial={{opacity: 0}}
              animate={{opacity: 1}}
              exit={{opacity: 0}}
              transition={{duration: 0.25}}
              className={calmMode ? 'space-y-28' : 'space-y-24'}
            >
              {/* -------------------------------------------------------------
                  SECTION 2: HERO (Full-Viewport Feel, Calm, 3D Bio-Sculpture)
                 ------------------------------------------------------------- */}
              <section aria-labelledby="hero-heading" className="pt-2">
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-stretch">
                  {/* Left 7 Columns: Headline, Subhead, Primary + Secondary CTA */}
                  <div className="lg:col-span-7 flex flex-col justify-between py-2">
                    <div>
                      <div className="flex flex-wrap items-center gap-2 text-xs font-medium text-[#0F766E]">
                        <span>The Living Health Continuum</span>
                        <span aria-hidden="true">·</span>
                        <span>Integrated Regenerative Hospital & Research Sanctuary</span>
                      </div>

                      <h1
                        id="hero-heading"
                        className="text-4xl sm:text-5xl lg:text-[52px] font-bold tracking-tight text-[#0F172A] leading-[1.12] mt-4"
                        style={{textWrap: 'balance'}}
                      >
                        {calmMode
                          ? 'Precision Regenerative Medicine, Designed Around Human Peace.'
                          : 'Where Cellular Regeneration Meets Architectural Calm.'}
                      </h1>

                      <p className="text-base sm:text-lg text-slate-600 mt-5 max-w-2xl leading-[1.65]">
                        {calmMode
                          ? 'Whether you need a routine checkup, a team of specialists working together for a complex diagnosis, or advanced tissue repair, we guide every step in a quiet, sunlit environment.'
                          : 'Aetherion Nexus unites autologous stem-cell bio-engineering, 7-Tesla robotic diagnostics, and real-time multi-specialist case conferences under one biophilic sanctuary—with patient-held cryptographic record custody.'}
                      </p>

                      {/* Primary + Secondary CTAs */}
                      <div className="mt-8 flex flex-wrap items-center gap-3.5">
                        <button
                          type="button"
                          onClick={() => openBooking('appointment')}
                          className="px-6 py-3.5 rounded-xl bg-[#F59E0B] hover:bg-amber-400 text-slate-950 text-sm font-bold inline-flex items-center gap-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer shadow-sm"
                        >
                          <span>Book Care Appointment</span>
                          <ArrowRight className="w-4 h-4" />
                        </button>

                        <button
                          type="button"
                          onClick={() => navigateToPage('digital-twin')}
                          className="px-5 py-3.5 rounded-xl bg-[#0F766E] hover:bg-[#0D9488] text-white text-sm font-semibold inline-flex items-center gap-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                        >
                          <Building2 className="w-4 h-4" />
                          <span>Enter 3D Hospital Walkthrough</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => openBooking('virtual')}
                          className="px-4 py-3.5 rounded-xl border border-slate-300 hover:border-[#0F766E] bg-white text-slate-800 text-sm font-semibold inline-flex items-center gap-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                        >
                          <Video className="w-4 h-4 text-[#0F766E]" />
                          <span>Start Virtual eVisit</span>
                        </button>
                      </div>
                    </div>

                    {/* Subtle Trust Indicators Row (Unboxed clean metadata) */}
                    <div className="mt-10 pt-6 border-t border-slate-200/90 grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
                      <div>
                        <div className="font-mono tabular-nums font-bold text-slate-900 text-sm">
                          Joint Commission & FACT
                        </div>
                        <div className="text-slate-500 mt-0.5">
                          ISO Class 5 Cellular Therapy Accredited
                        </div>
                      </div>
                      <div>
                        <div className="font-mono tabular-nums font-bold text-[#0F766E] text-sm">
                          18-Minute Swarm Triage
                        </div>
                        <div className="text-slate-500 mt-0.5">
                          24/7 Direct Multi-Specialist Access
                        </div>
                      </div>
                      <div>
                        <div className="font-mono tabular-nums font-bold text-slate-900 text-sm">
                          4.94 / 5.0 Patient Rating
                        </div>
                        <div className="text-slate-500 mt-0.5">
                          14,800+ Verified Longitudinal Outcomes
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Right 5 Columns: Interactive 3D Abstract Medical Bio-Sculpture in Warm Atrium Frame */}
                  <div className="lg:col-span-5 rounded-2xl border border-slate-200/90 bg-gradient-to-br from-[#0F172A] via-[#134E4A] to-[#0F172A] relative overflow-hidden flex flex-col justify-between min-h-[420px]">
                    <div className="flex-1 relative">
                      <HeroBioSculpture3D />
                    </div>
                    <div className="p-4 bg-slate-950/85 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-300">
                      <span>
                        Interactive 3D Cellular Matrix · Move cursor to inspect
                      </span>
                      <button
                        type="button"
                        onClick={() => navigateToPage('regenerative')}
                        className="text-teal-300 hover:text-white font-semibold cursor-pointer"
                      >
                        Open 3D Lab →
                      </button>
                    </div>
                  </div>
                </div>
              </section>

              {/* -------------------------------------------------------------
                  SECTION 3: INTENT BAR (Four Large, Clear Action Cards)
                 ------------------------------------------------------------- */}
              <section aria-label="Primary Patient Intent Actions">
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
                  <button
                    type="button"
                    onClick={() => navigateToPage('specialists')}
                    className="text-left p-6 rounded-2xl border border-slate-200 bg-white hover:border-[#0F766E] transition-colors flex flex-col justify-between group cursor-pointer"
                  >
                    <div>
                      <div className="w-10 h-10 rounded-xl bg-teal-50 text-[#0F766E] flex items-center justify-center mb-4">
                        <Stethoscope className="w-5 h-5" />
                      </div>
                      <h2 className="text-lg font-bold text-slate-900 group-hover:text-[#0F766E] transition-colors">
                        01. Find a Specialist
                      </h2>
                      <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
                        Filter clinicians by real-time slots, spoken languages,
                        insurance, or convene a 4-doctor Specialist Swarm.
                      </p>
                    </div>
                    <div className="mt-5 pt-3 border-t border-slate-100 text-xs font-semibold text-[#0F766E] flex items-center justify-between">
                      <span>8 Senior Leads Available Today</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => openBooking('virtual')}
                    className="text-left p-6 rounded-2xl border border-slate-200 bg-white hover:border-[#0F766E] transition-colors flex flex-col justify-between group cursor-pointer"
                  >
                    <div>
                      <div className="w-10 h-10 rounded-xl bg-teal-50 text-[#0F766E] flex items-center justify-center mb-4">
                        <Video className="w-5 h-5" />
                      </div>
                      <h2 className="text-lg font-bold text-slate-900 group-hover:text-[#0F766E] transition-colors">
                        02. Start Virtual Visit
                      </h2>
                      <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
                        Instant HIPAA-sovereign video consult with seamless
                        handoff to home diagnostics or campus imaging.
                      </p>
                    </div>
                    <div className="mt-5 pt-3 border-t border-slate-100 text-xs font-semibold text-[#0F766E] flex items-center justify-between">
                      <span>Median Connection: 4 Mins</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => openBooking('emergency')}
                    className="text-left p-6 rounded-2xl border border-slate-200 bg-white hover:border-amber-500 transition-colors flex flex-col justify-between group cursor-pointer"
                  >
                    <div>
                      <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center mb-4">
                        <PhoneCall className="w-5 h-5" />
                      </div>
                      <h2 className="text-lg font-bold text-slate-900 group-hover:text-amber-700 transition-colors">
                        03. Emergency Guidance
                      </h2>
                      <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
                        Zero-waiting-room private stabilization pods with live
                        wait-time telemetry and pre-arrival ambulance sync.
                      </p>
                    </div>
                    <div className="mt-5 pt-3 border-t border-slate-100 text-xs font-mono font-bold text-amber-700 flex items-center justify-between">
                      <span>Live Triage Wait: 3 Mins</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => navigateToPage('digital-twin')}
                    className="text-left p-6 rounded-2xl border border-slate-200 bg-white hover:border-[#0F766E] transition-colors flex flex-col justify-between group cursor-pointer"
                  >
                    <div>
                      <div className="w-10 h-10 rounded-xl bg-teal-50 text-[#0F766E] flex items-center justify-center mb-4">
                        <Compass className="w-5 h-5" />
                      </div>
                      <h2 className="text-lg font-bold text-slate-900 group-hover:text-[#0F766E] transition-colors">
                        04. Explore Digital Twin
                      </h2>
                      <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
                        Walk through our 3D hospital exterior and interior
                        clinical rooms with live occupancy and AR phone handoff.
                      </p>
                    </div>
                    <div className="mt-5 pt-3 border-t border-slate-100 text-xs font-semibold text-[#0F766E] flex items-center justify-between">
                      <span>Launch 3D Campus & Rooms</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </div>
                  </button>
                </div>
              </section>

              {/* -------------------------------------------------------------
                  SECTION 4: LIVING DIGITAL TWIN CAMPUS & 3D HOSPITAL INTERIOR
                 ------------------------------------------------------------- */}
              <section aria-labelledby="digital-twin-heading">
                <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-6">
                  <div>
                    <div className="text-xs font-semibold text-[#0F766E]">
                      04. Living Digital Twin Campus · Real-Time WebGL Spatial Model
                    </div>
                    <h2
                      id="digital-twin-heading"
                      className="text-2xl sm:text-4xl font-bold tracking-tight text-slate-900 mt-1"
                    >
                      {calmMode
                        ? 'Explore Our Campus and Step Inside Every Suite Before Your Visit'
                        : 'Interactive 3D Hospital Campus & Interior Clinical Walkthrough'}
                    </h2>
                    <p className="text-sm text-slate-600 mt-1.5 max-w-3xl">
                      Click any room preset in the bottom dock or drag the{' '}
                      <strong>Interior Cutaway</strong> slider to lift the outer
                      architecture and inspect the 3D animations inside the
                      7-Tesla MRI & Robotics Suite, GMP Cell Therapy Lab,
                      Biophilic Atrium, and Recovery Sanctuary.
                    </p>
                  </div>
                </div>

                <HospitalDigitalTwin3D
                  calmMode={calmMode}
                  initialZoneId="campus-overview"
                  compactMode={true}
                  onExpandFullPage={() => navigateToPage('digital-twin')}
                  onBookInZone={(zoneName) =>
                    openBooking('appointment', `Campus Suite: ${zoneName}`)
                  }
                />
              </section>

              {/* -------------------------------------------------------------
                  SECTION 5: PREDICTIVE PERSONAL HEALTH TRAJECTORY
                 ------------------------------------------------------------- */}
              <section aria-labelledby="trajectory-heading">
                <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-6">
                  <div>
                    <div className="text-xs font-semibold text-[#0F766E]">
                      05. Longitudinal Precision · Anonymized Population Cohorts
                    </div>
                    <h2
                      id="trajectory-heading"
                      className="text-2xl sm:text-4xl font-bold tracking-tight text-slate-900 mt-1"
                    >
                      Predictive Personal Health Trajectory
                    </h2>
                  </div>
                  <button
                    type="button"
                    onClick={() => navigateToPage('trajectory')}
                    className="text-xs font-semibold text-[#0F766E] hover:text-[#0D9488] cursor-pointer"
                  >
                    Open Dedicated Trajectory View →
                  </button>
                </div>

                <PredictiveTrajectorySection
                  calmMode={calmMode}
                  onScheduleAssessment={(goal) =>
                    openBooking('appointment', `Trajectory Assessment: ${goal}`)
                  }
                />
              </section>

              {/* -------------------------------------------------------------
                  SECTION 6: SPECIALIST SWARM & FIND CARE DIRECTORY
                 ------------------------------------------------------------- */}
              <section aria-labelledby="swarm-heading">
                <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-6">
                  <div>
                    <div className="text-xs font-semibold text-[#0F766E]">
                      06. Collaborative Medicine · Zero Departmental Silos
                    </div>
                    <h2
                      id="swarm-heading"
                      className="text-2xl sm:text-4xl font-bold tracking-tight text-slate-900 mt-1"
                    >
                      Specialist Swarm & Provider Directory
                    </h2>
                  </div>
                  <button
                    type="button"
                    onClick={() => navigateToPage('specialists')}
                    className="text-xs font-semibold text-[#0F766E] hover:text-[#0D9488] cursor-pointer"
                  >
                    Open Full Provider Directory →
                  </button>
                </div>

                <SpecialistSwarmSection
                  calmMode={calmMode}
                  onBookDoctor={(name, spec) =>
                    openBooking('appointment', `${name} (${spec})`)
                  }
                />
              </section>

              {/* -------------------------------------------------------------
                  SECTION 7: REGENERATIVE & ADVANCED CARE 3D SIMULATOR
                 ------------------------------------------------------------- */}
              <section aria-labelledby="regenerative-heading">
                <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-6">
                  <div>
                    <div className="text-xs font-semibold text-[#0F766E]">
                      07. Regenerative Care Simulator · 3D Molecular & Tissue Visuals
                    </div>
                    <h2
                      id="regenerative-heading"
                      className="text-2xl sm:text-4xl font-bold tracking-tight text-slate-900 mt-1"
                    >
                      Three Featured Restorative Pathways
                    </h2>
                  </div>
                  <button
                    type="button"
                    onClick={() => navigateToPage('regenerative')}
                    className="text-xs font-semibold text-[#0F766E] hover:text-[#0D9488] cursor-pointer"
                  >
                    Open Full-Screen 3D Simulator →
                  </button>
                </div>

                <RegenerativeCareSimulator3D
                  calmMode={calmMode}
                  onConsultPathway={(title) =>
                    openBooking('appointment', `Regenerative Pathway: ${title}`)
                  }
                />
              </section>

              {/* -------------------------------------------------------------
                  SOVEREIGN HEALTH RECORD LAYER (Interactive Patient Key Vault)
                 ------------------------------------------------------------- */}
              <section aria-labelledby="sovereign-heading">
                <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-6">
                  <div>
                    <div className="text-xs font-semibold text-[#0F766E]">
                      Patient Data Autonomy · Zero-Knowledge Custody
                    </div>
                    <h2
                      id="sovereign-heading"
                      className="text-2xl sm:text-4xl font-bold tracking-tight text-slate-900 mt-1"
                    >
                      Sovereign Health Record Layer
                    </h2>
                  </div>
                  <button
                    type="button"
                    onClick={() => navigateToPage('sovereign-portal')}
                    className="text-xs font-semibold text-[#0F766E] hover:text-[#0D9488] cursor-pointer"
                  >
                    Open Dedicated Vault Page →
                  </button>
                </div>

                <SovereignHealthRecordSection calmMode={calmMode} />
              </section>

              {/* -------------------------------------------------------------
                  SECTIONS 8 & 9: PATIENT STORIES + TRUST & NUMBERS
                 ------------------------------------------------------------- */}
              <section aria-label="Patient Outcomes and Institutional Trust">
                <PatientStoriesAndTrustSection
                  calmMode={calmMode}
                  onExplorePathway={() => navigateToPage('regenerative')}
                />
              </section>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* =====================================================================
          SECTION 10: COMPREHENSIVE MULTI-COLUMN FOOTER
         ===================================================================== */}
      <footer className="bg-[#0F172A] text-slate-300 border-t border-slate-800 mt-20">
        <div className="max-w-[1360px] mx-auto px-4 sm:px-8 py-14">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-slate-800">
            {/* Column 1: Brand & Emergency Numbers */}
            <div className="lg:col-span-2 space-y-3">
              <div className="text-xl font-bold text-white tracking-tight">
                Aetherion Nexus
              </div>
              <p className="text-xs text-slate-400 max-w-sm leading-relaxed">
                The Living Health Continuum. Integrated academic hospital,
                ISO Class 5 autologous regenerative bio-foundry, and biophilic
                healing campus.
              </p>
              <div className="pt-2 space-y-1 text-xs">
                <div>
                  <span className="text-slate-400">24/7 Emergency & Trauma: </span>
                  <a
                    href="tel:911"
                    className="font-mono font-bold text-amber-400 hover:underline"
                  >
                    911
                  </a>{' '}
                  or{' '}
                  <a
                    href="tel:+18005552384"
                    className="font-mono font-bold text-teal-300 hover:underline"
                  >
                    1-800-555-AETH (2384)
                  </a>
                </div>
                <div className="text-slate-400">
                  Main Sanctuary Campus: 400 Aetherion Way · Subterranean EV
                  Arrival & Helipad
                </div>
              </div>
            </div>

            {/* Column 2: Clinical & 3D Views */}
            <div className="space-y-2.5 text-xs">
              <div className="font-semibold text-white">
                Continuum & 3D Views
              </div>
              <ul className="space-y-2 text-slate-400">
                <li>
                  <button
                    type="button"
                    onClick={() => navigateToPage('digital-twin')}
                    className="hover:text-white cursor-pointer"
                  >
                    Living Digital Twin Campus (3D)
                  </button>
                </li>
                <li>
                  <button
                    type="button"
                    onClick={() => navigateToPage('regenerative')}
                    className="hover:text-white cursor-pointer"
                  >
                    Regenerative Care 3D Simulator
                  </button>
                </li>
                <li>
                  <button
                    type="button"
                    onClick={() => navigateToPage('trajectory')}
                    className="hover:text-white cursor-pointer"
                  >
                    12-Month Predictive Trajectory
                  </button>
                </li>
                <li>
                  <button
                    type="button"
                    onClick={() => navigateToPage('specialists')}
                    className="hover:text-white cursor-pointer"
                  >
                    Specialist Swarm Matching
                  </button>
                </li>
              </ul>
            </div>

            {/* Column 3: Patient Resources */}
            <div className="space-y-2.5 text-xs">
              <div className="font-semibold text-white">
                Patients & Custody
              </div>
              <ul className="space-y-2 text-slate-400">
                <li>
                  <button
                    type="button"
                    onClick={() => navigateToPage('sovereign-portal')}
                    className="hover:text-white cursor-pointer"
                  >
                    Sovereign Health Record Key
                  </button>
                </li>
                <li>
                  <button
                    type="button"
                    onClick={() => openBooking('virtual')}
                    className="hover:text-white cursor-pointer"
                  >
                    Start Telemedicine / eVisit
                  </button>
                </li>
                <li>
                  <button
                    type="button"
                    onClick={() => openBooking('appointment')}
                    className="hover:text-white cursor-pointer"
                  >
                    Transparent Billing & Insurance
                  </button>
                </li>
                <li>
                  <button
                    type="button"
                    onClick={() => setCalmMode((c) => !c)}
                    className="hover:text-white cursor-pointer"
                  >
                    Toggle Emotion-Aware Calm Mode
                  </button>
                </li>
              </ul>
            </div>

            {/* Column 4: Accessibility & Language */}
            <div className="space-y-2.5 text-xs">
              <div className="font-semibold text-white">
                Accessibility & Governance
              </div>
              <p className="text-slate-400 leading-relaxed">
                Engineered to WCAG 2.2 AA/AAA standards with keyboard navigation,
                reduced-motion respect, and Zero-UI voice control.
              </p>
              <button
                type="button"
                onClick={() => setZeroUiOpen(true)}
                className="px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-teal-300 font-semibold inline-flex items-center gap-1.5 cursor-pointer"
              >
                <Volume2 className="w-3.5 h-3.5" />
                <span>Launch Zero-UI Mode (Alt+A)</span>
              </button>
            </div>
          </div>

          <div className="pt-6 flex flex-wrap items-center justify-between gap-4 text-xs text-slate-400">
            <div>
              © 2026 Aetherion Nexus Health System. All clinical projections are
              educational and subject to physician consultation.
            </div>
            <div className="flex items-center gap-4">
              <span>HIPAA Sovereign Compliant</span>
              <span>·</span>
              <span>Zero Third-Party Tracking</span>
              <span>·</span>
              <span>English / Español / Français / 日本語 / हिन्दी</span>
            </div>
          </div>
        </div>
      </footer>

      {/* Interactive Modals */}
      <BookingAndTriageModal
        isOpen={bookingModal.isOpen}
        initialMode={bookingModal.mode}
        prefilledContext={bookingModal.context}
        onClose={() => setBookingModal((prev) => ({...prev, isOpen: false}))}
      />

      <ZeroUIAccessibilityOverlay
        active={zeroUiOpen}
        onClose={() => setZeroUiOpen(false)}
        onNavigatePage={navigateToPage}
        onOpenBooking={(mode) => openBooking(mode)}
      />
    </div>
  );
}
