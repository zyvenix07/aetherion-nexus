import type {Metadata} from 'next';
import {Plus_Jakarta_Sans, IBM_Plex_Mono} from 'next/font/google';
import './globals.css';

const plusJakarta = Plus_Jakarta_Sans({
  subsets: ['latin'],
  weight: ['400', '500', '600', '700'],
  variable: '--font-sans',
  display: 'swap',
});

const ibmPlexMono = IBM_Plex_Mono({
  subsets: ['latin'],
  weight: ['400', '500', '600'],
  variable: '--font-mono',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'Aetherion Nexus — The Living Health Continuum',
  description:
    'Next-generation integrated hospital and regenerative health continuum with interactive 3D Digital Twin campus, interior clinical suites, predictive health trajectory, and specialist swarm matching.',
  openGraph: {
    title: 'Aetherion Nexus — The Living Health Continuum',
    description:
      'Next-generation integrated hospital and regenerative health continuum with interactive 3D Digital Twin campus, interior clinical suites, predictive health trajectory, and specialist swarm matching.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Aetherion Nexus — The Living Health Continuum',
    description:
      'Next-generation integrated hospital and regenerative health continuum with interactive 3D Digital Twin campus, interior clinical suites, predictive health trajectory, and specialist swarm matching.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en" className={`${plusJakarta.variable} ${ibmPlexMono.variable}`}>
      <body
        suppressHydrationWarning
        className="bg-[#F8FAFC] text-[#0F172A] antialiased selection:bg-[#0F766E]/15 selection:text-[#0F766E]"
        style={{fontFamily: 'var(--font-sans), system-ui, sans-serif'}}
      >
        {children}
      </body>
    </html>
  );
}
