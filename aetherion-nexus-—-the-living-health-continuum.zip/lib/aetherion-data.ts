export type PageView =
  | 'overview'
  | 'digital-twin'
  | 'specialists'
  | 'regenerative'
  | 'trajectory'
  | 'sovereign-portal';

export interface CampusZone {
  id: string;
  name: string;
  shortName: string;
  category: 'exterior-wing' | 'interior-suite';
  floor: string;
  occupancyPct: number;
  waitMinutes: number;
  airChangesPerHour: number;
  arBeaconCode: string;
  parkingZone: string;
  standardSummary: string;
  calmSummary: string;
  highlights: string[];
  cameraPos: [number, number, number];
  cameraTarget: [number, number, number];
}

export const CAMPUS_ZONES: CampusZone[] = [
  {
    id: 'campus-overview',
    name: 'Aetherion Integrated Campus & Biophilic Sanctuary',
    shortName: 'Full Campus 3D',
    category: 'exterior-wing',
    floor: 'All Levels (L1–L8)',
    occupancyPct: 48,
    waitMinutes: 4,
    airChangesPerHour: 18,
    arBeaconCode: 'AETH-NORTH-01',
    parkingZone: 'West Subterranean EV Deck (142 spaces open)',
    standardSummary:
      'Four interconnected timber-and-glass clinical pavilions surrounding a central botanical recovery courtyard with dedicated helipad and subterranean transit hub.',
    calmSummary:
      'A quiet, sunlit campus designed around nature and easy wayfinding. Valet and gentle mobility assistance greet you at every entrance.',
    highlights: [
      'Zero-threshold arrival with automated license-plate check-in',
      '100% circadian daylight harvesting across patient wings',
      'Direct skybridge links between Diagnostics and Regenerative Suites',
    ],
    cameraPos: [26, 20, 28],
    cameraTarget: [0, 2, 0],
  },
  {
    id: 'interior-atrium',
    name: 'Biophilic Grand Atrium & Concierge Lounge',
    shortName: 'Interior: Atrium',
    category: 'interior-suite',
    floor: 'Level 1 · Ground Concourse',
    occupancyPct: 36,
    waitMinutes: 2,
    airChangesPerHour: 22,
    arBeaconCode: 'ATR-CONCOURSE-1A',
    parkingZone: 'South Drop-Off Canopy (Direct elevator)',
    standardSummary:
      'Double-height timber atrium featuring indoor olive trees, acoustic limestone baffles, biometric self-check kiosks, and human care navigators.',
    calmSummary:
      'Our main welcome garden indoors. Sit beside living trees and natural water acoustics while a personal guide brings your check-in tablet to you.',
    highlights: [
      'Sound-absorbing limestone architecture (< 42 dBA ambient noise)',
      'Live AR indoor navigation handoff to personal smartphones',
      'Private family consultation alcoves with herbal hydration bar',
    ],
    cameraPos: [0, 3.8, 11.5],
    cameraTarget: [0, 2.2, 0],
  },
  {
    id: 'interior-mri-robotics',
    name: '7-Tesla Hybrid MRI & Neuro-Robotic Suite',
    shortName: 'Interior: MRI & Robotics',
    category: 'interior-suite',
    floor: 'Level 3 · Diagnostic & Surgical Wing',
    occupancyPct: 62,
    waitMinutes: 8,
    airChangesPerHour: 32,
    arBeaconCode: 'DIAG-7TMRI-3B',
    parkingZone: 'East Clinical Deck Level P2',
    standardSummary:
      'Ultra-high-field 7T functional magnetic resonance imaging paired with dual-arm micro-surgical robotics and real-time holographic perfusion displays.',
    calmSummary:
      'A softly lit, wide-bore imaging room with soothing sky projections and quiet acoustic shielding so your scan feels calm, spacious, and unhurried.',
    highlights: [
      'Wide-bore 80cm ambient-lit magnet with 65% acoustic noise reduction',
      'Sub-millimeter robotic catheter and neuro-navigation precision',
      'Real-time radiologist co-review before you leave the suite',
    ],
    cameraPos: [-8.5, 4.2, 7.5],
    cameraTarget: [-8.5, 2.0, 0],
  },
  {
    id: 'interior-cell-lab',
    name: 'Autologous GMP Cell & Tissue Bio-Foundry',
    shortName: 'Interior: Cell Therapy Lab',
    category: 'interior-suite',
    floor: 'Level 5 · Regenerative Tower',
    occupancyPct: 54,
    waitMinutes: 0,
    airChangesPerHour: 45,
    arBeaconCode: 'REGEN-GMP-5C',
    parkingZone: 'North Tower Elevator Core',
    standardSummary:
      'ISO Class 5 cleanroom bioreactors and automated microfluidic cell sorters cultivating patient-specific iPSC scaffolds and targeted CAR-T/NK therapies.',
    calmSummary:
      'A glass-walled laboratory where your own healthy cells are gently nurtured and prepared for restorative therapy, visible from the family viewing gallery.',
    highlights: [
      'Closed-loop perfusion bioreactors with continuous optical quality telemetry',
      'Chain-of-custody cryptographic barcoding tied to your Sovereign Key',
      'Adjacent infusion suites eliminating cryo-transport delays',
    ],
    cameraPos: [8.5, 4.2, 7.5],
    cameraTarget: [8.5, 2.0, 0],
  },
  {
    id: 'interior-recovery-suite',
    name: 'Circadian Biophilic Patient Sanctuary Suite',
    shortName: 'Interior: Patient Suite',
    category: 'interior-suite',
    floor: 'Level 6 · East Healing Pavilion',
    occupancyPct: 71,
    waitMinutes: 0,
    airChangesPerHour: 24,
    arBeaconCode: 'HEAL-SUITE-604',
    parkingZone: 'East Garden Valet',
    standardSummary:
      'Private inpatient recovery room with contactless radar vitals sensing, circadian sky-ceiling LED matrix, hidden medical gases, and private terrace.',
    calmSummary:
      'Your private recovery room looks and feels like a quiet timber studio—no loud beeping monitors, warm natural bedding, and a sofa bed for loved ones.',
    highlights: [
      'Zero-alarm contactless millimeter-wave heart & respiratory monitoring',
      'Dynamic spectral lighting tuned to accelerate melatonin & tissue repair',
      'Direct acoustic link to your dedicated primary nurse within 15 seconds',
    ],
    cameraPos: [0, 4.5, -9.5],
    cameraTarget: [0, 2.0, -3.5],
  },
];

export interface Physician {
  id: string;
  name: string;
  credentials: string;
  specialty: string;
  subspecialty: string;
  languages: string[];
  nextAvailable: string;
  videoReady: boolean;
  insurances: string[];
  experienceYears: number;
  clinicalFocus: string;
  calmBio: string;
  swarmRole: string;
  avatarHue: string;
  publicationsCount: number;
}

export const PHYSICIANS: Physician[] = [
  {
    id: 'dr-elena-vance',
    name: 'Dr. Elena Rostova-Vance',
    credentials: 'MD, PhD',
    specialty: 'Regenerative Cardiology',
    subspecialty: 'Autologous Myocardial Tissue Engineering',
    languages: ['English', 'Spanish', 'Russian'],
    nextAvailable: 'Today · 2:30 PM',
    videoReady: true,
    insurances: ['Aetna', 'BlueCross', 'Medicare', 'UnitedHealthcare'],
    experienceYears: 18,
    clinicalFocus:
      'Leads Phase III clinical trials in iPSC-derived cardiomyocyte patches for post-ischemic heart failure without open sternotomy.',
    calmBio:
      'Helps strengthen your heart muscle naturally using your own restorative cells, explaining every step with warmth and clarity.',
    swarmRole: 'Lead Hemodynamic & Cellular Strategist',
    avatarHue: '#0F766E',
    publicationsCount: 84,
  },
  {
    id: 'dr-marcus-thorne',
    name: 'Dr. Marcus Thorne',
    credentials: 'MD, FACS',
    specialty: 'Neuro-Restorative Surgery',
    subspecialty: 'Bionic & Peripheral Nerve Micro-Reconstruction',
    languages: ['English', 'French'],
    nextAvailable: 'Tomorrow · 9:15 AM',
    videoReady: true,
    insurances: ['BlueCross', 'Cigna', 'Medicare', 'Aetherion Direct'],
    experienceYears: 21,
    clinicalFocus:
      'Pioneered minimally invasive bio-printed neuro-vascular conduits and adaptive brain-spinal interfaces for motor recovery.',
    calmBio:
      'Specializes in gentle micro-procedures and guided physical rehabilitation to restore movement and comfort after nerve injury.',
    swarmRole: 'Micro-Surgical & Neuro-Plasticity Lead',
    avatarHue: '#0D9488',
    publicationsCount: 112,
  },
  {
    id: 'dr-amara-okafor',
    name: 'Dr. Amara Okafor',
    credentials: 'MD, MPH',
    specialty: 'Precision Oncology & Immunogenetics',
    subspecialty: 'Liquid Biopsy & Neoantigen Cell Therapy',
    languages: ['English', 'Igbo', 'French'],
    nextAvailable: 'Today · 4:00 PM',
    videoReady: true,
    insurances: ['Aetna', 'Cigna', 'UnitedHealthcare', 'Medicare'],
    experienceYears: 15,
    clinicalFocus:
      'Designs bespoke TIL and mRNA immunotherapies guided by whole-exome sequencing and circulating tumor DNA kinetics.',
    calmBio:
      'Tailors gentle, targeted immune therapies specifically to your body’s unique genetics, minimizing side effects and hospital stays.',
    swarmRole: 'Genomic & Immunotherapy Architect',
    avatarHue: '#115E59',
    publicationsCount: 69,
  },
  {
    id: 'dr-kenji-takahashi',
    name: 'Dr. Kenji Takahashi',
    credentials: 'MD, PhD',
    specialty: 'Metabolic & Epigenetic Longevity',
    subspecialty: 'Mitochondrial Bioenergetics & Preventive Medicine',
    languages: ['English', 'Japanese'],
    nextAvailable: 'Thu · 10:30 AM',
    videoReady: true,
    insurances: ['BlueCross', 'UnitedHealthcare', 'Aetherion Direct'],
    experienceYears: 14,
    clinicalFocus:
      'Integrates continuous multi-omic biomarkers, VO2 max cardiopulmonary remodeling, and targeted senolytics to compress morbidity.',
    calmBio:
      'Partners with you to build sustainable energy, restorative sleep, and long-term vitality through simple daily habits and precise diagnostics.',
    swarmRole: 'Systemic Metabolic & Biomarker Lead',
    avatarHue: '#0F766E',
    publicationsCount: 53,
  },
  {
    id: 'dr-sofia-mendez',
    name: 'Dr. Sofia Alvarez-Mendez',
    credentials: 'MD',
    specialty: 'Autoimmune & Musculoskeletal Regeneration',
    subspecialty: 'Orthobiologics & Cartilage Matrix Synthesis',
    languages: ['English', 'Spanish', 'Portuguese'],
    nextAvailable: 'Today · 5:15 PM',
    videoReady: true,
    insurances: ['Aetna', 'BlueCross', 'Cigna', 'Medicare'],
    experienceYears: 12,
    clinicalFocus:
      'Restores articular cartilage and modulates refractory synovial inflammation using targeted mesenchymal secretome protocols.',
    calmBio:
      'Helps relieve joint pain and restore smooth, comfortable movement without major joint replacement surgery whenever possible.',
    swarmRole: 'Immunomodulation & Matrix Specialist',
    avatarHue: '#0D9488',
    publicationsCount: 41,
  },
  {
    id: 'dr-devon-brooks',
    name: 'Dr. Devon Brooks',
    credentials: 'MD, FACEP',
    specialty: 'Acute Care & Hybrid Trauma Navigation',
    subspecialty: 'Point-of-Care Perfusion & Rapid Stabilization',
    languages: ['English', 'ASL'],
    nextAvailable: 'Immediate · 24/7 Triage',
    videoReady: true,
    insurances: ['Aetna', 'BlueCross', 'Cigna', 'UnitedHealthcare', 'Medicare'],
    experienceYears: 16,
    clinicalFocus:
      'Directs Aetherion’s zero-wait emergency stabilization pods with pre-arrival ambulance telemetry and instant specialist swarm activation.',
    calmBio:
      'Provides immediate, reassuring urgent care with zero waiting room stress—connecting you directly to a quiet private stabilization suite.',
    swarmRole: 'Acute Triage & Rapid Diagnostic Coordinator',
    avatarHue: '#134E4A',
    publicationsCount: 37,
  },
  {
    id: 'dr-linnea-lindqvist',
    name: 'Dr. Linnea Lindqvist',
    credentials: 'MD, PhD',
    specialty: 'Maternal-Fetal & Perinatal Genomics',
    subspecialty: 'Non-Invasive Fetal Therapy & Placental Biology',
    languages: ['English', 'Swedish', 'German'],
    nextAvailable: 'Fri · 11:00 AM',
    videoReady: true,
    insurances: ['Aetna', 'BlueCross', 'UnitedHealthcare'],
    experienceYears: 17,
    clinicalFocus:
      'Specializes in ultra-high-resolution fetal echocardiography and gentle in-utero cellular interventions.',
    calmBio:
      'Supports expectant parents with gentle, high-clarity imaging and compassionate team guidance for every stage of pregnancy.',
    swarmRole: 'Perinatal & Developmental Genetics Lead',
    avatarHue: '#0F766E',
    publicationsCount: 64,
  },
  {
    id: 'dr-rajiv-kulkarni',
    name: 'Dr. Rajiv Kulkarni',
    credentials: 'MD, DM',
    specialty: 'Pulmonary & Vascular Bio-Engineering',
    subspecialty: 'Alveolar Epithelial Repair & Micro-Perfusion',
    languages: ['English', 'Hindi', 'Marathi'],
    nextAvailable: 'Tomorrow · 1:45 PM',
    videoReady: true,
    insurances: ['BlueCross', 'Cigna', 'Medicare', 'UnitedHealthcare'],
    experienceYears: 19,
    clinicalFocus:
      'Focuses on reversing fibrotic lung remodeling through inhaled exosome therapeutics and microvascular rehabilitation.',
    calmBio:
      'Helps you breathe deeper and easier with targeted lung-repair therapies and personalized respiratory rehabilitation.',
    swarmRole: 'Cardiopulmonary Oxygenation Specialist',
    avatarHue: '#0D9488',
    publicationsCount: 78,
  },
];

export interface SwarmCondition {
  id: string;
  title: string;
  category: string;
  readingLevelSummary: string;
  estimatedOpinionMinutes: number;
  activeSpecialists: string[];
  protocolSteps: string[];
}

export const SWARM_CONDITIONS: SwarmCondition[] = [
  {
    id: 'myocardial-recovery',
    title: 'Post-Ischemic Heart Muscle Recovery',
    category: 'Cardiovascular & Cellular',
    readingLevelSummary:
      'When a heart attack leaves a weak spot in the heart muscle, our team works together to strengthen the tissue, balance your metabolism, and improve oxygen flow without major open-chest surgery.',
    estimatedOpinionMinutes: 18,
    activeSpecialists: [
      'dr-elena-vance',
      'dr-rajiv-kulkarni',
      'dr-kenji-takahashi',
      'dr-devon-brooks',
    ],
    protocolSteps: [
      'Simultaneous 7T Cardiac MRI + Cardiopulmonary Perfusion Review',
      'Autologous iPSC Secretome Eligibility & Bio-Scaffold Mapping',
      'Unified 12-Month Home Wearable & Rehab Plan in 1 Visit',
    ],
  },
  {
    id: 'neuro-mobility',
    title: 'Complex Nerve Injury & Motor Restoration',
    category: 'Neurology &Orthobiologics',
    readingLevelSummary:
      'For lingering numbness, weakness, or spinal/nerve injuries, our nerve surgeons, joint specialists, and rehab engineers design a single plan to reconnect nerve pathways and rebuild strength.',
    estimatedOpinionMinutes: 22,
    activeSpecialists: [
      'dr-marcus-thorne',
      'dr-sofia-mendez',
      'dr-kenji-takahashi',
    ],
    protocolSteps: [
      'High-Resolution Tractography & Nerve Conduction Mapping',
      'Bio-Printed Conduit or Targeted Neuro-Modulation Consensus',
      'Robotic Exoskeleton & Fine-Motor Studio Onboarding',
    ],
  },
  {
    id: 'autoimmune-systemic',
    title: 'Multi-System Autoimmune & Inflammatory Reset',
    category: 'Immunogenetics & Longevity',
    readingLevelSummary:
      'When your immune system is overactive and causing fatigue, joint pain, or organ stress, our genetics, immune, and metabolic doctors meet together to calm inflammation at its root.',
    estimatedOpinionMinutes: 16,
    activeSpecialists: [
      'dr-amara-okafor',
      'dr-sofia-mendez',
      'dr-kenji-takahashi',
      'dr-rajiv-kulkarni',
    ],
    protocolSteps: [
      'Single-Cell Immune Profiling & Epigenetic Methylation Assay',
      'Targeted Biologic / Secretome De-Escalation Roadmap',
      'Anti-Inflammatory Nutrition & Vagal Tone Biofeedback Sync',
    ],
  },
];

export interface RegenerativePathway {
  id: 'ipsc-cardiac' | 'crispr-epigenetic' | 'vascular-conduit';
  title: string;
  subtitle: string;
  plainLanguageSummary: string;
  clinicalIndication: string;
  recoveryTimeline: string;
  trialOutcomeMetric: string;
  stages: {
    phaseNumber: string;
    title: string;
    duration: string;
    explanation: string;
    molecularBehavior: string;
  }[];
}

export const REGENERATIVE_PATHWAYS: RegenerativePathway[] = [
  {
    id: 'ipsc-cardiac',
    title: 'Autologous iPSC Myocardial Matrix',
    subtitle: 'Cell Therapy · Self-Derived Heart Muscle Repair',
    plainLanguageSummary:
      'We take a tiny, painless skin or blood sample from your arm, guide those cells in our cleanroom to become healthy new heart muscle cells, and place a gentle dissolving patch over weakened heart tissue so it beats strongly again.',
    clinicalIndication: 'Chronic Ischemic Cardiomyopathy & Microvascular Scar',
    recoveryTimeline: 'Outpatient harvest · 2-day catheter placement · 12-week remodeling',
    trialOutcomeMetric: '+11.4% Left Ventricular Ejection Fraction at 6 Months (n=312)',
    stages: [
      {
        phaseNumber: '01',
        title: 'Autologous Cell Harvest & Reprogramming',
        duration: 'Days 1–7',
        explanation:
          'A standard blood draw isolates peripheral mononuclear cells, which are reprogrammed using non-integrating Episomal factors into pluripotent stem cells.',
        molecularBehavior: 'Pluripotent nuclei align in high-viability spherical clusters.',
      },
      {
        phaseNumber: '02',
        title: 'Cardiomyocyte Differentiation & Hydrogel Seeding',
        duration: 'Days 8–21',
        explanation:
          'Cells mature into spontaneously beating cardiomyocytes inside a collagen-fibrin scaffold matching your heart wall geometry from 7T MRI.',
        molecularBehavior: 'Synchronous contractile waves propagate across the 3D lattice.',
      },
      {
        phaseNumber: '03',
        title: 'Minimally Invasive Epicardial Deployment',
        duration: 'Day 22 (90-Min Procedure)',
        explanation:
          'Through a 2cm thoracoscopic port, our surgical robot positions the bio-patch directly over the scarred myocardium without stopping the heart.',
        molecularBehavior: 'Micro-vessels sprout between host tissue and the new cellular matrix.',
      },
      {
        phaseNumber: '04',
        title: 'Electromechanical Integration & Remodeling',
        duration: 'Weeks 4–24',
        explanation:
          'The biodegradable scaffold dissolves as the new muscle fibers synchronize electrically with your natural heartbeat, boosting pumping efficiency.',
        molecularBehavior: 'Full gap-junction coupling and mature sarcomere alignment.',
      },
    ],
  },
  {
    id: 'crispr-epigenetic',
    title: 'CRISPR-Cas13 Epigenetic Silencing',
    subtitle: 'Gene Modulation · Reversible RNA & Methylation Tuning',
    plainLanguageSummary:
      'Instead of permanently cutting your DNA, this gentle therapy acts like a dimmer switch—turning down harmful inflammatory or cholesterol signals at the RNA message level while leaving your natural genetic code intact.',
    clinicalIndication: 'Refractory Familial Hypercholesterolemia & Neuro-Inflammation',
    recoveryTimeline: 'Single 45-minute IV infusion · Zero hospital stay',
    trialOutcomeMetric: '-68% Pathogenic Transcript Expression at 12 Months (n=198)',
    stages: [
      {
        phaseNumber: '01',
        title: 'Whole-Transcriptome Target Mapping',
        duration: 'Days 1–5',
        explanation:
          'High-depth RNA sequencing identifies the exact overactive messenger RNA transcripts driving vascular or autoimmune stress.',
        molecularBehavior: 'Double-stranded helical target sites highlighted along the strand.',
      },
      {
        phaseNumber: '02',
        title: 'Lipid Nanoparticle Guide Assembly',
        duration: 'Days 6–10',
        explanation:
          'Custom guide RNAs are encapsulated in tissue-selective biodegradable lipid spheres engineered to home directly to liver or neural receptors.',
        molecularBehavior: 'Ribonucleoprotein complexes dock smoothly onto the target groove.',
      },
      {
        phaseNumber: '03',
        title: 'Precision Transcript Cleavage & Methylation',
        duration: 'Hours 1–48 Post-Infusion',
        explanation:
          'Once inside target cells, the Cas13 enzyme selectively neutralizes the faulty RNA messages without altering permanent nuclear DNA.',
        molecularBehavior: 'Harmful transcript rings dissolve while structural helix stays whole.',
      },
      {
        phaseNumber: '04',
        title: 'Homeostatic Biomarker Stabilization',
        duration: 'Months 1–12',
        explanation:
          'Inflammatory cytokines and lipid particles drop into optimal physiological ranges, verified via monthly finger-stick home telemetry.',
        molecularBehavior: 'Steady harmonic oscillation of healthy cellular transcription.',
      },
    ],
  },
  {
    id: 'vascular-conduit',
    title: 'Bio-Printed Neuro-Vascular Conduit',
    subtitle: 'Advanced Rehab · 3D Micro-Channel Nerve & Vessel Bridge',
    plainLanguageSummary:
      'Using a precision 3D bio-printer, we create a soft, living bridge lined with your own support cells. It guides damaged nerves and tiny blood vessels to grow back across a gap and restore feeling and strength.',
    clinicalIndication: 'Peripheral Nerve Gap Injuries & Diabetic Micro-Ischemia',
    recoveryTimeline: '1-day microsurgery · Guided neuro-rehab Weeks 2–16',
    trialOutcomeMetric: '89% Sensory & Fine-Motor Conduction Recovery (n=144)',
    stages: [
      {
        phaseNumber: '01',
        title: '3D Diffusion Tensor Nerve Mapping',
        duration: 'Day 1',
        explanation:
          'Ultra-high-resolution nerve imaging measures the exact diameter and fascicle bundle pattern of your healthy nerve ends.',
        molecularBehavior: 'Bifurcated tubular geometry calibrated to micron tolerances.',
      },
      {
        phaseNumber: '02',
        title: 'Multi-Nozzle Bioprinting with Schwann Cells',
        duration: 'Days 2–6',
        explanation:
          'Micro-channels of silk-fibroin and laminin hydrogel are printed and seeded with autologous Schwann and endothelial progenitor cells.',
        molecularBehavior: 'Parallel guidance lumens infused with neurotrophic growth factors.',
      },
      {
        phaseNumber: '03',
        title: 'Tension-Free Microsurgical Coaptation',
        duration: 'Day 7',
        explanation:
          'Our neuro-restorative surgeons secure the conduit using sutureless photochemical tissue bonding under 40x optical magnification.',
        molecularBehavior: 'Axonal growth cones begin migrating along the trophic gradient.',
      },
      {
        phaseNumber: '04',
        title: 'Closed-Loop Neuro-Robotic Rehabilitation',
        duration: 'Weeks 3–16',
        explanation:
          'Soft wearable EMG sensors detect early nerve signals and trigger gentle robotic assistance, accelerating brain-to-muscle rewiring.',
        molecularBehavior: 'High-velocity myelinated signal pulses travel across the bridge.',
      },
    ],
  },
];

export interface PatientStory {
  id: string;
  patientName: string;
  age: number;
  profession: string;
  location: string;
  pathwayUsed: string;
  beforeState: string;
  changeIntervention: string;
  afterOutcome: string;
  quantifiedMetric: string;
  quote: string;
  attendingPhysician: string;
  visualTheme: 'conservatory' | 'architect' | 'terrace';
}

export const PATIENT_STORIES: PatientStory[] = [
  {
    id: 'story-claire',
    patientName: 'Claire Vance-Lin',
    age: 58,
    profession: 'Botanical Archivist',
    location: 'Portland, OR',
    pathwayUsed: 'Autologous iPSC Myocardial Matrix',
    beforeState:
      'Experienced severe shortness of breath walking 100 meters after a silent LAD myocardial infarction left a 34% ejection fraction.',
    changeIntervention:
      'Underwent thoracoscopic placement of an autologous iPSC-derived cardiomyocyte patch paired with 12 weeks of circadian cardiopulmonary rehab.',
    afterOutcome:
      'Returned to full-time fieldwork in the conservatory with zero angina, normal ventricular wall motion, and unassisted 8km trail hikes.',
    quantifiedMetric: 'LVEF improved from 34% to 52% in 20 weeks',
    quote:
      'There were no cold fluorescent hallways or rushed five-minute visits. My cardiologist, lung specialist, and cell biologist sat with me together in the atrium and showed me my own cells beating before the procedure.',
    attendingPhysician: 'Dr. Elena Rostova-Vance, MD, PhD',
    visualTheme: 'conservatory',
  },
  {
    id: 'story-mateo',
    patientName: 'Mateo Salgado',
    age: 42,
    profession: 'Structural Timber Architect',
    location: 'Austin, TX',
    pathwayUsed: 'Bio-Printed Neuro-Vascular Conduit',
    beforeState:
      'Suffered a 4.2cm ulnar and median nerve crush injury in a site accident, resulting in complete loss of right-hand pinch strength and tactile sensation.',
    changeIntervention:
      'Received a custom 3D bio-printed Schwann-cell multi-lumen nerve bridge followed by EMG-guided soft robotic studio therapy.',
    afterOutcome:
      'Regained two-point tactile discrimination and 92% grip strength, returning to hand-drafting architectural joinery models within 5 months.',
    quantifiedMetric: '4.2cm nerve gap bridged · 92% grip restoration',
    quote:
      'Having the 3D simulator explain how my nerve fibers would grow millimeter by millimeter took away the fear of the unknown. Five months later, I held a fountain pen steady again.',
    attendingPhysician: 'Dr. Marcus Thorne, MD, FACS',
    visualTheme: 'architect',
  },
  {
    id: 'story-sanjay',
    patientName: 'Sanjay & Meera Deshmukh',
    age: 64,
    profession: 'Retired Aerospace Educator',
    location: 'Boston, MA',
    pathwayUsed: 'CRISPR-Cas13 Epigenetic Silencing & Swarm Care',
    beforeState:
      'Battled statin-intolerant familial hypercholesterolemia (Lp(a) > 210 nmol/L) and systemic vascular inflammation despite four daily medications.',
    changeIntervention:
      'Enrolled in Aetherion’s Specialist Swarm protocol and received a single targeted lipid-nanoparticle epigenetic RNA modulation infusion.',
    afterOutcome:
      'Lp(a) and hs-CRP normalized within 6 weeks with zero hepatic side effects; now shares encrypted longitudinal records seamlessly while traveling.',
    quantifiedMetric: '-74% Lp(a) reduction · hs-CRP < 0.6 mg/L',
    quote:
      'With the Sovereign Record Key, I finally own my medical history. When we visited our grandchildren abroad, I shared a 15-minute read-only token with a local clinic in one tap.',
    attendingPhysician: 'Dr. Amara Okafor, MD, MPH & Dr. Kenji Takahashi, MD, PhD',
    visualTheme: 'terrace',
  },
];

export interface SovereignRecordItem {
  id: string;
  title: string;
  category: string;
  dateRecorded: string;
  fileSize: string;
  hashPreview: string;
  defaultSelected: boolean;
  clinicalSummary: string;
}

export const SOVEREIGN_RECORDS: SovereignRecordItem[] = [
  {
    id: 'rec-7t-mri',
    title: '7-Tesla Cardiac & Microvascular MRI (DICOM + 3D Mesh)',
    category: 'Diagnostic Imaging',
    dateRecorded: 'Oct 12, 2026',
    fileSize: '1.42 GB (Zero-Knowledge Indexed)',
    hashPreview: '0x8F4C...92E1',
    defaultSelected: true,
    clinicalSummary:
      'Normal biventricular volumes; LVEF 58%; zero late gadolinium enhancement; intact coronary microvascular flow reserve (CFR 3.4).',
  },
  {
    id: 'rec-epigenome',
    title: 'Whole-Exome & DunedinPACE Epigenetic Methylation Panel',
    category: 'Genomics & Longevity',
    dateRecorded: 'Oct 04, 2026',
    fileSize: '480 MB',
    hashPreview: '0x3A19...7C04',
    defaultSelected: true,
    clinicalSummary:
      'Biological pace of aging 0.78 years per chronological year; zero pathogenic BRCA/LDLR variants; optimal pharmacogenomic CYP2D6 metabolizer.',
  },
  {
    id: 'rec-wearable-telemetry',
    title: '90-Day Continuous HRV, Sleep Architecture & Glycemic Stream',
    category: 'Longitudinal Telemetry',
    dateRecorded: 'Live Sync · Updated 14m ago',
    fileSize: '64 MB',
    hashPreview: '0xD20B...41FA',
    defaultSelected: false,
    clinicalSummary:
      'Mean nocturnal HRV 74 ms; deep + REM sleep 44% of total sleep time; mean 24h interstitial glucose 89 mg/dL (SD 9 mg/dL).',
  },
  {
    id: 'rec-cell-bank',
    title: 'Autologous iPSC Master Cell Bank Certificate of Analysis',
    category: 'Regenerative Bio-Vault',
    dateRecorded: 'Sep 19, 2026',
    fileSize: '18 MB',
    hashPreview: '0x91EE...6B32',
    defaultSelected: true,
    clinicalSummary:
      'Passage-3 induced pluripotent stem cell line cryo-preserved at -196°C in Vault B4; 99.4% viability; normal karyotype verified.',
  },
];
