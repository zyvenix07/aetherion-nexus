'use client';

import React, {useState} from 'react';
import {
  PHYSICIANS,
  SWARM_CONDITIONS,
  Physician,
  SwarmCondition,
} from '@/lib/aetherion-data';
import {
  Users,
  Video,
  Calendar,
  Search,
  CheckCircle2,
  Sparkles,
  Clock,
  Globe,
  Play,
  X,
} from 'lucide-react';

interface SpecialistSwarmSectionProps {
  calmMode?: boolean;
  onBookDoctor: (doctorName: string, specialty: string) => void;
}

export default function SpecialistSwarmSection({
  calmMode = false,
  onBookDoctor,
}: SpecialistSwarmSectionProps) {
  const [selectedSwarmId, setSelectedSwarmId] = useState<string>(
    SWARM_CONDITIONS[0].id
  );
  const [specialtyFilter, setSpecialtyFilter] = useState<string>('All');
  const [languageFilter, setLanguageFilter] = useState<string>('All');
  const [insuranceFilter, setInsuranceFilter] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeVideoDoc, setActiveVideoDoc] = useState<Physician | null>(null);

  const activeSwarm: SwarmCondition =
    SWARM_CONDITIONS.find((c) => c.id === selectedSwarmId) ||
    SWARM_CONDITIONS[0];

  const swarmDoctors = PHYSICIANS.filter((doc) =>
    activeSwarm.activeSpecialists.includes(doc.id)
  );

  const specialties = [
    'All',
    ...Array.from(new Set(PHYSICIANS.map((d) => d.specialty))),
  ];
  const languages = [
    'All',
    'English',
    'Spanish',
    'French',
    'Japanese',
    'Hindi',
    'German',
  ];
  const insurances = [
    'All',
    'Aetna',
    'BlueCross',
    'Cigna',
    'Medicare',
    'UnitedHealthcare',
  ];

  const filteredDoctors = PHYSICIANS.filter((doc) => {
    const matchesSpecialty =
      specialtyFilter === 'All' || doc.specialty === specialtyFilter;
    const matchesLang =
      languageFilter === 'All' || doc.languages.includes(languageFilter);
    const matchesIns =
      insuranceFilter === 'All' || doc.insurances.includes(insuranceFilter);
    const matchesSearch =
      searchQuery.trim() === '' ||
      doc.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      doc.specialty.toLowerCase().includes(searchQuery.toLowerCase()) ||
      doc.subspecialty.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesSpecialty && matchesLang && matchesIns && matchesSearch;
  });

  return (
    <div className="space-y-12">
      {/* PART 1: REAL-TIME SPECIALIST SWARM MATCHING ENGINE */}
      <div className="rounded-2xl border border-slate-200 bg-white p-6 sm:p-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          <div className="lg:col-span-5">
            <div className="flex items-center gap-2 text-xs font-medium text-[#0F766E]">
              <Users className="w-4 h-4" />
              <span>Specialist Swarm Matching · Multi-Disciplinary Care</span>
            </div>
            <h3 className="text-2xl font-bold tracking-tight text-slate-900 mt-2">
              {calmMode
                ? 'Four Specialists Meet Together Around You—In One Quiet Visit'
                : 'Real-Time Multi-Specialist Case Conference Matching'}
            </h3>
            <p className="text-sm text-slate-600 mt-2 leading-relaxed">
              {calmMode
                ? 'Instead of booking four separate appointments across months, select your condition below to see the exact team of doctors who review your case together.'
                : 'Complex conditions cross departmental silos. Select a clinical presentation to assemble an anonymized real-time multidisciplinary board and calculate time-to-first-opinion.'}
            </p>

            {/* Condition Selector Buttons */}
            <div className="mt-5 space-y-2">
              {SWARM_CONDITIONS.map((cond) => {
                const isSelected = cond.id === selectedSwarmId;
                return (
                  <button
                    key={cond.id}
                    type="button"
                    onClick={() => setSelectedSwarmId(cond.id)}
                    className={`w-full text-left p-3.5 rounded-xl border transition-colors cursor-pointer ${
                      isSelected
                        ? 'bg-[#0F766E]/8 border-[#0F766E] text-slate-900'
                        : 'bg-slate-50/70 border-slate-200 text-slate-700 hover:bg-slate-100/70'
                    }`}
                  >
                    <div className="flex items-center justify-between text-xs text-[#0F766E] font-medium">
                      <span>{cond.category}</span>
                      <span className="font-mono tabular-nums">
                        Est. Opinion: {cond.estimatedOpinionMinutes} mins
                      </span>
                    </div>
                    <div className="text-sm font-bold text-slate-900 mt-0.5">
                      {cond.title}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Right 7 Columns: Assembled Swarm Board & Protocol */}
          <div className="lg:col-span-7 rounded-xl bg-[#F8FAFC] border border-slate-200/90 p-5 sm:p-6">
            <div className="flex flex-wrap items-center justify-between gap-2 pb-4 border-b border-slate-200">
              <div>
                <span className="text-xs text-slate-500">
                  Active Multidisciplinary Case Board
                </span>
                <h4 className="text-lg font-bold text-slate-900">
                  {activeSwarm.title}
                </h4>
              </div>
              <div className="text-right">
                <span className="text-xs text-slate-500 block">
                  Time-to-First-Opinion
                </span>
                <span className="font-mono tabular-nums text-base font-bold text-[#0F766E]">
                  {activeSwarm.estimatedOpinionMinutes} Minutes
                </span>
              </div>
            </div>

            {/* 6th-8th Grade Plain-Language Explanation */}
            <p className="text-sm text-slate-700 mt-4 leading-relaxed">
              {activeSwarm.readingLevelSummary}
            </p>

            {/* Matched Physicians in the Swarm */}
            <div className="mt-5 grid grid-cols-1 sm:grid-cols-2 gap-3">
              {swarmDoctors.map((doc) => (
                <div
                  key={doc.id}
                  className="p-3.5 rounded-xl bg-white border border-slate-200 flex items-start gap-3"
                >
                  <div
                    className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-xs shrink-0"
                    style={{backgroundColor: doc.avatarHue}}
                  >
                    {doc.name
                      .replace('Dr. ', '')
                      .split(' ')
                      .map((n) => n[0])
                      .join('')
                      .slice(0, 2)}
                  </div>
                  <div className="min-w-0">
                    <div className="text-xs font-bold text-slate-900 truncate">
                      {doc.name}, {doc.credentials}
                    </div>
                    <div className="text-[11px] font-medium text-[#0F766E] truncate">
                      {doc.swarmRole}
                    </div>
                    <div className="text-[11px] text-slate-500 mt-0.5 font-mono">
                      Slot: {doc.nextAvailable}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Unified Swarm Protocol Steps */}
            <div className="mt-5 pt-4 border-t border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="space-y-1">
                {activeSwarm.protocolSteps.map((step, i) => (
                  <div
                    key={i}
                    className="text-xs text-slate-600 flex items-center gap-2"
                  >
                    <span className="font-mono font-semibold text-[#0F766E]">
                      0{i + 1}.
                    </span>
                    <span>{step}</span>
                  </div>
                ))}
              </div>
              <button
                type="button"
                onClick={() =>
                  onBookDoctor(
                    `Specialist Swarm (${swarmDoctors.length} Physicians)`,
                    activeSwarm.title
                  )
                }
                className="px-4 py-2.5 rounded-lg bg-[#0F766E] hover:bg-[#0D9488] text-white text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                Convene This Specialist Swarm
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* PART 2: FILTERABLE PROVIDER DIRECTORY (8 PHYSICIANS) */}
      <div>
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-6">
          <div>
            <h3 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900">
              Filterable Provider Directory ({filteredDoctors.length} Clinicians)
            </h3>
            <p className="text-sm text-slate-600 mt-1">
              Real-time appointment slots, verified insurance acceptance, spoken
              languages, and 60-second clinician video introductions.
            </p>
          </div>

          {/* Search & Filter Controls */}
          <div className="flex flex-wrap items-center gap-2.5">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search doctor or specialty..."
                aria-label="Search doctor or specialty"
                className="pl-9 pr-3 py-2 rounded-lg border border-slate-300 bg-white text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#0F766E]"
              />
            </div>

            <select
              value={specialtyFilter}
              onChange={(e) => setSpecialtyFilter(e.target.value)}
              aria-label="Filter by Specialty"
              className="px-3 py-2 rounded-lg border border-slate-300 bg-white text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#0F766E]"
            >
              {specialties.map((s) => (
                <option key={s} value={s}>
                  {s === 'All' ? 'All Specialties' : s}
                </option>
              ))}
            </select>

            <select
              value={languageFilter}
              onChange={(e) => setLanguageFilter(e.target.value)}
              aria-label="Filter by Spoken Language"
              className="px-3 py-2 rounded-lg border border-slate-300 bg-white text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#0F766E]"
            >
              {languages.map((l) => (
                <option key={l} value={l}>
                  {l === 'All' ? 'All Languages' : l}
                </option>
              ))}
            </select>

            <select
              value={insuranceFilter}
              onChange={(e) => setInsuranceFilter(e.target.value)}
              aria-label="Filter by Insurance"
              className="px-3 py-2 rounded-lg border border-slate-300 bg-white text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#0F766E]"
            >
              {insurances.map((ins) => (
                <option key={ins} value={ins}>
                  {ins === 'All' ? 'All Insurances' : ins}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Physician Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
          {filteredDoctors.map((doc) => (
            <article
              key={doc.id}
              className="rounded-2xl border border-slate-200 bg-white p-5 flex flex-col justify-between hover:border-teal-600/50 transition-colors"
            >
              <div>
                {/* Header with editorial SVG portrait & credentials */}
                <div className="flex items-start gap-3.5">
                  <div
                    className="w-12 h-12 rounded-xl flex items-center justify-center text-white font-bold text-sm shrink-0 shadow-inner"
                    style={{backgroundColor: doc.avatarHue}}
                    aria-hidden="true"
                  >
                    {doc.name
                      .replace('Dr. ', '')
                      .split(' ')
                      .map((n) => n[0])
                      .join('')
                      .slice(0, 2)}
                  </div>
                  <div className="min-w-0">
                    <h4 className="text-sm font-bold text-slate-900 leading-snug">
                      {doc.name}, {doc.credentials}
                    </h4>
                    <div className="text-xs font-medium text-[#0F766E] mt-0.5">
                      {doc.specialty}
                    </div>
                  </div>
                </div>

                {/* Unboxed Clean Metadata Row (Zero-Pill Compliance) */}
                <div className="mt-3 pt-3 border-t border-slate-100 flex flex-wrap items-center gap-1.5 text-[11px] text-slate-500">
                  <span className="font-mono tabular-nums">
                    {doc.experienceYears} yrs exp
                  </span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono tabular-nums">
                    {doc.publicationsCount} trials/papers
                  </span>
                  <span aria-hidden="true">·</span>
                  <span>{doc.languages.join(', ')}</span>
                </div>

                <p className="text-xs text-slate-600 mt-3 leading-relaxed">
                  {calmMode ? doc.calmBio : doc.clinicalFocus}
                </p>

                <div className="mt-3 text-[11px] text-slate-500">
                  <span className="font-medium text-slate-700">Insurances: </span>
                  {doc.insurances.join(' · ')}
                </div>
              </div>

              <div className="mt-5 pt-3.5 border-t border-slate-100 space-y-2.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-500">Next Slot:</span>
                  <span className="font-mono tabular-nums font-semibold text-[#0F766E]">
                    {doc.nextAvailable}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => onBookDoctor(doc.name, doc.specialty)}
                    className="flex-1 px-3 py-2 rounded-lg bg-[#0F766E] hover:bg-[#0D9488] text-white text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    Book Slot
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveVideoDoc(doc)}
                    className="px-2.5 py-2 rounded-lg border border-slate-200 hover:border-teal-600 text-slate-700 hover:text-[#0F766E] text-xs font-medium inline-flex items-center gap-1 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                    title={`Watch 60s Video Intro of ${doc.name}`}
                  >
                    <Play className="w-3.5 h-3.5" />
                    <span>Intro</span>
                  </button>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>

      {/* Clinician Video Intro Modal */}
      {activeVideoDoc && (
        <div
          className="fixed inset-0 z-50 bg-slate-950/80 flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="video-intro-title"
        >
          <div className="bg-white rounded-2xl max-w-lg w-full overflow-hidden border border-slate-200 shadow-2xl">
            <div className="bg-[#0F172A] text-white p-6 relative">
              <button
                type="button"
                onClick={() => setActiveVideoDoc(null)}
                className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded cursor-pointer"
                aria-label="Close Video Intro"
              >
                <X className="w-5 h-5" />
              </button>
              <div className="text-xs text-teal-300 font-medium">
                Clinician Philosophy & Care Approach (0:58)
              </div>
              <h4 id="video-intro-title" className="text-xl font-bold mt-1">
                {activeVideoDoc.name}, {activeVideoDoc.credentials}
              </h4>
              <p className="text-xs text-slate-300 mt-0.5">
                {activeVideoDoc.specialty} · {activeVideoDoc.subspecialty}
              </p>

              {/* Simulated High-Craft Studio Video Waveform & Transcript Preview */}
              <div className="mt-5 p-4 rounded-xl bg-slate-900 border border-slate-800">
                <div className="flex items-center gap-3 mb-3">
                  <div
                    className="w-10 h-10 rounded-full flex items-center justify-center font-bold text-xs"
                    style={{backgroundColor: activeVideoDoc.avatarHue}}
                  >
                    <Video className="w-4 h-4 text-white" />
                  </div>
                  <div className="text-xs text-slate-300">
                    Recorded in Aetherion Biophilic Atrium Studio · Captions Enabled
                  </div>
                </div>
                <blockquote className="text-sm text-teal-50 italic leading-relaxed">
                  “When you come to Aetherion, you never have to repeat your story
                  five times or decode complex lab numbers alone. {activeVideoDoc.calmBio}”
                </blockquote>
              </div>
            </div>

            <div className="p-5 flex items-center justify-between bg-slate-50">
              <div className="text-xs text-slate-600">
                Next Open Visit:{' '}
                <strong className="font-mono text-[#0F766E]">
                  {activeVideoDoc.nextAvailable}
                </strong>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setActiveVideoDoc(null)}
                  className="px-3 py-2 rounded-lg text-xs font-medium text-slate-600 hover:text-slate-900 cursor-pointer"
                >
                  Close
                </button>
                <button
                  type="button"
                  onClick={() => {
                    const doc = activeVideoDoc;
                    setActiveVideoDoc(null);
                    onBookDoctor(doc.name, doc.specialty);
                  }}
                  className="px-4 py-2 rounded-lg bg-[#0F766E] hover:bg-[#0D9488] text-white text-xs font-semibold cursor-pointer"
                >
                  Book Visit with {activeVideoDoc.name.split(' ')[1]}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
