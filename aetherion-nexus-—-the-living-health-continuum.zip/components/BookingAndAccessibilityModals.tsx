'use client';

import React, {useState} from 'react';
import {PageView} from '@/lib/aetherion-data';
import {
  X,
  CheckCircle2,
  Video,
  Calendar,
  PhoneCall,
  AlertCircle,
  Volume2,
  Eye,
  Mic,
  HeartHandshake,
} from 'lucide-react';

interface BookingModalProps {
  isOpen: boolean;
  initialMode: 'appointment' | 'virtual' | 'emergency';
  prefilledContext?: string;
  onClose: () => void;
}

export function BookingAndTriageModal({
  isOpen,
  initialMode,
  prefilledContext,
  onClose,
}: BookingModalProps) {
  const [mode, setMode] = useState<'appointment' | 'virtual' | 'emergency'>(
    initialMode
  );
  const [patientName, setPatientName] = useState<string>('');
  const [contactEmail, setContactEmail] = useState<string>('');
  const [contactPhone, setContactPhone] = useState<string>('');
  const [visitDate, setVisitDate] = useState<string>('2026-10-20');
  const [clinicalNotes, setClinicalNotes] = useState<string>(
    prefilledContext || ''
  );
  const [errorMsg, setErrorMsg] = useState<string>('');
  const [submitted, setSubmitted] = useState<boolean>(false);

  React.useEffect(() => {
    setMode(initialMode);
    if (prefilledContext) {
      setClinicalNotes(prefilledContext);
    }
    setSubmitted(false);
    setErrorMsg('');
  }, [initialMode, prefilledContext, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (patientName.trim().length < 2) {
      setErrorMsg('Please enter your full name so our care team can greet you.');
      return;
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(contactEmail.trim())) {
      setErrorMsg('Please provide a valid email address for encrypted confirmation.');
      return;
    }
    setErrorMsg('');
    setSubmitted(true);
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-950/80 flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="booking-modal-title"
    >
      <div className="bg-white rounded-2xl max-w-xl w-full overflow-hidden border border-slate-200 shadow-2xl">
        {/* Header with Mode Switcher */}
        <div className="bg-[#0F172A] text-white p-6">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-teal-300">
              Aetherion Care Access & Instant Triage
            </span>
            <button
              type="button"
              onClick={onClose}
              className="text-slate-400 hover:text-white p-1 rounded cursor-pointer"
              aria-label="Close modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <h3 id="booking-modal-title" className="text-xl font-bold mt-1">
            {mode === 'appointment' && 'Schedule Campus or Specialist Visit'}
            {mode === 'virtual' && 'Start Instant Telemedicine / eVisit Handoff'}
            {mode === 'emergency' && '24/7 Emergency & Acute Stabilization Guidance'}
          </h3>

          <div className="mt-4 flex items-center gap-2">
            <button
              type="button"
              onClick={() => {
                setMode('appointment');
                setSubmitted(false);
              }}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                mode === 'appointment'
                  ? 'bg-[#0D9488] text-white'
                  : 'bg-slate-800 text-slate-300 hover:text-white'
              }`}
            >
              Book Appointment
            </button>
            <button
              type="button"
              onClick={() => {
                setMode('virtual');
                setSubmitted(false);
              }}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                mode === 'virtual'
                  ? 'bg-[#0D9488] text-white'
                  : 'bg-slate-800 text-slate-300 hover:text-white'
              }`}
            >
              Start Virtual eVisit
            </button>
            <button
              type="button"
              onClick={() => {
                setMode('emergency');
                setSubmitted(false);
              }}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                mode === 'emergency'
                  ? 'bg-amber-500 text-slate-950'
                  : 'bg-slate-800 text-slate-300 hover:text-white'
              }`}
            >
              Emergency Triage
            </button>
          </div>
        </div>

        {/* Body Content */}
        <div className="p-6">
          {mode === 'emergency' ? (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-amber-50 border border-amber-300 text-slate-900">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-amber-900">
                    Live Trauma & Stabilization Pod Status
                  </span>
                  <span className="font-mono text-xs font-bold text-[#0F766E]">
                    Current Wait: 3 Minutes
                  </span>
                </div>
                <p className="text-xs text-slate-700 mt-1.5 leading-relaxed">
                  If you are experiencing chest pain, stroke symptoms, or severe
                  shortness of breath, call <strong>911</strong> or tap our
                  Direct Ambulance Telemetry Line below so our Stabilization
                  Suite is pre-warmed before you arrive.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <a
                  href="tel:911"
                  className="p-4 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold flex items-center justify-between"
                >
                  <span>Call 911 Emergency</span>
                  <PhoneCall className="w-4 h-4" />
                </a>
                <a
                  href="tel:+18005552384"
                  className="p-4 rounded-xl bg-[#0F766E] hover:bg-[#0D9488] text-white font-bold flex items-center justify-between"
                >
                  <span>Aetherion Triage Desk (24/7)</span>
                  <PhoneCall className="w-4 h-4" />
                </a>
              </div>

              <div className="text-xs text-slate-600 pt-2">
                <strong>Direct Emergency Entrance:</strong> North Pavilion Level
                G1 (Valet & Zero-Wait Private Stabilization Pods · 400 Aetherion
                Way).
              </div>
            </div>
          ) : submitted ? (
            <div className="py-6 text-center space-y-3">
              <CheckCircle2 className="w-12 h-12 text-[#0F766E] mx-auto" />
              <h4 className="text-lg font-bold text-slate-900">
                {mode === 'virtual'
                  ? 'Encrypted eVisit Room Ready'
                  : 'Care Appointment Confirmed'}
              </h4>
              <p className="text-sm text-slate-600 max-w-md mx-auto">
                Thank you, <strong>{patientName}</strong>. We have sent your
                Sovereign Pass and AR Campus Wayfinding token to{' '}
                <strong className="font-mono">{contactEmail}</strong>.
              </p>
              {clinicalNotes && (
                <div className="text-xs text-slate-500 bg-slate-50 p-3 rounded-lg border border-slate-200 max-w-md mx-auto">
                  Selected Pathway / Specialist: <strong>{clinicalNotes}</strong>
                </div>
              )}
              <div className="pt-3">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-5 py-2.5 rounded-lg bg-[#0F766E] text-white text-xs font-semibold cursor-pointer"
                >
                  Return to Aetherion Continuum
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4" noValidate>
              {errorMsg && (
                <div
                  role="alert"
                  className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center gap-2"
                >
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{errorMsg}</span>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label
                    htmlFor="booking-name"
                    className="block text-xs font-semibold text-slate-700 mb-1"
                  >
                    Patient Full Name *
                  </label>
                  <input
                    id="booking-name"
                    type="text"
                    required
                    value={patientName}
                    onChange={(e) => setPatientName(e.target.value)}
                    placeholder="Claire Vance-Lin"
                    className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#0F766E]"
                  />
                </div>

                <div>
                  <label
                    htmlFor="booking-email"
                    className="block text-xs font-semibold text-slate-700 mb-1"
                  >
                    Encrypted Confirmation Email *
                  </label>
                  <input
                    id="booking-email"
                    type="email"
                    required
                    value={contactEmail}
                    onChange={(e) => setContactEmail(e.target.value)}
                    placeholder="claire@example.com"
                    className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#0F766E]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label
                    htmlFor="booking-phone"
                    className="block text-xs font-semibold text-slate-700 mb-1"
                  >
                    Mobile Number (For AR Campus Pass)
                  </label>
                  <input
                    id="booking-phone"
                    type="tel"
                    value={contactPhone}
                    onChange={(e) => setContactPhone(e.target.value)}
                    placeholder="(555) 234-8910"
                    className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#0F766E]"
                  />
                </div>

                <div>
                  <label
                    htmlFor="booking-date"
                    className="block text-xs font-semibold text-slate-700 mb-1"
                  >
                    Preferred Date
                  </label>
                  <input
                    id="booking-date"
                    type="date"
                    value={visitDate}
                    onChange={(e) => setVisitDate(e.target.value)}
                    className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#0F766E]"
                  />
                </div>
              </div>

              <div>
                <label
                  htmlFor="booking-notes"
                  className="block text-xs font-semibold text-slate-700 mb-1"
                >
                  Selected Specialist, Pathway, or Clinical Goal
                </label>
                <input
                  id="booking-notes"
                  type="text"
                  value={clinicalNotes}
                  onChange={(e) => setClinicalNotes(e.target.value)}
                  placeholder="e.g., Regenerative Cardiology Swarm or 7T MRI Checkup"
                  className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#0F766E]"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 rounded-lg text-xs font-medium text-slate-600 hover:text-slate-900 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-lg bg-[#F59E0B] hover:bg-amber-400 text-slate-950 text-xs font-bold transition-colors cursor-pointer"
                >
                  {mode === 'virtual'
                    ? 'Launch Encrypted Video Handoff'
                    : 'Confirm Care Appointment'}
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}

interface ZeroUIAccessibilityBarProps {
  active: boolean;
  onClose: () => void;
  onNavigatePage: (page: PageView) => void;
  onOpenBooking: (mode: 'appointment' | 'virtual' | 'emergency') => void;
}

export function ZeroUIAccessibilityOverlay({
  active,
  onClose,
  onNavigatePage,
  onOpenBooking,
}: ZeroUIAccessibilityBarProps) {
  const [spokenStatus, setSpokenStatus] = useState<string>(
    'Zero-UI Voice & Large-Target Mode Active. Click any oversized button or press Speak Summary.'
  );

  if (!active) return null;

  const speakText = (text: string) => {
    setSpokenStatus(text);
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.95;
      window.speechSynthesis.speak(utterance);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-950 text-white p-6 sm:p-10 overflow-y-auto flex flex-col justify-between"
      role="dialog"
      aria-modal="true"
      aria-label="Zero-UI Extreme Accessibility High-Contrast Large-Target Mode"
    >
      <div>
        <div className="flex flex-wrap items-center justify-between gap-4 pb-6 border-b-2 border-teal-400">
          <div>
            <div className="text-sm font-mono text-amber-400 font-bold">
              WCAG 2.2 AAA · ZERO-UI EXTREME ACCESSIBILITY MODE (ALT + A)
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold mt-1">
              Aetherion Nexus Voice & Large-Target Navigator
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="px-6 py-4 rounded-xl bg-slate-800 hover:bg-slate-700 border-2 border-white text-lg font-bold cursor-pointer"
          >
            Exit Accessibility Mode
          </button>
        </div>

        {/* Voice Readout Banner */}
        <div className="mt-6 p-5 rounded-2xl bg-slate-900 border-2 border-teal-400 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <Volume2 className="w-8 h-8 text-teal-300 shrink-0" />
            <p className="text-lg font-medium text-teal-100">{spokenStatus}</p>
          </div>
          <button
            type="button"
            onClick={() =>
              speakText(
                'Welcome to Aetherion Nexus. Emergency wait time is 3 minutes. You can book a doctor, start a virtual visit, explore the 3D hospital campus, or review your health records using the large buttons below.'
              )
            }
            className="px-5 py-3 rounded-xl bg-amber-400 text-slate-950 font-bold text-base cursor-pointer"
          >
            Read Page Aloud
          </button>
        </div>

        {/* Oversized High-Contrast Action Grid (>= 64px touch targets) */}
        <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-5">
          <button
            type="button"
            onClick={() => {
              speakText('Opening Appointment Booking.');
              onClose();
              onOpenBooking('appointment');
            }}
            className="p-6 rounded-2xl bg-[#0D9488] hover:bg-teal-600 border-2 border-white text-left transition-colors cursor-pointer"
          >
            <div className="text-2xl font-bold">1. Book a Doctor Visit</div>
            <div className="text-base text-teal-50 mt-1">
              Same-day in-person or specialist swarm consultations
            </div>
          </button>

          <button
            type="button"
            onClick={() => {
              speakText('Opening Virtual Video Visit.');
              onClose();
              onOpenBooking('virtual');
            }}
            className="p-6 rounded-2xl bg-[#0F766E] hover:bg-teal-700 border-2 border-white text-left transition-colors cursor-pointer"
          >
            <div className="text-2xl font-bold">2. Start Virtual Video Visit</div>
            <div className="text-base text-teal-50 mt-1">
              Connect with an Aetherion clinician from home in minutes
            </div>
          </button>

          <button
            type="button"
            onClick={() => {
              speakText('Opening 3D Hospital Digital Twin and Interior Suites.');
              onClose();
              onNavigatePage('digital-twin');
            }}
            className="p-6 rounded-2xl bg-slate-900 hover:bg-slate-800 border-2 border-teal-400 text-left transition-colors cursor-pointer"
          >
            <div className="text-2xl font-bold text-teal-300">
              3. Explore 3D Hospital & Interior Rooms
            </div>
            <div className="text-base text-slate-200 mt-1">
              Inspect the Atrium, 7T MRI Suite, Cell Lab, and Recovery Rooms
            </div>
          </button>

          <button
            type="button"
            onClick={() => {
              speakText('Opening 24/7 Emergency Guidance. Current wait is 3 minutes.');
              onClose();
              onOpenBooking('emergency');
            }}
            className="p-6 rounded-2xl bg-amber-500 hover:bg-amber-400 border-2 border-white text-slate-950 text-left transition-colors cursor-pointer"
          >
            <div className="text-2xl font-bold">
              4. Emergency Guidance (3 Min Wait)
            </div>
            <div className="text-base font-medium mt-1">
              Immediate 24/7 triage and direct ambulance stabilization pod
            </div>
          </button>
        </div>
      </div>

      <div className="mt-8 pt-4 border-t border-slate-800 text-sm text-slate-300 flex flex-wrap items-center justify-between gap-4">
        <span>
          Keyboard Shortcut: Press <strong>Alt + A</strong> anytime to toggle
          Zero-UI Accessibility Mode.
        </span>
        <span>24/7 Human Accessibility Concierge: 1-800-555-2384</span>
      </div>
    </div>
  );
}
