'use client';

import React, {useEffect, useRef} from 'react';
import * as THREE from 'three';
import {RoomEnvironment} from 'three/addons/environments/RoomEnvironment.js';

export default function HeroBioSculpture3D() {
  const mountRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    let renderer: THREE.WebGLRenderer;
    try {
      const isHeadless =
        typeof navigator !== 'undefined' &&
        (navigator.webdriver || /HeadlessChrome/i.test(navigator.userAgent));

      renderer = new THREE.WebGLRenderer({
        antialias: !isHeadless,
        alpha: true,
        powerPreference: 'high-performance',
      });
      renderer.outputColorSpace = THREE.SRGBColorSpace;
      renderer.toneMapping = THREE.ACESFilmicToneMapping;
      renderer.toneMappingExposure = 1.15;
      renderer.setPixelRatio(
        isHeadless ? 1 : Math.min(window.devicePixelRatio, 2)
      );
      renderer.setSize(container.clientWidth, container.clientHeight);
      container.innerHTML = '';
      container.appendChild(renderer.domElement);
    } catch {
      return;
    }

    const scene = new THREE.Scene();

    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    const envTexture = pmremGenerator.fromScene(
      new RoomEnvironment(),
      0.04
    ).texture;
    scene.environment = envTexture;
    pmremGenerator.dispose();

    const camera = new THREE.PerspectiveCamera(
      38,
      container.clientWidth / container.clientHeight,
      0.1,
      100
    );
    camera.position.set(0, 0.4, 8.2);

    // 3-Point Warm/Cool Studio Lighting
    const hemi = new THREE.HemisphereLight(0xf0fdfa, 0xe2e8f0, 1.0);
    scene.add(hemi);

    const keyLight = new THREE.DirectionalLight(0xfffbeb, 1.9);
    keyLight.position.set(6, 8, 7);
    scene.add(keyLight);

    const rimLight = new THREE.DirectionalLight(0x0d9488, 1.5);
    rimLight.position.set(-7, -5, -4);
    scene.add(rimLight);

    // Composite 6-Part Bio-Architectural Sculpture Group
    const sculptureGroup = new THREE.Group();
    scene.add(sculptureGroup);

    // 1. Primary Outer Transmissive Bio-Torus Knot
    const glassBioMat = new THREE.MeshPhysicalMaterial({
      color: 0x0d9488,
      roughness: 0.12,
      metalness: 0.1,
      transmission: 0.78,
      ior: 1.52,
      thickness: 1.6,
      clearcoat: 1.0,
    });
    const torusKnot = new THREE.Mesh(
      new THREE.TorusKnotGeometry(1.55, 0.36, 128, 24, 2, 3),
      glassBioMat
    );
    sculptureGroup.add(torusKnot);

    // 2. Inner Brushed Gold/Amber Precision Medical Ring
    const goldRingMat = new THREE.MeshPhysicalMaterial({
      color: 0xf59e0b,
      roughness: 0.2,
      metalness: 0.88,
      clearcoat: 0.8,
    });
    const innerRing1 = new THREE.Mesh(
      new THREE.TorusGeometry(2.35, 0.045, 20, 96),
      goldRingMat
    );
    innerRing1.rotation.x = Math.PI / 3;
    sculptureGroup.add(innerRing1);

    const innerRing2 = new THREE.Mesh(
      new THREE.TorusGeometry(2.62, 0.035, 16, 96),
      new THREE.MeshPhysicalMaterial({
        color: 0x0f766e,
        roughness: 0.25,
        metalness: 0.75,
      })
    );
    innerRing2.rotation.y = Math.PI / 4;
    sculptureGroup.add(innerRing2);

    // 3. Central Cellular Core Sphere
    const coreSphere = new THREE.Mesh(
      new THREE.IcosahedronGeometry(0.68, 3),
      new THREE.MeshStandardMaterial({
        color: 0xf8fafc,
        roughness: 0.3,
        metalness: 0.2,
        emissive: 0x0d9488,
        emissiveIntensity: 0.2,
      })
    );
    sculptureGroup.add(coreSphere);

    // 4. Orbiting Cellular Nodes (InstancedMesh of 18 micro-spheres)
    const nodeCount = 18;
    const nodesInst = new THREE.InstancedMesh(
      new THREE.SphereGeometry(0.11, 16, 16),
      goldRingMat,
      nodeCount
    );
    const dummyMat = new THREE.Matrix4();
    const dummyPos = new THREE.Vector3();
    const dummyQuat = new THREE.Quaternion();
    const dummyScale = new THREE.Vector3(1, 1, 1);

    for (let i = 0; i < nodeCount; i++) {
      const a = (i / nodeCount) * Math.PI * 2;
      dummyPos.set(
        Math.cos(a) * 2.35,
        Math.sin(a) * 1.15,
        Math.sin(a * 2) * 0.85
      );
      dummyMat.compose(dummyPos, dummyQuat, dummyScale);
      nodesInst.setMatrixAt(i, dummyMat);
    }
    nodesInst.computeBoundingSphere();
    sculptureGroup.add(nodesInst);

    renderer.compile(scene, camera);

    let pointerX = 0;
    let pointerY = 0;
    const onPointerMove = (e: PointerEvent) => {
      const rect = container.getBoundingClientRect();
      pointerX = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      pointerY = -((e.clientY - rect.top) / rect.height) * 2 + 1;
    };
    container.addEventListener('pointermove', onPointerMove);

    const clock = new THREE.Clock();
    let frameId = 0;

    const animate = () => {
      frameId = requestAnimationFrame(animate);
      const dt = Math.min(clock.getDelta(), 0.1);
      const t = clock.getElapsedTime();

      torusKnot.rotation.y = t * 0.22;
      torusKnot.rotation.x = Math.sin(t * 0.35) * 0.25;

      innerRing1.rotation.z = t * 0.3;
      innerRing2.rotation.x = -t * 0.24;
      coreSphere.scale.setScalar(1 + Math.sin(t * 2.2) * 0.06);

      sculptureGroup.rotation.y = THREE.MathUtils.damp(
        sculptureGroup.rotation.y,
        pointerX * 0.45,
        4,
        dt
      );
      sculptureGroup.rotation.x = THREE.MathUtils.damp(
        sculptureGroup.rotation.x,
        -pointerY * 0.3,
        4,
        dt
      );

      renderer.render(scene, camera);
    };
    animate();

    const handleResize = () => {
      if (!container) return;
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(frameId);
      window.removeEventListener('resize', handleResize);
      container.removeEventListener('pointermove', onPointerMove);
      envTexture.dispose();
      renderer.dispose();
    };
  }, []);

  return (
    <div
      ref={mountRef}
      className="w-full h-full min-h-[360px]"
      aria-label="Interactive 3D Regenerative Bio-Architectural Sculpture"
      role="img"
    />
  );
}
