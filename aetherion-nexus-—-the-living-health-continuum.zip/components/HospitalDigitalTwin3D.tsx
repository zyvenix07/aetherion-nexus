'use client';

import React, {useEffect, useRef, useState} from 'react';
import * as THREE from 'three';
import {OrbitControls} from 'three/addons/controls/OrbitControls.js';
import {RoomEnvironment} from 'three/addons/environments/RoomEnvironment.js';
import {CAMPUS_ZONES, CampusZone} from '@/lib/aetherion-data';
import {
  Building2,
  Compass,
  Eye,
  Layers,
  Maximize2,
  Minimize2,
  QrCode,
  Sliders,
  Sparkles,
  Sun,
  Moon,
  ChevronDown,
  ChevronUp,
  CheckCircle2,
  Navigation,
} from 'lucide-react';

// Pre-allocated math helpers at module scope to guarantee zero GC in render loop
const _targetCamPos = new THREE.Vector3();
const _targetLookAt = new THREE.Vector3();
const _tempMatrix = new THREE.Matrix4();
const _tempPos = new THREE.Vector3();
const _tempQuat = new THREE.Quaternion();
const _tempScale = new THREE.Vector3();
const _tempColor = new THREE.Color();

interface HospitalDigitalTwin3DProps {
  calmMode?: boolean;
  initialZoneId?: string;
  compactMode?: boolean;
  onExpandFullPage?: () => void;
  onBookInZone?: (zoneName: string) => void;
}

export default function HospitalDigitalTwin3D({
  calmMode = false,
  initialZoneId = 'campus-overview',
  compactMode = false,
  onExpandFullPage,
  onBookInZone,
}: HospitalDigitalTwin3DProps) {
  const canvasMountRef = useRef<HTMLDivElement | null>(null);

  const [activeZoneId, setActiveZoneId] = useState<string>(initialZoneId);
  const [cutawayLevel, setCutawayLevel] = useState<number>(
    initialZoneId === 'campus-overview' ? 0.15 : 0.88
  );
  const [circadianNight, setCircadianNight] = useState<boolean>(false);
  const [dockCollapsed, setDockCollapsed] = useState<boolean>(false);
  const [showArModal, setShowArModal] = useState<boolean>(false);
  const [arCopied, setArCopied] = useState<boolean>(false);
  const [webglReady, setWebglReady] = useState<boolean>(true);

  const activeZone: CampusZone =
    CAMPUS_ZONES.find((z) => z.id === activeZoneId) || CAMPUS_ZONES[0];

  // Mutable state ref consumed inside the Three.js requestAnimationFrame loop
  const simRef = useRef({
    cameraPos: new THREE.Vector3(...activeZone.cameraPos),
    cameraTarget: new THREE.Vector3(...activeZone.cameraTarget),
    cutawayTarget: initialZoneId === 'campus-overview' ? 0.15 : 0.88,
    cutawayCurrent: initialZoneId === 'campus-overview' ? 0.15 : 0.88,
    circadianNight: false,
    userInteracting: false,
    activeZoneId: initialZoneId,
  });

  // Sync React controls to mutable simulation ref
  useEffect(() => {
    const zone =
      CAMPUS_ZONES.find((z) => z.id === activeZoneId) || CAMPUS_ZONES[0];
    simRef.current.cameraPos.set(...zone.cameraPos);
    simRef.current.cameraTarget.set(...zone.cameraTarget);
    simRef.current.activeZoneId = activeZoneId;
    simRef.current.userInteracting = false;

    const autoCutaway = zone.category === 'interior-suite' ? 0.92 : 0.12;
    setCutawayLevel(autoCutaway);
    simRef.current.cutawayTarget = autoCutaway;
  }, [activeZoneId]);

  useEffect(() => {
    simRef.current.cutawayTarget = cutawayLevel;
  }, [cutawayLevel]);

  useEffect(() => {
    simRef.current.circadianNight = circadianNight;
  }, [circadianNight]);

  // Keyboard shortcut 'H' to toggle HUD drawer
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (
        e.key.toLowerCase() === 'h' &&
        document.activeElement?.tagName !== 'INPUT' &&
        document.activeElement?.tagName !== 'TEXTAREA'
      ) {
        setDockCollapsed((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  useEffect(() => {
    const container = canvasMountRef.current;
    if (!container) return;

    let renderer: THREE.WebGLRenderer;
    try {
      const isHeadless =
        typeof navigator !== 'undefined' &&
        (navigator.webdriver || /HeadlessChrome/i.test(navigator.userAgent));

      renderer = new THREE.WebGLRenderer({
        antialias: !isHeadless,
        powerPreference: 'high-performance',
      });
      renderer.outputColorSpace = THREE.SRGBColorSpace;
      renderer.toneMapping = THREE.ACESFilmicToneMapping;
      renderer.toneMappingExposure = 1.08;
      renderer.setPixelRatio(
        isHeadless ? 1 : Math.min(window.devicePixelRatio, 2)
      );
      renderer.shadowMap.enabled = !isHeadless;
      renderer.shadowMap.type = THREE.PCFSoftShadowMap;
      renderer.setSize(container.clientWidth, container.clientHeight);
      container.innerHTML = '';
      container.appendChild(renderer.domElement);
    } catch {
      setWebglReady(false);
      return;
    }

    const scene = new THREE.Scene();
    const daySkyColor = new THREE.Color(0xf1f5f9);
    const nightSkyColor = new THREE.Color(0x0b1528);
    scene.background = daySkyColor.clone();
    scene.fog = new THREE.FogExp2(0xf1f5f9, 0.012);

    // Studio Environment Reflection via RoomEnvironment + PMREMGenerator
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    const envTexture = pmremGenerator.fromScene(
      new RoomEnvironment(),
      0.04
    ).texture;
    scene.environment = envTexture;
    pmremGenerator.dispose();

    const camera = new THREE.PerspectiveCamera(
      42,
      container.clientWidth / container.clientHeight,
      0.5,
      180
    );
    camera.position.copy(simRef.current.cameraPos);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.06;
    controls.maxPolarAngle = Math.PI / 2 - 0.03;
    controls.minDistance = 4;
    controls.maxDistance = 58;
    controls.target.copy(simRef.current.cameraTarget);

    const onControlStart = () => {
      simRef.current.userInteracting = true;
    };
    controls.addEventListener('start', onControlStart);

    // 3-Point Balanced Studio & Architectural Lighting
    const hemiLight = new THREE.HemisphereLight(0xe0f2fe, 0xd6d3d1, 0.85);
    hemiLight.position.set(0, 35, 0);
    scene.add(hemiLight);

    const keyLight = new THREE.DirectionalLight(0xfffbeb, 1.65);
    keyLight.position.set(24, 34, 22);
    keyLight.castShadow = renderer.shadowMap.enabled;
    keyLight.shadow.mapSize.width = 1024;
    keyLight.shadow.mapSize.height = 1024;
    keyLight.shadow.camera.near = 5;
    keyLight.shadow.camera.far = 90;
    const d = 26;
    keyLight.shadow.camera.left = -d;
    keyLight.shadow.camera.right = d;
    keyLight.shadow.camera.top = d;
    keyLight.shadow.camera.bottom = -d;
    keyLight.shadow.bias = -0.0005;
    keyLight.shadow.normalBias = 0.02;
    scene.add(keyLight);

    const rimLight = new THREE.DirectionalLight(0x2dd4bf, 0.75);
    rimLight.position.set(-22, 18, -20);
    scene.add(rimLight);

    // Interior warm clinical point lights
    const atriumLight = new THREE.PointLight(0xfef3c7, 2.2, 18);
    atriumLight.position.set(0, 4.5, 0);
    scene.add(atriumLight);

    const mriSuiteLight = new THREE.PointLight(0x38bdf8, 2.5, 14);
    mriSuiteLight.position.set(-8.5, 4.2, 0);
    scene.add(mriSuiteLight);

    const cellLabLight = new THREE.PointLight(0x14b8a6, 2.5, 14);
    cellLabLight.position.set(8.5, 4.2, 0);
    scene.add(cellLabLight);

    // Shared PBR Material Library
    const limestoneMat = new THREE.MeshStandardMaterial({
      color: 0xf8fafc,
      roughness: 0.65,
      metalness: 0.05,
    });
    const warmTimberMat = new THREE.MeshStandardMaterial({
      color: 0xc29b61,
      roughness: 0.42,
      metalness: 0.1,
    });
    const darkSlateMat = new THREE.MeshStandardMaterial({
      color: 0x1e293b,
      roughness: 0.35,
      metalness: 0.55,
    });
    const brushedTitaniumMat = new THREE.MeshPhysicalMaterial({
      color: 0xe2e8f0,
      roughness: 0.2,
      metalness: 0.88,
      clearcoat: 0.6,
    });
    const tealAccentMat = new THREE.MeshStandardMaterial({
      color: 0x0d9488,
      roughness: 0.25,
      metalness: 0.3,
      emissive: 0x0f766e,
      emissiveIntensity: 0.25,
    });
    const amberBeaconMat = new THREE.MeshStandardMaterial({
      color: 0xf59e0b,
      roughness: 0.2,
      metalness: 0.2,
      emissive: 0xf59e0b,
      emissiveIntensity: 0.6,
    });
    const glassFacadeMat = new THREE.MeshPhysicalMaterial({
      color: 0xccfbf1,
      transparent: true,
      opacity: 0.34,
      roughness: 0.08,
      metalness: 0.1,
      transmission: 0.72,
      ior: 1.5,
      depthWrite: false,
    });

    // Procedural Ground & Biophilic Campus Terrain
    const groundGroup = new THREE.Group();
    const terrainGeo = new THREE.CylinderGeometry(48, 50, 0.8, 64);
    const terrainMat = new THREE.MeshStandardMaterial({
      color: 0xe2e8f0,
      roughness: 0.85,
      metalness: 0.02,
    });
    const terrainMesh = new THREE.Mesh(terrainGeo, terrainMat);
    terrainMesh.position.y = -0.4;
    terrainMesh.receiveShadow = true;
    groundGroup.add(terrainMesh);

    // Architectural Plaza Base & Subtle Grid Ring
    const plazaGeo = new THREE.CylinderGeometry(22, 22.8, 0.24, 48);
    const plazaMesh = new THREE.Mesh(plazaGeo, limestoneMat);
    plazaMesh.position.y = 0.12;
    plazaMesh.receiveShadow = true;
    groundGroup.add(plazaMesh);
    scene.add(groundGroup);

    // =========================================================================
    // INTERIOR CLINICAL SUITES (Always rendered inside the ground/middle levels)
    // =========================================================================
    const interiorGroup = new THREE.Group();
    scene.add(interiorGroup);

    // 1. CENTRAL BIOPHILIC ATRIUM (0, 0, 0)
    const atriumGroup = new THREE.Group();
    // Hydro-therapy reflection pool
    const poolRingGeo = new THREE.CylinderGeometry(3.4, 3.6, 0.32, 36);
    const poolRing = new THREE.Mesh(poolRingGeo, warmTimberMat);
    poolRing.position.set(0, 0.4, 0);
    atriumGroup.add(poolRing);

    const waterGeo = new THREE.CylinderGeometry(3.1, 3.1, 0.26, 36);
    const waterMat = new THREE.MeshPhysicalMaterial({
      color: 0x14b8a6,
      roughness: 0.1,
      metalness: 0.1,
      transmission: 0.65,
      transparent: true,
      opacity: 0.85,
    });
    const waterMesh = new THREE.Mesh(waterGeo, waterMat);
    waterMesh.position.set(0, 0.45, 0);
    atriumGroup.add(waterMesh);

    // Central Sanctuary Tree inside Atrium (Composite multi-part trunk + canopy)
    const centralTree = new THREE.Group();
    const trunkGeo = new THREE.CylinderGeometry(0.18, 0.28, 2.6, 12);
    const trunkMesh = new THREE.Mesh(trunkGeo, warmTimberMat);
    trunkMesh.position.y = 1.6;
    centralTree.add(trunkMesh);

    const canopyMat = new THREE.MeshStandardMaterial({
      color: 0x0f766e,
      roughness: 0.55,
      metalness: 0.05,
    });
    const canopyPositions: [number, number, number, number][] = [
      [0, 3.1, 0, 1.35],
      [0.85, 2.75, 0.5, 0.95],
      [-0.8, 2.8, -0.4, 1.0],
      [0.3, 3.4, -0.7, 0.85],
    ];
    canopyPositions.forEach(([cx, cy, cz, r]) => {
      const cMesh = new THREE.Mesh(
        new THREE.IcosahedronGeometry(r, 2),
        canopyMat
      );
      cMesh.position.set(cx, cy, cz);
      cMesh.castShadow = true;
      centralTree.add(cMesh);
    });
    atriumGroup.add(centralTree);

    // Concierge Reception Ring & Wayfinding Totems
    const deskCurveGeo = new THREE.TorusGeometry(4.6, 0.32, 16, 48, Math.PI * 0.85);
    const deskMesh = new THREE.Mesh(deskCurveGeo, warmTimberMat);
    deskMesh.rotation.x = Math.PI / 2;
    deskMesh.rotation.z = Math.PI * 0.08;
    deskMesh.position.set(0, 0.65, 0.5);
    atriumGroup.add(deskMesh);
    interiorGroup.add(atriumGroup);

    // 2. WEST WING: 7-TESLA HYBRID MRI & NEURO-ROBOTICS SUITE (-8.5, 0, 0)
    const mriSuiteGroup = new THREE.Group();
    mriSuiteGroup.position.set(-8.5, 0.25, 0);

    // Suite Floor Pad
    const mriFloor = new THREE.Mesh(
      new THREE.BoxGeometry(6.8, 0.16, 6.8),
      new THREE.MeshStandardMaterial({color: 0xf1f5f9, roughness: 0.3})
    );
    mriSuiteGroup.add(mriFloor);

    // 7-Tesla MRI Gantry (Composite Torus + Outer Shell + glowing diagnostic ring)
    const mriGantryGroup = new THREE.Group();
    mriGantryGroup.position.set(0, 1.65, -0.8);

    const outerDrum = new THREE.Mesh(
      new THREE.CylinderGeometry(1.55, 1.55, 1.7, 36, 1, true),
      limestoneMat
    );
    outerDrum.rotation.x = Math.PI / 2;
    mriGantryGroup.add(outerDrum);

    const innerBore = new THREE.Mesh(
      new THREE.CylinderGeometry(0.85, 0.85, 1.72, 32, 1, true),
      brushedTitaniumMat
    );
    innerBore.rotation.x = Math.PI / 2;
    mriGantryGroup.add(innerBore);

    const frontFaceRing = new THREE.Mesh(
      new THREE.RingGeometry(0.85, 1.55, 36),
      limestoneMat
    );
    frontFaceRing.position.z = 0.85;
    mriGantryGroup.add(frontFaceRing);

    const backFaceRing = frontFaceRing.clone();
    backFaceRing.rotation.y = Math.PI;
    backFaceRing.position.z = -0.85;
    mriGantryGroup.add(backFaceRing);

    const fluxRing = new THREE.Mesh(
      new THREE.TorusGeometry(1.18, 0.055, 16, 48),
      tealAccentMat
    );
    fluxRing.position.z = 0.87;
    mriGantryGroup.add(fluxRing);
    mriSuiteGroup.add(mriGantryGroup);

    // Motorized Patient Table & Scanning Bed (animated in loop)
    const mriPedestal = new THREE.Mesh(
      new THREE.BoxGeometry(0.7, 0.85, 1.8),
      darkSlateMat
    );
    mriPedestal.position.set(0, 0.5, 1.5);
    mriSuiteGroup.add(mriPedestal);

    const mriCradle = new THREE.Mesh(
      new THREE.BoxGeometry(0.62, 0.1, 2.7),
      warmTimberMat
    );
    mriCradle.position.set(0, 1.02, 1.1);
    mriSuiteGroup.add(mriCradle);

    // Dual Articulated Neuro-Surgical Robotic Arms
    const robotArmLeft = new THREE.Group();
    robotArmLeft.position.set(-1.95, 0.2, 0.4);
    const baseCol = new THREE.Mesh(
      new THREE.CylinderGeometry(0.22, 0.28, 1.8, 16),
      brushedTitaniumMat
    );
    baseCol.position.y = 0.9;
    robotArmLeft.add(baseCol);

    const shoulderJoint = new THREE.Mesh(
      new THREE.SphereGeometry(0.24, 16, 16),
      tealAccentMat
    );
    shoulderJoint.position.y = 1.85;
    robotArmLeft.add(shoulderJoint);

    const upperArm = new THREE.Mesh(
      new THREE.CylinderGeometry(0.1, 0.14, 1.35, 12),
      brushedTitaniumMat
    );
    upperArm.position.set(0.45, 2.25, -0.2);
    upperArm.rotation.z = -Math.PI / 4;
    robotArmLeft.add(upperArm);

    const robotArmRight = robotArmLeft.clone();
    robotArmRight.position.set(1.95, 0.2, 0.4);
    robotArmRight.rotation.y = Math.PI;
    mriSuiteGroup.add(robotArmLeft);
    mriSuiteGroup.add(robotArmRight);

    interiorGroup.add(mriSuiteGroup);

    // 3. EAST WING: AUTOLOGOUS GMP CELL & TISSUE BIO-FOUNDRY (8.5, 0, 0)
    const cellLabGroup = new THREE.Group();
    cellLabGroup.position.set(8.5, 0.25, 0);

    const labFloor = new THREE.Mesh(
      new THREE.BoxGeometry(6.8, 0.16, 6.8),
      new THREE.MeshStandardMaterial({color: 0xf1f5f9, roughness: 0.25})
    );
    cellLabGroup.add(labFloor);

    // Rotating Bioreactor Carousel (6 glass perfusion vessels)
    const bioreactorCarousel = new THREE.Group();
    bioreactorCarousel.position.set(0, 0.2, 0);

    const centralHub = new THREE.Mesh(
      new THREE.CylinderGeometry(0.65, 0.8, 2.6, 24),
      brushedTitaniumMat
    );
    centralHub.position.y = 1.3;
    bioreactorCarousel.add(centralHub);

    for (let i = 0; i < 6; i++) {
      const angle = (i / 6) * Math.PI * 2;
      const rx = Math.cos(angle) * 1.85;
      const rz = Math.sin(angle) * 1.85;

      const vesselGroup = new THREE.Group();
      vesselGroup.position.set(rx, 0, rz);

      const baseCap = new THREE.Mesh(
        new THREE.CylinderGeometry(0.42, 0.46, 0.35, 20),
        darkSlateMat
      );
      baseCap.position.y = 0.2;
      vesselGroup.add(baseCap);

      const nutrientColumn = new THREE.Mesh(
        new THREE.CylinderGeometry(0.36, 0.36, 1.65, 20),
        new THREE.MeshPhysicalMaterial({
          color: i % 2 === 0 ? 0x14b8a6 : 0x0ea5e9,
          roughness: 0.12,
          metalness: 0.1,
          transmission: 0.78,
          transparent: true,
          opacity: 0.75,
        })
      );
      nutrientColumn.position.y = 1.2;
      vesselGroup.add(nutrientColumn);

      const topCap = new THREE.Mesh(
        new THREE.CylinderGeometry(0.4, 0.42, 0.25, 20),
        brushedTitaniumMat
      );
      topCap.position.y = 2.12;
      vesselGroup.add(topCap);

      bioreactorCarousel.add(vesselGroup);
    }
    cellLabGroup.add(bioreactorCarousel);
    interiorGroup.add(cellLabGroup);

    // 4. NORTH PAVILION: CIRCADIAN PATIENT SANCTUARY SUITE (0, 0, -8.5)
    const recoverySuiteGroup = new THREE.Group();
    recoverySuiteGroup.position.set(0, 0.25, -8.5);

    const suiteFloor = new THREE.Mesh(
      new THREE.BoxGeometry(6.4, 0.16, 5.4),
      warmTimberMat
    );
    recoverySuiteGroup.add(suiteFloor);

    // Ergonomic Smart Patient Bed
    const bedFrame = new THREE.Mesh(
      new THREE.BoxGeometry(1.7, 0.42, 2.5),
      warmTimberMat
    );
    bedFrame.position.set(0, 0.35, -0.3);
    recoverySuiteGroup.add(bedFrame);

    const mattress = new THREE.Mesh(
      new THREE.BoxGeometry(1.54, 0.24, 2.35),
      limestoneMat
    );
    mattress.position.set(0, 0.65, -0.3);
    recoverySuiteGroup.add(mattress);

    // Contactless Millimeter-Wave Vitals Arch over Headboard
    const vitalsArch = new THREE.Mesh(
      new THREE.TorusGeometry(1.35, 0.08, 16, 36, Math.PI),
      tealAccentMat
    );
    vitalsArch.position.set(0, 0.6, -1.45);
    recoverySuiteGroup.add(vitalsArch);
    interiorGroup.add(recoverySuiteGroup);

    // =========================================================================
    // EXTERIOR MULTI-WING HOSPITAL ARCHITECTURE (Lifts smoothly on cutaway!)
    // =========================================================================
    const exteriorShellGroup = new THREE.Group();
    scene.add(exteriorShellGroup);

    // Central Biophilic Dome Canopy
    const atriumRoofGroup = new THREE.Group();
    const domeRing = new THREE.Mesh(
      new THREE.TorusGeometry(5.6, 0.28, 16, 48),
      warmTimberMat
    );
    domeRing.rotation.x = Math.PI / 2;
    domeRing.position.y = 4.6;
    atriumRoofGroup.add(domeRing);

    const glassDome = new THREE.Mesh(
      new THREE.SphereGeometry(5.55, 36, 18, 0, Math.PI * 2, 0, Math.PI * 0.42),
      glassFacadeMat
    );
    glassDome.position.y = 2.6;
    glassDome.renderOrder = 2;
    atriumRoofGroup.add(glassDome);
    exteriorShellGroup.add(atriumRoofGroup);

    // Helper to build a multi-part hospital wing (Core + Glass Curtain + Timber Louvers + Roof Deck)
    const createWingShell = (
      x: number,
      z: number,
      width: number,
      height: number,
      depth: number,
      hasHelipad = false
    ) => {
      const wing = new THREE.Group();
      wing.position.set(x, 0, z);

      // Glass Curtain Envelope
      const glassEnvelope = new THREE.Mesh(
        new THREE.BoxGeometry(width, height, depth),
        glassFacadeMat
      );
      glassEnvelope.position.y = height / 2 + 0.25;
      glassEnvelope.renderOrder = 3;
      wing.add(glassEnvelope);

      // Horizontal Floor Slabs & Timber Louver Fins
      const floorsCount = 3;
      for (let f = 1; f <= floorsCount; f++) {
        const slabY = (f / floorsCount) * height + 0.25;
        const slab = new THREE.Mesh(
          new THREE.BoxGeometry(width + 0.35, 0.22, depth + 0.35),
          f === floorsCount ? limestoneMat : warmTimberMat
        );
        slab.position.y = slabY;
        slab.castShadow = true;
        slab.receiveShadow = true;
        wing.add(slab);
      }

      if (hasHelipad) {
        const helipadPad = new THREE.Mesh(
          new THREE.CylinderGeometry(2.4, 2.6, 0.25, 32),
          darkSlateMat
        );
        helipadPad.position.y = height + 0.5;
        wing.add(helipadPad);

        const helipadRing = new THREE.Mesh(
          new THREE.RingGeometry(1.75, 1.95, 32),
          amberBeaconMat
        );
        helipadRing.rotation.x = -Math.PI / 2;
        helipadRing.position.y = height + 0.64;
        wing.add(helipadRing);
      }

      return wing;
    };

    const westDiagnosticWing = createWingShell(-8.5, 0, 7.2, 5.2, 7.2, true);
    const eastRegenWing = createWingShell(8.5, 0, 7.2, 6.2, 7.2, false);
    const northSanctuaryWing = createWingShell(0, -8.5, 7.0, 4.6, 5.8, false);

    exteriorShellGroup.add(westDiagnosticWing);
    exteriorShellGroup.add(eastRegenWing);
    exteriorShellGroup.add(northSanctuaryWing);

    // Skybridges connecting wings
    const skybridgeWest = new THREE.Mesh(
      new THREE.BoxGeometry(4.2, 1.1, 1.8),
      glassFacadeMat
    );
    skybridgeWest.position.set(-4.2, 3.6, 0);
    exteriorShellGroup.add(skybridgeWest);

    const skybridgeEast = skybridgeWest.clone();
    skybridgeEast.position.set(4.2, 3.6, 0);
    exteriorShellGroup.add(skybridgeEast);

    // =========================================================================
    // INSTANCED PERIMETER TREES (Biophilic Campus Parkland)
    // =========================================================================
    const treeCount = 28;
    const treeCanopyInstanced = new THREE.InstancedMesh(
      new THREE.IcosahedronGeometry(1.1, 1),
      canopyMat,
      treeCount
    );
    const treeTrunkInstanced = new THREE.InstancedMesh(
      new THREE.CylinderGeometry(0.14, 0.22, 1.6, 8),
      warmTimberMat,
      treeCount
    );

    for (let i = 0; i < treeCount; i++) {
      const angle = (i / treeCount) * Math.PI * 2 + (i % 2) * 0.12;
      const radius = 16.5 + (i % 3) * 2.4;
      const tx = Math.cos(angle) * radius;
      const tz = Math.sin(angle) * radius;
      const scale = 0.82 + (i % 5) * 0.11;

      _tempPos.set(tx, 0.8 * scale, tz);
      _tempQuat.identity();
      _tempScale.set(scale, scale, scale);
      _tempMatrix.compose(_tempPos, _tempQuat, _tempScale);
      treeTrunkInstanced.setMatrixAt(i, _tempMatrix);

      _tempPos.set(tx, 2.1 * scale, tz);
      _tempMatrix.compose(_tempPos, _tempQuat, _tempScale);
      treeCanopyInstanced.setMatrixAt(i, _tempMatrix);

      _tempColor.setHSL(0.47 + (i % 4) * 0.015, 0.65, 0.26 + (i % 3) * 0.04);
      treeCanopyInstanced.setColorAt(i, _tempColor);
    }
    treeCanopyInstanced.computeBoundingSphere();
    treeTrunkInstanced.computeBoundingSphere();
    scene.add(treeTrunkInstanced);
    scene.add(treeCanopyInstanced);

    // =========================================================================
    // ANIMATED CLINICAL TELEMETRY & AIRFLOW PARTICLES (InstancedMesh)
    // =========================================================================
    const flowCount = 36;
    const flowInstanced = new THREE.InstancedMesh(
      new THREE.SphereGeometry(0.09, 10, 10),
      tealAccentMat,
      flowCount
    );
    flowInstanced.frustumCulled = false;
    scene.add(flowInstanced);

    // Pre-compile shaders once
    renderer.compile(scene, camera);

    const clock = new THREE.Clock();
    let animFrameId = 0;

    const animate = () => {
      animFrameId = requestAnimationFrame(animate);
      const delta = Math.min(clock.getDelta(), 0.1);
      const elapsed = clock.getElapsedTime();

      // 1. Smoothly damp cutaway / exploded floor height
      simRef.current.cutawayCurrent = THREE.MathUtils.damp(
        simRef.current.cutawayCurrent,
        simRef.current.cutawayTarget,
        5.5,
        delta
      );
      const cut = simRef.current.cutawayCurrent;

      // Lift exterior shell smoothly so interior clinical suites are 100% visible
      exteriorShellGroup.position.y = cut * 9.5;
      glassFacadeMat.opacity = THREE.MathUtils.lerp(0.38, 0.1, cut);

      // 2. Smoothly glide camera when user selects a zone preset
      if (!simRef.current.userInteracting) {
        _targetCamPos.copy(simRef.current.cameraPos);
        _targetLookAt.copy(simRef.current.cameraTarget);

        camera.position.x = THREE.MathUtils.damp(
          camera.position.x,
          _targetCamPos.x,
          3.8,
          delta
        );
        camera.position.y = THREE.MathUtils.damp(
          camera.position.y,
          _targetCamPos.y,
          3.8,
          delta
        );
        camera.position.z = THREE.MathUtils.damp(
          camera.position.z,
          _targetCamPos.z,
          3.8,
          delta
        );

        controls.target.x = THREE.MathUtils.damp(
          controls.target.x,
          _targetLookAt.x,
          4.2,
          delta
        );
        controls.target.y = THREE.MathUtils.damp(
          controls.target.y,
          _targetLookAt.y,
          4.2,
          delta
        );
        controls.target.z = THREE.MathUtils.damp(
          controls.target.z,
          _targetLookAt.z,
          4.2,
          delta
        );
      }

      // 3. Circadian Day / Night atmospheric interpolation
      const targetBg = simRef.current.circadianNight
        ? nightSkyColor
        : daySkyColor;
      if (scene.background instanceof THREE.Color) {
        scene.background.lerp(targetBg, delta * 3.0);
        if (scene.fog instanceof THREE.FogExp2) {
          scene.fog.color.copy(scene.background);
        }
      }
      keyLight.intensity = THREE.MathUtils.damp(
        keyLight.intensity,
        simRef.current.circadianNight ? 0.35 : 1.65,
        3.0,
        delta
      );
      atriumLight.intensity = THREE.MathUtils.damp(
        atriumLight.intensity,
        simRef.current.circadianNight ? 3.6 : 2.0,
        3.0,
        delta
      );

      // 4. Inside-the-Hospital 3D Medical Animations!
      // A. 7T MRI Patient Cradle smooth diagnostic glide + magnetic flux ring rotation
      mriCradle.position.z = 0.55 + Math.sin(elapsed * 0.9) * 0.65;
      fluxRing.rotation.z = elapsed * 1.4;
      robotArmLeft.rotation.y = Math.sin(elapsed * 0.7) * 0.35;
      robotArmRight.rotation.y = Math.PI - Math.sin(elapsed * 0.7) * 0.35;

      // B. GMP Cell Therapy Bioreactor Carousel gentle rotation
      bioreactorCarousel.rotation.y = elapsed * 0.35;

      // C. Atrium hydro-reflection gentle wave & corridor cellular flow particles
      waterMesh.position.y = 0.44 + Math.sin(elapsed * 1.8) * 0.025;

      for (let i = 0; i < flowCount; i++) {
        const t = (elapsed * 0.22 + i / flowCount) % 1;
        const angle = t * Math.PI * 2 * 2;
        const r = 3.5 + Math.sin(t * Math.PI * 4) * 5.2;
        _tempPos.set(
          Math.cos(angle) * r,
          1.1 + Math.sin(elapsed * 2 + i) * 0.35,
          Math.sin(angle) * r
        );
        _tempQuat.identity();
        _tempScale.setScalar(0.8 + Math.sin(elapsed * 3 + i) * 0.25);
        _tempMatrix.compose(_tempPos, _tempQuat, _tempScale);
        flowInstanced.setMatrixAt(i, _tempMatrix);
      }
      flowInstanced.instanceMatrix.needsUpdate = true;

      controls.update();
      renderer.render(scene, camera);
    };

    animate();

    const handleResize = () => {
      if (!container) return;
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animFrameId);
      window.removeEventListener('resize', handleResize);
      controls.removeEventListener('start', onControlStart);
      controls.dispose();
      envTexture.dispose();
      renderer.dispose();
    };
  }, []);

  const handleCopyBeacon = () => {
    if (typeof navigator !== 'undefined' && navigator.clipboard) {
      navigator.clipboard.writeText(
        `https://aetherion.Each/ar-handoff/${activeZone.arBeaconCode}`
      );
    }
    setArCopied(true);
    setTimeout(() => setArCopied(false), 2500);
  };

  return (
    <div
      className={`relative w-full overflow-hidden rounded-2xl border border-slate-200/90 bg-[#0F172A] ${
        compactMode ? 'h-[580px]' : 'h-[760px]'
      }`}
    >
      {/* Dedicated WebGL Canvas Mount Container (Zero sibling mutation) */}
      <div
        ref={canvasMountRef}
        className="w-full h-full cursor-grab active:cursor-grabbing"
        aria-label="Interactive 3D Digital Twin of Aetherion Nexus Hospital Campus and Interior Clinical Suites"
        role="img"
      />

      {/* Fallback if WebGL is unavailable */}
      {!webglReady && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-slate-900 text-white p-8 text-center">
          <Building2 className="w-12 h-12 text-[#0D9488] mb-3" />
          <h3 className="text-xl font-semibold mb-2">
            Aetherion Spatial Architecture Preview
          </h3>
          <p className="text-sm text-slate-300 max-w-md">
            Select any hospital wing or interior suite below to inspect real-time
            anonymized occupancy, air-filtration metrics, and AR wayfinding beacons.
          </p>
        </div>
      )}

      {/* Top-Left Minimal Spec Header Overlay (Solid/RGBA surface — no backdrop-filter over WebGL) */}
      <div className="absolute top-4 left-4 right-4 flex flex-wrap items-start justify-between gap-4 pointer-events-none z-10">
        <div className="pointer-events-auto bg-[#0F172A]/90 border border-slate-700/80 text-white rounded-xl px-4 py-3 max-w-md shadow-lg">
          <div className="flex items-center gap-2 text-xs text-teal-300 font-medium mb-1">
            <span>Living Digital Twin</span>
            <span aria-hidden="true">·</span>
            <span>{activeZone.floor}</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono tabular-nums">
              {activeZone.airChangesPerHour} ACH Clean Air
            </span>
          </div>
          <h3 className="text-base sm:text-lg font-semibold tracking-tight text-white">
            {activeZone.name}
          </h3>
          <p className="text-xs text-slate-300 mt-1 leading-relaxed">
            {calmMode ? activeZone.calmSummary : activeZone.standardSummary}
          </p>

          {/* Compact telemetry row */}
          <div className="mt-3 pt-2.5 border-t border-slate-800 flex flex-wrap items-center gap-4 text-xs">
            <div>
              <span className="text-slate-400">Occupancy: </span>
              <span className="font-mono tabular-nums font-semibold text-white">
                {activeZone.occupancyPct}%
              </span>
            </div>
            <div>
              <span className="text-slate-400">Est. Check-In: </span>
              <span className="font-mono tabular-nums font-semibold text-teal-300">
                {activeZone.waitMinutes === 0
                  ? 'Direct Entry'
                  : `${activeZone.waitMinutes} min`}
              </span>
            </div>
            <button
              type="button"
              onClick={() => setShowArModal(true)}
              className="ml-auto inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-[#0F766E] hover:bg-[#0D9488] text-white font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <QrCode className="w-3.5 h-3.5" />
              <span>AR Phone Handoff</span>
            </button>
          </div>
        </div>

        {/* Top-Right Quick Actions */}
        <div className="pointer-events-auto flex items-center gap-2">
          <button
            type="button"
            onClick={() => setCircadianNight((prev) => !prev)}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-[#0F172A]/90 border border-slate-700/80 text-xs font-medium text-slate-200 hover:text-white hover:border-teal-500 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            title="Toggle Circadian Day/Night Hospital Lighting"
          >
            {circadianNight ? (
              <>
                <Sun className="w-3.5 h-3.5 text-amber-400" />
                <span>Daylight Mode</span>
              </>
            ) : (
              <>
                <Moon className="w-3.5 h-3.5 text-teal-300" />
                <span>Circadian Night</span>
              </>
            )}
          </button>

          {compactMode && onExpandFullPage && (
            <button
              type="button"
              onClick={onExpandFullPage}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-[#0F766E] hover:bg-[#0D9488] text-xs font-semibold text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer shadow-md"
            >
              <Maximize2 className="w-3.5 h-3.5" />
              <span>Full 3D Interior Walkthrough</span>
            </button>
          )}
        </div>
      </div>

      {/* Unified Collapsible Bottom Control Dock (Zero Side-Panel Clutter) */}
      <div
        className="absolute bottom-4 left-1/2 -translate-x-1/2 z-10 w-[94vw] max-w-[920px] transition-transform duration-200"
        style={{
          transform: dockCollapsed
            ? 'translate(-50%, calc(100% - 34px))'
            : 'translate(-50%, 0)',
        }}
      >
        {/* Collapse / Expand Handle */}
        <div className="flex justify-center mb-1">
          <button
            type="button"
            onClick={() => setDockCollapsed((prev) => !prev)}
            className="inline-flex items-center gap-1.5 px-3 py-1 rounded-t-lg bg-[#0F172A]/95 border border-b-0 border-slate-700/80 text-[11px] font-medium text-slate-300 hover:text-white transition-colors cursor-pointer"
          >
            {dockCollapsed ? (
              <>
                <ChevronUp className="w-3.5 h-3.5 text-teal-400" />
                <span>Show 3D Controls (H)</span>
              </>
            ) : (
              <>
                <ChevronDown className="w-3.5 h-3.5 text-teal-400" />
                <span>Hide Controls · Zen View (H)</span>
              </>
            )}
          </button>
        </div>

        {/* Main Bottom Control Bar */}
        <div className="bg-[#0F172A]/95 border border-slate-700/90 rounded-xl p-3 text-white shadow-2xl">
          <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-3">
            {/* Room / Wing Camera Selector Tabs */}
            <div
              className="flex items-center gap-1 overflow-x-auto pb-1 lg:pb-0"
              role="tablist"
              aria-label="3D Hospital Zones and Interior Rooms"
            >
              {CAMPUS_ZONES.map((zone) => {
                const isSelected = zone.id === activeZoneId;
                return (
                  <button
                    key={zone.id}
                    type="button"
                    role="tab"
                    aria-selected={isSelected}
                    onClick={() => setActiveZoneId(zone.id)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                      isSelected
                        ? 'bg-[#0D9488] text-white shadow-sm'
                        : 'text-slate-300 hover:text-white hover:bg-slate-800/80'
                    }`}
                  >
                    {zone.shortName}
                  </button>
                );
              })}
            </div>

            {/* Architecture Cutaway Slider (Explode Exterior to see Inside the Hospital) */}
            <div className="flex items-center gap-3 pt-2 lg:pt-0 lg:pl-3 border-t lg:border-t-0 lg:border-l border-slate-800 shrink-0">
              <label
                htmlFor="cutaway-slider"
                className="flex items-center gap-1.5 text-xs text-slate-300 whitespace-nowrap shrink-0"
              >
                <Layers className="w-3.5 h-3.5 text-teal-400" />
                <span>Interior Cutaway</span>
              </label>
              <input
                id="cutaway-slider"
                type="range"
                min={0}
                max={1}
                step={0.02}
                value={cutawayLevel}
                onChange={(e) => setCutawayLevel(parseFloat(e.target.value))}
                className="w-28 sm:w-32 accent-[#0D9488] cursor-pointer"
              />
              <span className="text-xs font-mono tabular-nums text-teal-300 w-9 text-right">
                {Math.round(cutawayLevel * 100)}%
              </span>

              {onBookInZone && (
                <button
                  type="button"
                  onClick={() => onBookInZone(activeZone.name)}
                  className="ml-1 px-3 py-1.5 rounded-lg bg-[#F59E0B] hover:bg-amber-400 text-slate-950 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  Book in Suite
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* AR Smartphone Wayfinding Handoff Modal */}
      {showArModal && (
        <div
          className="absolute inset-0 z-20 bg-slate-950/85 flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="ar-handoff-title"
        >
          <div className="bg-white text-slate-900 rounded-2xl max-w-md w-full p-6 border border-slate-200 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2 text-xs font-medium text-[#0F766E]">
                <Navigation className="w-4 h-4" />
                <span>Zero-App AR Wayfinding Handoff</span>
              </div>
              <button
                type="button"
                onClick={() => setShowArModal(false)}
                className="text-xs font-medium text-slate-500 hover:text-slate-900 px-2 py-1 rounded cursor-pointer"
              >
                Close
              </button>
            </div>

            <h4
              id="ar-handoff-title"
              className="text-lg font-bold text-slate-900 mt-3"
            >
              {activeZone.name}
            </h4>
            <p className="text-sm text-slate-600 mt-1">
              Scan or copy your encrypted arrival pass. When you step out of{' '}
              <strong className="text-slate-800">{activeZone.parkingZone}</strong>,
              subtle teal floor arrows guide your phone camera directly to{' '}
              <strong className="text-slate-800">{activeZone.floor}</strong>.
            </p>

            {/* Procedural SVG Visual Beacon Pass */}
            <div className="my-4 p-4 rounded-xl bg-slate-50 border border-slate-200 flex items-center gap-4">
              <svg
                viewBox="0 0 80 80"
                className="w-20 h-20 shrink-0 rounded-lg bg-white p-1.5 border border-slate-200"
                aria-hidden="true"
              >
                <rect x="6" y="6" width="22" height="22" fill="#0F766E" rx="3" />
                <rect x="11" y="11" width="12" height="12" fill="#FFFFFF" rx="1" />
                <rect x="14" y="14" width="6" height="6" fill="#0F172A" />
                <rect x="52" y="6" width="22" height="22" fill="#0F766E" rx="3" />
                <rect x="57" y="11" width="12" height="12" fill="#FFFFFF" rx="1" />
                <rect x="60" y="14" width="6" height="6" fill="#0F172A" />
                <rect x="6" y="52" width="22" height="22" fill="#0F766E" rx="3" />
                <rect x="11" y="57" width="12" height="12" fill="#FFFFFF" rx="1" />
                <rect x="14" y="60" width="6" height="6" fill="#0F172A" />
                <rect x="34" y="12" width="6" height="6" fill="#0F172A" />
                <rect x="34" y="24" width="12" height="6" fill="#0D9488" />
                <rect x="12" y="34" width="16" height="6" fill="#0F172A" />
                <rect x="34" y="34" width="14" height="14" fill="#0F766E" rx="2" />
                <rect x="54" y="36" width="18" height="6" fill="#0F172A" />
                <rect x="36" y="54" width="8" height="18" fill="#0D9488" />
                <rect x="50" y="52" width="22" height="10" fill="#0F172A" />
                <rect x="56" y="66" width="16" height="8" fill="#0F766E" />
              </svg>
              <div className="text-xs space-y-1">
                <div className="text-slate-500">Spatial Anchor Token</div>
                <div className="font-mono font-semibold text-sm text-slate-900">
                  {activeZone.arBeaconCode}
                </div>
                <div className="text-slate-600">{activeZone.parkingZone}</div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={handleCopyBeacon}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#0F766E] hover:bg-[#0D9488] text-white text-xs font-semibold transition-colors cursor-pointer"
              >
                {arCopied ? (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    <span>AR Link Copied to Clipboard</span>
                  </>
                ) : (
                  <>
                    <QrCode className="w-4 h-4" />
                    <span>Copy AR Smartphone Pass</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
