'use client';

import React, {useState} from 'react';
import {
  Activity,
  Watch,
  CheckCircle2,
  Sliders,
  ShieldAlert,
  TrendingUp,
  Heart,
} from 'lucide-react';

interface PredictiveTrajectorySectionProps {
  calmMode?: boolean;
  onScheduleAssessment?: (goalTitle: string) => void;
}

interface TrajectoryPreset {
  id: 'cardio' | 'epigenetic' | 'neuro';
  label: string;
  metricName: string;
  unit: string;
  higherIsBetter: boolean;
  baselinePoints: number[];
  aetherionPoints: number[];
  milestones: {month: number; title: string; detail: string}[];
}

const TRAJECTORY_PRESETS: TrajectoryPreset[] = [
  {
    id: 'cardio',
    label: 'Cardiopulmonary & VO2 Max Remodeling',
    metricName: 'Peak VO2 Max & Myocardial Reserve',
    unit: 'mL/kg/min',
    higherIsBetter: true,
    baselinePoints: [31, 31.2, 31.0, 30.8, 30.9, 30.6, 30.5, 30.4, 30.2, 30.1, 30.0, 29.8],
    aetherionPoints: [31, 32.8, 34.9, 37.1, 39.0, 40.8, 42.1, 43.4, 44.5, 45.2, 46.0, 46.8],
    milestones: [
      {
        month: 1,
        title: '7T Perfusion Baseline & Zone-2 Prescription',
        detail: 'Microvascular reserve mapped; personalized mitochondrial training initiated.',
      },
      {
        month: 3,
        title: 'Autologous Exosome / Secretome Support',
        detail: 'Endothelial nitric oxide bioavailability increases +24%; resting HR drops 6 bpm.',
      },
      {
        month: 6,
        title: 'Mid-Point Cardiopulmonary Remodeling',
        detail: 'Ventricular stroke volume +14%; sustained aerobic threshold climbs.',
      },
      {
        month: 12,
        title: 'Biological Decade Reversal Target',
        detail: 'VO2 Max reaches top 5% age-decile bracket (+51% over baseline trajectory).',
      },
    ],
  },
  {
    id: 'epigenetic',
    label: 'Systemic Inflammation & Pace of Aging',
    metricName: 'High-Sensitivity CRP & DunedinPACE Score',
    unit: 'mg/L hs-CRP',
    higherIsBetter: false,
    baselinePoints: [3.2, 3.1, 3.3, 3.2, 3.4, 3.3, 3.5, 3.4, 3.6, 3.5, 3.6, 3.7],
    aetherionPoints: [3.2, 2.5, 1.9, 1.4, 1.1, 0.85, 0.72, 0.64, 0.58, 0.52, 0.48, 0.45],
    milestones: [
      {
        month: 1,
        title: 'Multi-Omic Methylation & Gut Microbiome Audit',
        detail: 'Identifies hidden silent inflammatory triggers and lipid oxidation pathways.',
      },
      {
        month: 3,
        title: 'Targeted Epigenetic & Nutritional Modulation',
        detail: 'hs-CRP drops below 1.5 mg/L; nocturnal heart-rate variability rises +18 ms.',
      },
      {
        month: 6,
        title: 'Senolytic & Autophagy Consolidation',
        detail: 'Biological pace of aging slows from 1.08x to 0.79x chronological years.',
      },
      {
        month: 12,
        title: 'Sustained Low-Inflammation Homeostasis',
        detail: '86% reduction in vascular inflammatory burden verified by liquid biopsy.',
      },
    ],
  },
  {
    id: 'neuro',
    label: 'Neuromuscular & Fine-Motor Recovery',
    metricName: 'Motor Unit Recruitment & Nerve Conduction',
    unit: '% Functional Index',
    higherIsBetter: true,
    baselinePoints: [42, 44, 46, 48, 49, 51, 52, 53, 53.5, 54, 54.2, 54.5],
    aetherionPoints: [42, 51, 62, 71, 78, 83, 87, 90, 92, 93.5, 94.8, 96],
    milestones: [
      {
        month: 1,
        title: 'High-Density EMG & Tractography Onboarding',
        detail: 'Maps surviving motor axons and calibrates soft robotic assistance gain.',
      },
      {
        month: 3,
        title: 'Schwann-Cell Trophic Gradient Peak',
        detail: 'Axonal sprouting crosses target gap at 1.8 mm/day with closed-loop feedback.',
      },
      {
        month: 6,
        title: 'Independent Fine-Motor Dexterity',
        detail: 'Two-point tactile discrimination and pinch endurance exceed 85% baseline.',
      },
      {
        month: 12,
        title: 'Full Cortical-Motor Integration',
        detail: '96% functional symmetry restored on standardized dexterity assessments.',
      },
    ],
  },
];

export default function PredictiveTrajectorySection({
  calmMode = false,
  onScheduleAssessment,
}: PredictiveTrajectorySectionProps) {
  const [presetId, setPresetId] = useState<'cardio' | 'epigenetic' | 'neuro'>(
    'cardio'
  );
  const [wearableSynced, setWearableSynced] = useState<boolean>(true);
  const [adherenceLevel, setAdherenceLevel] = useState<number>(85);
  const [selectedMonthIdx, setSelectedMonthIdx] = useState<number>(11);

  const activePreset =
    TRAJECTORY_PRESETS.find((p) => p.id === presetId) || TRAJECTORY_PRESETS[0];

  // Scale Aetherion projection slightly by user's selected adherence slider (70% - 100%)
  const adherenceFactor = adherenceLevel / 85;
  const computedPoints = activePreset.aetherionPoints.map((val, idx) => {
    if (idx === 0) return val;
    const delta = val - activePreset.baselinePoints[0];
    return Number((activePreset.baselinePoints[0] + delta * adherenceFactor).toFixed(2));
  });

  const allValues = [...activePreset.baselinePoints, ...computedPoints];
  const minVal = Math.min(...allValues) * 0.9;
  const maxVal = Math.max(...allValues) * 1.08;

  const width = 680;
  const height = 260;
  const padX = 44;
  const padY = 28;

  const getX = (idx: number) =>
    padX + (idx / 11) * (width - padX * 2);
  const getY = (val: number) =>
    height - padY - ((val - minVal) / (maxVal - minVal || 1)) * (height - padY * 2);

  const baselinePath = activePreset.baselinePoints
    .map((v, i) => `${i === 0 ? 'M' : 'L'} ${getX(i).toFixed(1)} ${getY(v).toFixed(1)}`)
    .join(' ');

  const aetherionPath = computedPoints
    .map((v, i) => `${i === 0 ? 'M' : 'L'} ${getX(i).toFixed(1)} ${getY(v).toFixed(1)}`)
    .join(' ');

  const areaPath = `${aetherionPath} L ${getX(11).toFixed(1)} ${(height - padY).toFixed(1)} L ${getX(0).toFixed(1)} ${(height - padY).toFixed(1)} Z`;

  const currentBaseline = activePreset.baselinePoints[selectedMonthIdx];
  const currentAetherion = computedPoints[selectedMonthIdx];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
      {/* Left 5 Columns: Onboarding & Personalization Controls */}
      <div className="lg:col-span-5 flex flex-col justify-between rounded-2xl border border-slate-200 bg-white p-6 sm:p-8">
        <div>
          <div className="flex items-center gap-2 text-xs font-medium text-[#0F766E]">
            <Activity className="w-4 h-4" />
            <span>Predictive Personal Health Trajectory</span>
          </div>
          <h3 className="text-2xl font-bold tracking-tight text-slate-900 mt-2">
            {calmMode
              ? 'See How Your Body Can Gently Strengthen Over 12 Months'
              : '12-Month Multi-Omic & Physiological Projection'}
          </h3>
          <p className="text-sm text-slate-600 mt-2 leading-relaxed">
            {calmMode
              ? 'Choose a health focus below to explore an encouraging, step-by-step picture of how personalized care supports your recovery.'
              : 'Modeled from 42,000+ anonymized Aetherion longitudinal cohorts. Adjust your focus pathway and protocol adherence to inspect projected biomarker shifts.'}
          </p>

          {/* Pathway Selector */}
          <div className="mt-6 space-y-2">
            <label className="block text-xs font-semibold text-slate-700">
              1. Select Primary Clinical Trajectory
            </label>
            <div className="space-y-2">
              {TRAJECTORY_PRESETS.map((preset) => {
                const active = preset.id === presetId;
                return (
                  <button
                    key={preset.id}
                    type="button"
                    onClick={() => setPresetId(preset.id)}
                    className={`w-full text-left px-4 py-3 rounded-xl border text-xs font-medium transition-colors flex items-center justify-between cursor-pointer ${
                      active
                        ? 'bg-[#0F766E]/8 border-[#0F766E] text-slate-900'
                        : 'bg-slate-50/70 border-slate-200 text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    <span className="font-semibold">{preset.label}</span>
                    <span className="font-mono text-[11px] text-[#0F766E]">
                      {preset.unit}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Wearable Telemetry Sync Toggle */}
          <div className="mt-5 pt-5 border-t border-slate-100">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Watch className="w-4 h-4 text-[#0F766E]" />
                <div>
                  <div className="text-xs font-semibold text-slate-900">
                    2. Continuous Wearable & HRV Calibration
                  </div>
                  <div className="text-[11px] text-slate-500">
                    Simulates Apple Health / Oura / Garmin nocturnal stream
                  </div>
                </div>
              </div>
              <button
                type="button"
                role="switch"
                aria-checked={wearableSynced}
                onClick={() => setWearableSynced((w) => !w)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                  wearableSynced
                    ? 'bg-[#0F766E] text-white'
                    : 'bg-slate-200 text-slate-700'
                }`}
              >
                {wearableSynced ? 'Synced · Live' : 'Connect Mock'}
              </button>
            </div>
          </div>

          {/* Protocol Consistency Slider */}
          <div className="mt-5 pt-5 border-t border-slate-100">
            <div className="flex items-center justify-between text-xs mb-2">
              <label
                htmlFor="adherence-slider"
                className="font-semibold text-slate-700 flex items-center gap-1.5"
              >
                <Sliders className="w-3.5 h-3.5 text-[#0F766E]" />
                <span>3. Weekly Protocol & Sleep Consistency</span>
              </label>
              <span className="font-mono tabular-nums font-semibold text-[#0F766E]">
                {adherenceLevel}%
              </span>
            </div>
            <input
              id="adherence-slider"
              type="range"
              min={65}
              max={100}
              step={5}
              value={adherenceLevel}
              onChange={(e) => setAdherenceLevel(Number(e.target.value))}
              className="w-full accent-[#0F766E] cursor-pointer"
            />
          </div>
        </div>

        {/* Educational & Privacy Framing Note */}
        <div className="mt-6 pt-4 border-t border-slate-100 flex items-start gap-2.5 text-[11px] text-slate-500 leading-relaxed">
          <ShieldAlert className="w-4 h-4 text-[#0F766E] shrink-0 mt-0.5" />
          <p>
            <strong>Educational Clinical Projection:</strong> Curves illustrate
            median anonymized outcomes across Aetherion cohorts and do not
            constitute a guaranteed medical prognosis. Computations run locally in
            your browser session.
          </p>
        </div>
      </div>

      {/* Right 7 Columns: Interactive 12-Month Trajectory Visualization & Milestones */}
      <div className="lg:col-span-7 flex flex-col justify-between rounded-2xl border border-slate-200 bg-white p-6 sm:p-8">
        <div>
          <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-100">
            <div>
              <div className="text-xs text-slate-500">
                Projected Biomarker Curve · {activePreset.metricName}
              </div>
              <h4 className="text-lg font-bold text-slate-900 mt-0.5">
                Month {selectedMonthIdx + 1} Comparison Readout
              </h4>
            </div>

            <div className="flex items-center gap-6 text-xs">
              <div>
                <span className="text-slate-500 block">Standard Care</span>
                <span className="font-mono tabular-nums font-semibold text-slate-700 text-base">
                  {currentBaseline} {activePreset.unit}
                </span>
              </div>
              <div>
                <span className="text-[#0F766E] font-medium block">
                  Aetherion Continuum
                </span>
                <span className="font-mono tabular-nums font-bold text-[#0F766E] text-base">
                  {currentAetherion} {activePreset.unit}
                </span>
              </div>
            </div>
          </div>

          {/* Interactive SVG Trajectory Graph */}
          <div className="mt-6 relative">
            <svg
              viewBox={`0 0 ${width} ${height}`}
              className="w-full h-auto overflow-visible"
              role="img"
              aria-label={`12-month health trajectory chart for ${activePreset.label}`}
            >
              <defs>
                <linearGradient id="aetherionAreaGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#0D9488" stopOpacity="0.24" />
                  <stop offset="100%" stopColor="#0D9488" stopOpacity="0.0" />
                </linearGradient>
              </defs>

              {/* Horizontal Reference Grid Lines */}
              {[0, 0.25, 0.5, 0.75, 1].map((step, i) => {
                const y = padY + step * (height - padY * 2);
                const val = (maxVal - step * (maxVal - minVal)).toFixed(1);
                return (
                  <g key={i}>
                    <line
                      x1={padX}
                      y1={y}
                      x2={width - padX}
                      y2={y}
                      stroke="#E2E8F0"
                      strokeDasharray={i === 4 ? undefined : '4 4'}
                      strokeWidth="1"
                    />
                    <text
                      x={padX - 8}
                      y={y + 4}
                      textAnchor="end"
                      className="fill-slate-400 text-[10px] font-mono"
                    >
                      {val}
                    </text>
                  </g>
                );
              })}

              {/* Shaded Confidence Area under Aetherion Curve */}
              <path d={areaPath} fill="url(#aetherionAreaGrad)" />

              {/* Standard Care Baseline Trajectory Line */}
              <path
                d={baselinePath}
                fill="none"
                stroke="#94A3B8"
                strokeWidth="2"
                strokeDasharray="5 5"
              />

              {/* Aetherion Regenerative Protocol Line */}
              <path
                d={aetherionPath}
                fill="none"
                stroke="#0F766E"
                strokeWidth="3"
                strokeLinecap="round"
              />

              {/* Interactive Month Nodes */}
              {computedPoints.map((val, idx) => {
                const cx = getX(idx);
                const cy = getY(val);
                const isSelected = idx === selectedMonthIdx;
                return (
                  <g
                    key={idx}
                    className="cursor-pointer"
                    onClick={() => setSelectedMonthIdx(idx)}
                  >
                    {isSelected && (
                      <line
                        x1={cx}
                        y1={padY}
                        x2={cx}
                        y2={height - padY}
                        stroke="#0D9488"
                        strokeWidth="1.5"
                        strokeDasharray="3 3"
                      />
                    )}
                    <circle
                      cx={cx}
                      cy={cy}
                      r={isSelected ? 6.5 : 4}
                      fill={isSelected ? '#F59E0B' : '#0F766E'}
                      stroke="#FFFFFF"
                      strokeWidth="2"
                    />
                    <text
                      x={cx}
                      y={height - 6}
                      textAnchor="middle"
                      className={`text-[10px] font-mono ${
                        isSelected
                          ? 'fill-slate-900 font-bold'
                          : 'fill-slate-400'
                      }`}
                    >
                      M{idx + 1}
                    </text>
                  </g>
                );
              })}
            </svg>
          </div>

          {/* 4 Key Clinical Milestones across the 12-Month Continuum */}
          <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 gap-3">
            {activePreset.milestones.map((ms) => {
              const isCurrent = selectedMonthIdx + 1 >= ms.month;
              return (
                <button
                  key={ms.month}
                  type="button"
                  onClick={() => setSelectedMonthIdx(ms.month - 1)}
                  className={`text-left p-3.5 rounded-xl border transition-colors cursor-pointer ${
                    isCurrent
                      ? 'bg-[#F8FAFC] border-teal-600/40'
                      : 'bg-white border-slate-200 opacity-75 hover:opacity-100'
                  }`}
                >
                  <div className="flex items-center justify-between text-xs font-mono text-[#0F766E]">
                    <span>Month {ms.month} Milestone</span>
                    <CheckCircle2 className="w-3.5 h-3.5" />
                  </div>
                  <div className="text-xs font-bold text-slate-900 mt-1">
                    {ms.title}
                  </div>
                  <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                    {ms.detail}
                  </p>
                </button>
              );
            })}
          </div>
        </div>

        <div className="mt-6 pt-4 border-t border-slate-100 flex flex-wrap items-center justify-between gap-4">
          <div className="text-xs text-slate-500">
            Click any month node (`M1`–`M12`) on the curve to inspect biomarker
            deltas.
          </div>
          {onScheduleAssessment && (
            <button
              type="button"
              onClick={() => onScheduleAssessment(activePreset.label)}
              className="px-4 py-2.5 rounded-lg bg-[#0F766E] hover:bg-[#0D9488] text-white text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Book Baseline Multi-Omic Assessment
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
