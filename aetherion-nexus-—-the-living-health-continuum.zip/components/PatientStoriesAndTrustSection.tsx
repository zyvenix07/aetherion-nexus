'use client';

import React from 'react';
import {PATIENT_STORIES, PatientStory} from '@/lib/aetherion-data';
import {Award, BookOpen, CheckCircle2, ShieldCheck, ArrowUpRight} from 'lucide-react';

interface PatientStoriesAndTrustSectionProps {
  calmMode?: boolean;
  onExplorePathway?: () => void;
}

function EditorialStoryArtwork({theme}: {theme: PatientStory['visualTheme']}) {
  if (theme === 'conservatory') {
    return (
      <svg
        viewBox="0 0 400 260"
        className="w-full h-48 object-cover rounded-xl border border-slate-200/80"
        role="img"
        aria-label="Warm editorial illustration of sunlit botanical glasshouse conservatory"
      >
        <defs>
          <linearGradient id="sunConservatory" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#FEF3C7" />
            <stop offset="55%" stopColor="#CCFBF1" />
            <stop offset="100%" stopColor="#0F766E" />
          </linearGradient>
        </defs>
        <rect width="400" height="260" fill="url(#sunConservatory)" />
        {/* Architectural Glasshouse Arches */}
        <path
          d="M 40 260 Q 200 20 360 260"
          fill="none"
          stroke="#0F766E"
          strokeWidth="2.5"
          strokeOpacity="0.4"
        />
        <path
          d="M 90 260 Q 200 65 310 260"
          fill="none"
          stroke="#0F766E"
          strokeWidth="2"
          strokeOpacity="0.4"
        />
        <line
          x1="200"
          y1="20"
          x2="200"
          y2="260"
          stroke="#0F766E"
          strokeWidth="1.5"
          strokeOpacity="0.3"
        />
        {/* Warm Sun & Botanical Silhouette */}
        <circle cx="115" cy="78" r="28" fill="#F59E0B" fillOpacity="0.35" />
        <circle cx="240" cy="165" r="55" fill="#0D9488" fillOpacity="0.3" />
        <circle cx="165" cy="180" r="44" fill="#115E59" fillOpacity="0.35" />
        {/* Walking figure silhouette in warm morning light */}
        <circle cx="200" cy="148" r="11" fill="#0F172A" />
        <path
          d="M 184 230 C 186 180 214 180 216 230 Z"
          fill="#0F172A"
        />
      </svg>
    );
  }

  if (theme === 'architect') {
    return (
      <svg
        viewBox="0 0 400 260"
        className="w-full h-48 object-cover rounded-xl border border-slate-200/80"
        role="img"
        aria-label="Warm editorial illustration of timber drafting studio with natural window light"
      >
        <defs>
          <linearGradient id="oakStudio" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#FDE68A" />
            <stop offset="50%" stopColor="#F1F5F9" />
            <stop offset="100%" stopColor="#0D9488" />
          </linearGradient>
        </defs>
        <rect width="400" height="260" fill="url(#oakStudio)" />
        {/* Tall Studio Window Shadows */}
        <rect
          x="45"
          y="25"
          width="95"
          height="155"
          fill="#FFFFFF"
          fillOpacity="0.65"
          rx="6"
        />
        <rect
          x="155"
          y="25"
          width="95"
          height="155"
          fill="#FFFFFF"
          fillOpacity="0.5"
          rx="6"
        />
        {/* Architectural Drafting Table & Structural Curves */}
        <polygon
          points="60,235 340,235 310,175 90,175"
          fill="#B45309"
          fillOpacity="0.35"
        />
        <path
          d="M 125 205 Q 200 140 275 205"
          fill="none"
          stroke="#0F766E"
          strokeWidth="3"
        />
        <circle cx="200" cy="172" r="6" fill="#0F172A" />
      </svg>
    );
  }

  return (
    <svg
      viewBox="0 0 400 260"
      className="w-full h-48 object-cover rounded-xl border border-slate-200/80"
      role="img"
      aria-label="Warm editorial illustration of sunlit stone terrace overlooking green hills"
    >
      <defs>
        <linearGradient id="terraceHills" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#FEF3C7" />
          <stop offset="60%" stopColor="#E0F2FE" />
          <stop offset="100%" stopColor="#0F766E" />
        </linearGradient>
      </defs>
      <rect width="400" height="260" fill="url(#terraceHills)" />
      <circle cx="300" cy="70" r="34" fill="#F59E0B" fillOpacity="0.35" />
      <path
        d="M 0 190 Q 120 135 250 185 T 400 165 L 400 260 L 0 260 Z"
        fill="#0D9488"
        fillOpacity="0.32"
      />
      <path
        d="M 0 215 Q 160 175 310 210 T 400 195 L 400 260 L 0 260 Z"
        fill="#0F766E"
        fillOpacity="0.55"
      />
      {/* Two figures sharing morning tea on terrace */}
      <circle cx="175" cy="162" r="10" fill="#0F172A" />
      <circle cx="220" cy="166" r="10" fill="#0F172A" />
      <rect x="165" y="176" width="20" height="38" rx="6" fill="#0F172A" />
      <rect x="210" y="180" width="20" height="34" rx="6" fill="#0F172A" />
    </svg>
  );
}

export default function PatientStoriesAndTrustSection({
  calmMode = false,
  onExplorePathway,
}: PatientStoriesAndTrustSectionProps) {
  return (
    <div className="space-y-20">
      {/* SECTION 8: AUTHENTIC PATIENT STORIES & OUTCOMES */}
      <div>
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
          <div>
            <div className="text-xs font-semibold text-[#0F766E]">
              08. Verified Patient Outcomes · Longitudinal Follow-Up
            </div>
            <h2 className="text-2xl sm:text-4xl font-bold tracking-tight text-slate-900 mt-1">
              {calmMode
                ? 'Real Stories of Quiet Recovery and Restored Strength'
                : 'Documented Restorative Outcomes Without Melodrama'}
            </h2>
          </div>
          {onExplorePathway && (
            <button
              type="button"
              onClick={onExplorePathway}
              className="text-xs font-semibold text-[#0F766E] hover:text-[#0D9488] inline-flex items-center gap-1 cursor-pointer"
            >
              <span>Inspect 3D Regenerative Pathways</span>
              <ArrowUpRight className="w-4 h-4" />
            </button>
          )}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {PATIENT_STORIES.map((story) => (
            <article
              key={story.id}
              className="rounded-2xl border border-slate-200 bg-white p-6 flex flex-col justify-between"
            >
              <div>
                <EditorialStoryArtwork theme={story.visualTheme} />

                {/* Clean Unboxed Metadata */}
                <div className="mt-4 flex flex-wrap items-center gap-1.5 text-xs text-slate-500">
                  <span className="font-semibold text-slate-900">
                    {story.patientName}, {story.age}
                  </span>
                  <span aria-hidden="true">·</span>
                  <span>{story.profession}</span>
                  <span aria-hidden="true">·</span>
                  <span>{story.location}</span>
                </div>

                <div className="mt-2 font-mono tabular-nums text-xs font-bold text-[#0F766E]">
                  {story.quantifiedMetric}
                </div>

                <blockquote className="mt-3 text-sm text-slate-700 leading-relaxed">
                  “{story.quote}”
                </blockquote>

                {/* Concrete Before / Change / Outcome Breakdown */}
                <div className="mt-4 pt-4 border-t border-slate-100 space-y-2 text-xs text-slate-600">
                  <div>
                    <strong className="text-slate-900">Baseline: </strong>
                    {story.beforeState}
                  </div>
                  <div>
                    <strong className="text-slate-900">Protocol: </strong>
                    {story.changeIntervention}
                  </div>
                  <div>
                    <strong className="text-slate-900">12-Mo Outcome: </strong>
                    {story.afterOutcome}
                  </div>
                </div>
              </div>

              <div className="mt-5 pt-3 border-t border-slate-100 text-[11px] text-slate-500 flex items-center justify-between">
                <span>Attending: {story.attendingPhysician}</span>
              </div>
            </article>
          ))}
        </div>
      </div>

      {/* SECTION 9: TRUST, ACCREDITATIONS & CLINICAL NUMBERS */}
      <div className="rounded-2xl border border-slate-200 bg-white p-6 sm:p-10">
        <div className="max-w-3xl">
          <div className="text-xs font-semibold text-[#0F766E]">
            09. Clinical Governance, Accreditations & Published Evidence
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 mt-1">
            Audited Outcomes & Institutional Transparency
          </h2>
          <p className="text-sm text-slate-600 mt-2 leading-relaxed">
            Every regenerative protocol and diagnostic pathway at Aetherion Nexus
            undergoes independent IRB oversight, real-time morbidity auditing,
            and peer-reviewed publication.
          </p>
        </div>

        {/* 4 Quantified Institutional Metrics */}
        <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 pt-6 border-t border-slate-100">
          <div>
            <div className="font-mono tabular-nums text-3xl font-bold text-slate-900">
              99.4%
            </div>
            <div className="text-xs font-semibold text-[#0F766E] mt-1">
              30-Day Surgical & Cellular Safety Rate
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Across 14,800+ minimally invasive robotic & autologous procedures
              (2024–2026 audit).
            </p>
          </div>

          <div>
            <div className="font-mono tabular-nums text-3xl font-bold text-slate-900">
              18 min
            </div>
            <div className="text-xs font-semibold text-[#0F766E] mt-1">
              Median Specialist Swarm Consensus
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Time from diagnostic upload to multi-specialist treatment plan vs.
              41 days national average.
            </p>
          </div>

          <div>
            <div className="font-mono tabular-nums text-3xl font-bold text-slate-900">
              312
            </div>
            <div className="text-xs font-semibold text-[#0F766E] mt-1">
              Active Phase II/III Regenerative Trials
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Published in NEJM, Nature Medicine, Lancet, and Circulation with
              open anonymized datasets.
            </p>
          </div>

          <div>
            <div className="font-mono tabular-nums text-3xl font-bold text-slate-900">
              4.94 / 5
            </div>
            <div className="text-xs font-semibold text-[#0F766E] mt-1">
              HCAHPS Patient Quietness & Clarity Score
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Top 0.5% nationally for nocturnal acoustic peace, nurse response
              speed, and billing transparency.
            </p>
          </div>
        </div>

        {/* Accreditations Row */}
        <div className="mt-8 pt-6 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs text-slate-700">
          <div className="flex items-start gap-2.5">
            <ShieldCheck className="w-4 h-4 text-[#0F766E] shrink-0 mt-0.5" />
            <div>
              <div className="font-bold text-slate-900">
                Joint Commission Gold Seal
              </div>
              <div className="text-slate-500">
                Comprehensive Academic & Regenerative Medical Center
              </div>
            </div>
          </div>

          <div className="flex items-start gap-2.5">
            <Award className="w-4 h-4 text-[#0F766E] shrink-0 mt-0.5" />
            <div>
              <div className="font-bold text-slate-900">
                FACT Cellular Therapy Accredited
              </div>
              <div className="text-slate-500">
                Foundation for the Accreditation of Cellular Therapy (ISO Class 5)
              </div>
            </div>
          </div>

          <div className="flex items-start gap-2.5">
            <BookOpen className="w-4 h-4 text-[#0F766E] shrink-0 mt-0.5" />
            <div>
              <div className="font-bold text-slate-900">
                Magnet® Recognition Program
              </div>
              <div className="text-slate-500">
                ANCC Distinction for Nursing Excellence & Patient Autonomy
              </div>
            </div>
          </div>

          <div className="flex items-start gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-[#0F766E] shrink-0 mt-0.5" />
            <div>
              <div className="font-bold text-slate-900">
                WCAG 2.2 AA+ & HIPAA Sovereign
              </div>
              <div className="text-slate-500">
                Zero-Knowledge Patient Custody & Universal Accessibility
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
