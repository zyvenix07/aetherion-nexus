'use client';

import React, {useEffect, useState} from 'react';
import {motion, AnimatePresence} from 'motion/react';
import {ArrowRight, ShieldCheck} from 'lucide-react';

interface EntryAnimationOverlayProps {
  onComplete: () => void;
}

export default function EntryAnimationOverlay({
  onComplete,
}: EntryAnimationOverlayProps) {
  const [visible, setVisible] = useState<boolean>(true);
  const [phase, setPhase] = useState<number>(0);

  useEffect(() => {
    // Respect prefers-reduced-motion immediately
    if (
      typeof window !== 'undefined' &&
      window.matchMedia('(prefers-reduced-motion: reduce)').matches
    ) {
      setVisible(false);
      onComplete();
      return;
    }

    const t1 = setTimeout(() => setPhase(1), 450);
    const t2 = setTimeout(() => setPhase(2), 1150);
    const t3 = setTimeout(() => {
      setVisible(false);
      onComplete();
    }, 2100);

    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
    };
  }, [onComplete]);

  const handleSkip = () => {
    setVisible(false);
    onComplete();
  };

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{opacity: 1}}
          exit={{opacity: 0, scale: 1.02}}
          transition={{duration: 0.45, ease: [0.16, 1, 0.3, 1]}}
          className="fixed inset-0 z-50 bg-[#0F172A] text-white flex flex-col items-center justify-between p-8 select-none"
          role="dialog"
          aria-label="Aetherion Nexus Entry Sequence"
        >
          {/* Top Bar inside Entry Screen */}
          <div className="w-full max-w-6xl flex items-center justify-between text-xs text-slate-400">
            <span>Aetherion Nexus · Integrated Regenerative Health System</span>
            <button
              type="button"
              onClick={handleSkip}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-700 text-slate-200 hover:text-white hover:border-teal-400 transition-colors cursor-pointer"
            >
              <span>Enter Continuum Immediately</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Center Geometric Regenerative Convergence */}
          <div className="flex flex-col items-center text-center max-w-xl my-auto">
            <div className="relative w-36 h-36 mb-8 flex items-center justify-center">
              <motion.svg
                viewBox="0 0 160 160"
                className="w-full h-full"
                initial={{rotate: -25, scale: 0.85, opacity: 0}}
                animate={{rotate: 0, scale: 1, opacity: 1}}
                transition={{duration: 1.1, ease: [0.16, 1, 0.3, 1]}}
              >
                <circle
                  cx="80"
                  cy="80"
                  r="68"
                  fill="none"
                  stroke="#1E293B"
                  strokeWidth="1.5"
                />
                <motion.circle
                  cx="80"
                  cy="80"
                  r="68"
                  fill="none"
                  stroke="#0D9488"
                  strokeWidth="2.5"
                  strokeDasharray="427"
                  initial={{strokeDashoffset: 427}}
                  animate={{strokeDashoffset: 0}}
                  transition={{duration: 1.4, ease: 'easeInOut'}}
                />
                <motion.ellipse
                  cx="80"
                  cy="80"
                  rx="54"
                  ry="24"
                  fill="none"
                  stroke="#2DD4BF"
                  strokeWidth="1.5"
                  initial={{rotate: 0, opacity: 0.2}}
                  animate={{rotate: 60, opacity: 0.85}}
                  transition={{duration: 1.5, ease: 'easeOut'}}
                  style={{transformOrigin: '80px 80px'}}
                />
                <motion.ellipse
                  cx="80"
                  cy="80"
                  rx="54"
                  ry="24"
                  fill="none"
                  stroke="#F59E0B"
                  strokeWidth="1.5"
                  initial={{rotate: 0, opacity: 0.2}}
                  animate={{rotate: -60, opacity: 0.75}}
                  transition={{duration: 1.5, ease: 'easeOut'}}
                  style={{transformOrigin: '80px 80px'}}
                />
                <circle cx="80" cy="80" r="8" fill="#0D9488" />
                <circle cx="80" cy="80" r="3.5" fill="#F8FAFC" />
              </motion.svg>
            </div>

            <motion.div
              initial={{opacity: 0, y: 12}}
              animate={{opacity: 1, y: 0}}
              transition={{duration: 0.5, delay: 0.15}}
              className="text-xs font-medium text-teal-300 tracking-wide mb-2"
            >
              The Living Health Continuum
            </motion.div>

            <motion.h1
              initial={{opacity: 0, y: 14}}
              animate={{opacity: 1, y: 0}}
              transition={{duration: 0.6, delay: 0.25}}
              className="text-3xl sm:text-5xl font-bold tracking-tight text-white"
            >
              Aetherion Nexus
            </motion.h1>

            <motion.p
              initial={{opacity: 0}}
              animate={{opacity: 1}}
              transition={{duration: 0.6, delay: 0.45}}
              className="text-sm sm:text-base text-slate-300 mt-3 max-w-md leading-relaxed"
            >
              {phase === 0 &&
                'Initializing 3D Digital Twin Campus & Interior Clinical Suites...'}
              {phase === 1 &&
                'Calibrating Specialist Swarm & Regenerative Tissue Models...'}
              {phase >= 2 &&
                'Clinical Sanctuary Ready · WCAG 2.2 AA+ Verified'}
            </motion.p>
          </div>

          {/* Bottom Trust & Privacy Note */}
          <div className="w-full max-w-6xl flex flex-wrap items-center justify-between gap-4 text-xs text-slate-400 border-t border-slate-800/80 pt-4">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-teal-400" />
              <span>
                Zero-Knowledge Sovereign Health Record Layer · HIPAA & ISO 27001
              </span>
            </div>
            <div className="font-mono tabular-nums text-teal-300">
              {phase === 0 ? '34%' : phase === 1 ? '78%' : '100%'}
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
