'use client';

import React, {useState} from 'react';
import {SOVEREIGN_RECORDS, SovereignRecordItem} from '@/lib/aetherion-data';
import {
  KeyRound,
  ShieldCheck,
  Clock,
  Lock,
  Copy,
  CheckCircle2,
  RefreshCw,
  FileText,
  Trash2,
} from 'lucide-react';

interface SovereignHealthRecordSectionProps {
  calmMode?: boolean;
}

export default function SovereignHealthRecordSection({
  calmMode = false,
}: SovereignHealthRecordSectionProps) {
  const [selectedIds, setSelectedIds] = useState<string[]>(
    SOVEREIGN_RECORDS.filter((r) => r.defaultSelected).map((r) => r.id)
  );
  const [expiryWindow, setExpiryWindow] = useState<'15m' | '24h' | '7d'>('24h');
  const [recipientLabel, setRecipientLabel] = useState<string>(
    'External Second-Opinion Specialist'
  );
  const [activeToken, setActiveToken] = useState<{
    tokenString: string;
    createdAt: string;
    expiresLabel: string;
    scopeCount: number;
    recipient: string;
  } | null>({
    tokenString: 'aeth_zkp_94F2C81E0B73D19A',
    createdAt: 'Generated 4 mins ago',
    expiresLabel: 'Valid for 24 Hours (Read-Only)',
    scopeCount: 3,
    recipient: 'Stanford Cardiology External Review',
  });
  const [copied, setCopied] = useState<boolean>(false);

  const toggleRecord = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleGenerateToken = () => {
    if (selectedIds.length === 0) return;
    const randomHex = Array.from({length: 16}, () =>
      Math.floor(Math.random() * 16)
        .toString(16)
        .toUpperCase()
    ).join('');
    const labels = {
      '15m': 'Valid for 15 Minutes (Emergency / Instant Handoff)',
      '24h': 'Valid for 24 Hours (Read-Only Consultation)',
      '7d': 'Valid for 7 Days (Multi-Center Case Review)',
    };
    setActiveToken({
      tokenString: `aeth_zkp_${randomHex}`,
      createdAt: 'Just now · Zero-Knowledge Proof Verified',
      expiresLabel: labels[expiryWindow],
      scopeCount: selectedIds.length,
      recipient: recipientLabel.trim() || 'Authorized Clinical Recipient',
    });
    setCopied(false);
  };

  const handleCopyToken = () => {
    if (!activeToken) return;
    if (typeof navigator !== 'undefined' && navigator.clipboard) {
      navigator.clipboard.writeText(
        `https://aetherion.Each/vault/${activeToken.tokenString}`
      );
    }
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
      {/* Left 7 Columns: Record Scope Selection & Custody Vault */}
      <div className="lg:col-span-7 rounded-2xl border border-slate-200 bg-white p-6 sm:p-8 flex flex-col justify-between">
        <div>
          <div className="flex items-center gap-2 text-xs font-medium text-[#0F766E]">
            <KeyRound className="w-4 h-4" />
            <span>Sovereign Health Record Layer · Patient-Held Custody</span>
          </div>
          <h3 className="text-2xl font-bold tracking-tight text-slate-900 mt-2">
            {calmMode
              ? 'You Hold the Only Key to Your Medical Records'
              : 'One-Click Zero-Knowledge Record Sharing via Time-Limited Tokens'}
          </h3>
          <p className="text-sm text-slate-600 mt-2 leading-relaxed">
            {calmMode
              ? 'Share only the exact scan or lab result you choose with an outside doctor or family member, and turn off access whenever you wish.'
              : 'No fax machines, CD-ROMs, or permanent third-party data brokers. Select specific diagnostic bundles below to mint an ephemeral, cryptographically verifiable read-only key.'}
          </p>

          {/* Selectable Clinical Record Bundles */}
          <div className="mt-6 space-y-3">
            {SOVEREIGN_RECORDS.map((rec: SovereignRecordItem) => {
              const checked = selectedIds.includes(rec.id);
              return (
                <div
                  key={rec.id}
                  onClick={() => toggleRecord(rec.id)}
                  role="checkbox"
                  aria-checked={checked}
                  tabIndex={0}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault();
                      toggleRecord(rec.id);
                    }
                  }}
                  className={`p-4 rounded-xl border transition-colors cursor-pointer ${
                    checked
                      ? 'bg-[#0F766E]/6 border-[#0F766E]'
                      : 'bg-slate-50/70 border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-3">
                      <input
                        type="checkbox"
                        checked={checked}
                        onChange={() => {}}
                        className="mt-1 accent-[#0F766E] w-4 h-4 cursor-pointer"
                        aria-label={rec.title}
                      />
                      <div>
                        <div className="text-sm font-bold text-slate-900">
                          {rec.title}
                        </div>
                        <div className="flex flex-wrap items-center gap-1.5 text-[11px] text-slate-500 mt-0.5">
                          <span>{rec.category}</span>
                          <span aria-hidden="true">·</span>
                          <span>{rec.dateRecorded}</span>
                          <span aria-hidden="true">·</span>
                          <span className="font-mono">{rec.fileSize}</span>
                          <span aria-hidden="true">·</span>
                          <span className="font-mono text-[#0F766E]">
                            SHA-3: {rec.hashPreview}
                          </span>
                        </div>
                        <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                          {rec.clinicalSummary}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
          <span>
            Selected Bundles:{' '}
            <strong className="font-mono text-slate-900">
              {selectedIds.length} of {SOVEREIGN_RECORDS.length}
            </strong>
          </span>
          <span>Hardware Enclave Status: FIPS 140-3 Verified</span>
        </div>
      </div>

      {/* Right 5 Columns: Interactive Sovereign Key Minting & Revocation Panel */}
      <div className="lg:col-span-5 rounded-2xl border border-slate-200 bg-[#0F172A] text-white p-6 sm:p-8 flex flex-col justify-between">
        <div>
          <div className="flex items-center justify-between text-xs text-teal-300 font-medium">
            <span>Patient Cryptographic Custody Vault</span>
            <Lock className="w-4 h-4" />
          </div>

          <h4 className="text-xl font-bold tracking-tight mt-2">
            Configure Ephemeral Share Key
          </h4>

          {/* Recipient Input */}
          <div className="mt-5">
            <label
              htmlFor="recipient-name-input"
              className="block text-xs text-slate-300 mb-1.5"
            >
              Authorized Recipient or Institution Label
            </label>
            <input
              id="recipient-name-input"
              type="text"
              value={recipientLabel}
              onChange={(e) => setRecipientLabel(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-teal-400"
              placeholder="e.g., Family Caregiver or Visiting Physician"
            />
          </div>

          {/* Time-Limited Token Duration */}
          <div className="mt-4">
            <label className="block text-xs text-slate-300 mb-1.5">
              Auto-Destruct Expiration Window
            </label>
            <div className="grid grid-cols-3 gap-2">
              {(
                [
                  {id: '15m', label: '15 Minutes'},
                  {id: '24h', label: '24 Hours'},
                  {id: '7d', label: '7 Days'},
                ] as const
              ).map((opt) => (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => setExpiryWindow(opt.id)}
                  className={`py-2 px-3 rounded-lg text-xs font-semibold border transition-colors cursor-pointer ${
                    expiryWindow === opt.id
                      ? 'bg-[#0D9488] border-teal-400 text-white'
                      : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          <button
            type="button"
            onClick={handleGenerateToken}
            disabled={selectedIds.length === 0}
            className="mt-5 w-full py-3 px-4 rounded-xl bg-[#F59E0B] hover:bg-amber-400 disabled:opacity-40 text-slate-950 font-semibold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer"
          >
            <RefreshCw className="w-4 h-4" />
            <span>
              Mint Time-Limited Sovereign Key ({selectedIds.length} Records)
            </span>
          </button>

          {/* Active Token Display Card */}
          {activeToken ? (
            <div className="mt-6 p-4 rounded-xl bg-slate-900/90 border border-teal-500/40 space-y-3">
              <div className="flex items-center justify-between text-xs">
                <span className="text-teal-300 font-medium">
                  Active Ephemeral Token
                </span>
                <span className="text-slate-400">{activeToken.createdAt}</span>
              </div>

              <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 font-mono text-xs text-teal-200 break-all">
                {activeToken.tokenString}
              </div>

              <div className="text-xs text-slate-300 space-y-1">
                <div>
                  <span className="text-slate-400">Recipient: </span>
                  <span className="font-medium text-white">
                    {activeToken.recipient}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400">Window: </span>
                  <span>{activeToken.expiresLabel}</span>
                </div>
                <div>
                  <span className="text-slate-400">Records Unlocked: </span>
                  <span className="font-mono">{activeToken.scopeCount}</span>
                </div>
              </div>

              <div className="pt-2 flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleCopyToken}
                  className="flex-1 py-2 px-3 rounded-lg bg-[#0F766E] hover:bg-[#0D9488] text-white text-xs font-semibold inline-flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  {copied ? (
                    <>
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Copied Encrypted Link</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy Share Link</span>
                    </>
                  )}
                </button>
                <button
                  type="button"
                  onClick={() => setActiveToken(null)}
                  className="py-2 px-3 rounded-lg border border-rose-500/40 text-rose-300 hover:bg-rose-950/50 text-xs font-medium inline-flex items-center gap-1 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Revoke</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="mt-6 p-5 rounded-xl bg-slate-900/60 border border-slate-800 text-center text-xs text-slate-400">
              All external share tokens have been revoked. Zero external parties
              currently have access to your Sovereign Health Record Layer.
            </div>
          )}
        </div>

        <div className="mt-6 pt-4 border-t border-slate-800 flex items-center gap-2 text-[11px] text-slate-400">
          <ShieldCheck className="w-4 h-4 text-teal-400 shrink-0" />
          <span>
            Audited zero-knowledge architecture: Aetherion servers cannot
            decrypt your records without your active session signature.
          </span>
        </div>
      </div>
    </div>
  );
}
