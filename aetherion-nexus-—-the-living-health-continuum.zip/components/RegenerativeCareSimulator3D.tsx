'use client';

import React, {useEffect, useRef, useState} from 'react';
import * as THREE from 'three';
import {OrbitControls} from 'three/addons/controls/OrbitControls.js';
import {RoomEnvironment} from 'three/addons/environments/RoomEnvironment.js';
import {
  REGENERATIVE_PATHWAYS,
  RegenerativePathway,
} from '@/lib/aetherion-data';
import {
  Dna,
  HeartPulse,
  Network,
  Play,
  Pause,
  RotateCcw,
  ArrowRight,
} from 'lucide-react';

// Pre-allocated math helpers at module scope (zero GC in render loop)
const _mat4 = new THREE.Matrix4();
const _pos = new THREE.Vector3();
const _quat = new THREE.Quaternion();
const _scale = new THREE.Vector3();
const _euler = new THREE.Euler();

interface RegenerativeCareSimulator3DProps {
  calmMode?: boolean;
  onConsultPathway?: (pathwayTitle: string) => void;
}

export default function RegenerativeCareSimulator3D({
  calmMode = false,
  onConsultPathway,
}: RegenerativeCareSimulator3DProps) {
  const canvasMountRef = useRef<HTMLDivElement | null>(null);

  const [selectedPathwayId, setSelectedPathwayId] = useState<
    'ipsc-cardiac' | 'crispr-epigenetic' | 'vascular-conduit'
  >('ipsc-cardiac');
  const [stageIndex, setStageIndex] = useState<number>(1);
  const [isPlaying, setIsPlaying] = useState<boolean>(true);

  const activePathway: RegenerativePathway =
    REGENERATIVE_PATHWAYS.find((p) => p.id === selectedPathwayId) ||
    REGENERATIVE_PATHWAYS[0];

  const simStateRef = useRef({
    pathwayId: 'ipsc-cardiac' as
      | 'ipsc-cardiac'
      | 'crispr-epigenetic'
      | 'vascular-conduit',
    stageIndex: 1,
    isPlaying: true,
  });

  useEffect(() => {
    simStateRef.current.pathwayId = selectedPathwayId;
  }, [selectedPathwayId]);

  useEffect(() => {
    simStateRef.current.stageIndex = stageIndex;
  }, [stageIndex]);

  useEffect(() => {
    simStateRef.current.isPlaying = isPlaying;
  }, [isPlaying]);

  useEffect(() => {
    const container = canvasMountRef.current;
    if (!container) return;

    let renderer: THREE.WebGLRenderer;
    try {
      const isHeadless =
        typeof navigator !== 'undefined' &&
        (navigator.webdriver || /HeadlessChrome/i.test(navigator.userAgent));

      renderer = new THREE.WebGLRenderer({
        antialias: !isHeadless,
        powerPreference: 'high-performance',
      });
      renderer.outputColorSpace = THREE.SRGBColorSpace;
      renderer.toneMapping = THREE.ACESFilmicToneMapping;
      renderer.toneMappingExposure = 1.12;
      renderer.setPixelRatio(
        isHeadless ? 1 : Math.min(window.devicePixelRatio, 2)
      );
      renderer.setSize(container.clientWidth, container.clientHeight);
      container.innerHTML = '';
      container.appendChild(renderer.domElement);
    } catch {
      return;
    }

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0c1926);
    scene.fog = new THREE.FogExp2(0x0c1926, 0.035);

    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    const envTex = pmremGenerator.fromScene(
      new RoomEnvironment(),
      0.04
    ).texture;
    scene.environment = envTex;
    pmremGenerator.dispose();

    const camera = new THREE.PerspectiveCamera(
      40,
      container.clientWidth / container.clientHeight,
      0.1,
      100
    );
    camera.position.set(0, 3.2, 11.5);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.minDistance = 5;
    controls.maxDistance = 20;

    // 3-Point Biophysical Studio Lighting
    const hemiLight = new THREE.HemisphereLight(0xccfbf1, 0x0f172a, 0.9);
    scene.add(hemiLight);

    const keyLight = new THREE.DirectionalLight(0xfffbeb, 1.8);
    keyLight.position.set(8, 12, 10);
    scene.add(keyLight);

    const rimLight = new THREE.DirectionalLight(0x14b8a6, 1.4);
    rimLight.position.set(-10, -6, -8);
    scene.add(rimLight);

    // PBR Bio-Materials
    const tealCellMat = new THREE.MeshPhysicalMaterial({
      color: 0x14b8a6,
      roughness: 0.18,
      metalness: 0.1,
      transmission: 0.55,
      thickness: 1.2,
      clearcoat: 0.8,
    });
    const nucleusMat = new THREE.MeshStandardMaterial({
      color: 0xf59e0b,
      roughness: 0.3,
      metalness: 0.2,
      emissive: 0xd97706,
      emissiveIntensity: 0.35,
    });
    const scaffoldMat = new THREE.MeshPhysicalMaterial({
      color: 0x99f6e4,
      roughness: 0.25,
      metalness: 0.15,
      transparent: true,
      opacity: 0.45,
    });
    const helixStrandMat = new THREE.MeshPhysicalMaterial({
      color: 0x38bdf8,
      roughness: 0.2,
      metalness: 0.3,
      clearcoat: 0.6,
    });

    // =========================================================================
    // MODEL 1: AUTOLOGOUS iPSC MYOCARDIAL MATRIX (25 Instanced Cardiomyocytes)
    // =========================================================================
    const cardiacGroup = new THREE.Group();
    const cellCount = 25;
    const cellOuterInst = new THREE.InstancedMesh(
      new THREE.SphereGeometry(0.48, 24, 24),
      tealCellMat,
      cellCount
    );
    const cellNucleiInst = new THREE.InstancedMesh(
      new THREE.SphereGeometry(0.18, 16, 16),
      nucleusMat,
      cellCount
    );
    cellOuterInst.frustumCulled = false;
    cellNucleiInst.frustumCulled = false;
    cardiacGroup.add(cellOuterInst);
    cardiacGroup.add(cellNucleiInst);

    // Collagen-fibrin lattice ring
    const latticeTorus = new THREE.Mesh(
      new THREE.TorusGeometry(3.4, 0.08, 16, 64),
      scaffoldMat
    );
    latticeTorus.rotation.x = Math.PI / 2;
    cardiacGroup.add(latticeTorus);
    scene.add(cardiacGroup);

    // =========================================================================
    // MODEL 2: CRISPR-CAS13 EPIGENETIC HELIX & RNP COMPLEX
    // =========================================================================
    const crisprGroup = new THREE.Group();
    const rungCount = 28;
    const strandAInst = new THREE.InstancedMesh(
      new THREE.SphereGeometry(0.22, 16, 16),
      helixStrandMat,
      rungCount
    );
    const strandBInst = new THREE.InstancedMesh(
      new THREE.SphereGeometry(0.22, 16, 16),
      tealCellMat,
      rungCount
    );
    const baseRungInst = new THREE.InstancedMesh(
      new THREE.CylinderGeometry(0.055, 0.055, 2.2, 10),
      scaffoldMat,
      rungCount
    );
    strandAInst.frustumCulled = false;
    strandBInst.frustumCulled = false;
    baseRungInst.frustumCulled = false;
    crisprGroup.add(strandAInst);
    crisprGroup.add(strandBInst);
    crisprGroup.add(baseRungInst);

    // Cas13 Ribonucleoprotein Docking Envelope
    const cas13Envelope = new THREE.Mesh(
      new THREE.TorusKnotGeometry(1.15, 0.34, 64, 16, 2, 3),
      new THREE.MeshPhysicalMaterial({
        color: 0xf59e0b,
        roughness: 0.15,
        metalness: 0.1,
        transmission: 0.68,
        transparent: true,
        opacity: 0.82,
      })
    );
    crisprGroup.add(cas13Envelope);
    scene.add(crisprGroup);

    // =========================================================================
    // MODEL 3: BIO-PRINTED NEURO-VASCULAR MULTI-LUMEN CONDUIT
    // =========================================================================
    const conduitGroup = new THREE.Group();
    const outerSheath = new THREE.Mesh(
      new THREE.CylinderGeometry(1.65, 1.65, 6.8, 36, 1, true),
      scaffoldMat
    );
    outerSheath.rotation.z = Math.PI / 2;
    conduitGroup.add(outerSheath);

    // 4 Internal Guidance Micro-Channels
    const channelOffsets: [number, number][] = [
      [0.65, 0.65],
      [-0.65, 0.65],
      [0.65, -0.65],
      [-0.65, -0.65],
    ];
    channelOffsets.forEach(([cy, cz]) => {
      const lumen = new THREE.Mesh(
        new THREE.CylinderGeometry(0.36, 0.36, 6.6, 20, 1, true),
        tealCellMat
      );
      lumen.rotation.z = Math.PI / 2;
      lumen.position.set(0, cy, cz);
      conduitGroup.add(lumen);
    });

    // Migrating Axonal Signal Pulses (32 Instanced Spheres)
    const axonCount = 32;
    const axonPulseInst = new THREE.InstancedMesh(
      new THREE.SphereGeometry(0.16, 14, 14),
      nucleusMat,
      axonCount
    );
    axonPulseInst.frustumCulled = false;
    conduitGroup.add(axonPulseInst);
    scene.add(conduitGroup);

    renderer.compile(scene, camera);

    const clock = new THREE.Clock();
    let frameId = 0;
    let simTime = 0;

    const animate = () => {
      frameId = requestAnimationFrame(animate);
      const dt = Math.min(clock.getDelta(), 0.1);
      if (simStateRef.current.isPlaying) {
        simTime += dt * (0.85 + simStateRef.current.stageIndex * 0.25);
      }

      const activeId = simStateRef.current.pathwayId;
      const stg = simStateRef.current.stageIndex;

      cardiacGroup.visible = activeId === 'ipsc-cardiac';
      crisprGroup.visible = activeId === 'crispr-epigenetic';
      conduitGroup.visible = activeId === 'vascular-conduit';

      if (activeId === 'ipsc-cardiac') {
        // Animate 5x5 synchronous beating cardiomyocyte matrix
        for (let i = 0; i < cellCount; i++) {
          const row = Math.floor(i / 5) - 2;
          const col = (i % 5) - 2;
          const dist = Math.sqrt(row * row + col * col);
          // Synchronous contractile wave increases with clinical stage
          const wave =
            Math.sin(simTime * 2.6 - dist * 0.8) * (0.12 + stg * 0.08);
          const spacing = THREE.MathUtils.lerp(1.45, 1.08, stg / 3);

          _pos.set(col * spacing, wave, row * spacing);
          _quat.identity();
          const pulseScale = 0.85 + (stg + 1) * 0.06 + wave * 0.35;
          _scale.set(pulseScale, pulseScale * 0.82, pulseScale);
          _mat4.compose(_pos, _quat, _scale);
          cellOuterInst.setMatrixAt(i, _mat4);

          _scale.setScalar(0.9 + wave * 0.2);
          _mat4.compose(_pos, _quat, _scale);
          cellNucleiInst.setMatrixAt(i, _mat4);
        }
        cellOuterInst.instanceMatrix.needsUpdate = true;
        cellNucleiInst.instanceMatrix.needsUpdate = true;
        cardiacGroup.rotation.y = simTime * 0.18;
      } else if (activeId === 'crispr-epigenetic') {
        // Animate 3D Double Helix + Cas13 docking
        for (let i = 0; i < rungCount; i++) {
          const t = i / (rungCount - 1) - 0.5;
          const x = t * 7.6;
          const angle = t * Math.PI * 4 + simTime * 0.9;
          const radius = 1.1;

          const yA = Math.cos(angle) * radius;
          const zA = Math.sin(angle) * radius;

          _pos.set(x, yA, zA);
          _quat.identity();
          _scale.setScalar(1);
          _mat4.compose(_pos, _quat, _scale);
          strandAInst.setMatrixAt(i, _mat4);

          _pos.set(x, -yA, -zA);
          _mat4.compose(_pos, _quat, _scale);
          strandBInst.setMatrixAt(i, _mat4);

          _pos.set(x, 0, 0);
          _euler.set(angle + Math.PI / 2, 0, 0);
          _quat.setFromEuler(_euler);
          _mat4.compose(_pos, _quat, _scale);
          baseRungInst.setMatrixAt(i, _mat4);
        }
        strandAInst.instanceMatrix.needsUpdate = true;
        strandBInst.instanceMatrix.needsUpdate = true;
        baseRungInst.instanceMatrix.needsUpdate = true;

        cas13Envelope.position.x = Math.sin(simTime * 0.7) * 1.4;
        cas13Envelope.rotation.x = simTime * 0.6;
        cas13Envelope.rotation.y = simTime * 0.4;
        cas13Envelope.scale.setScalar(0.65 + stg * 0.12);
      } else if (activeId === 'vascular-conduit') {
        // Animate Neuro-Vascular Conduit axonal growth cones gliding across lumens
        for (let i = 0; i < axonCount; i++) {
          const ch = channelOffsets[i % 4];
          const progress = ((simTime * 0.35 + i / axonCount) % 1) - 0.5;
          const span = 6.2 * ((stg + 1) / 4);
          _pos.set(
            progress * span,
            ch[0] + Math.sin(simTime * 3 + i) * 0.08,
            ch[1] + Math.cos(simTime * 3 + i) * 0.08
          );
          _quat.identity();
          _scale.setScalar(0.85 + Math.sin(simTime * 4 + i) * 0.25);
          _mat4.compose(_pos, _quat, _scale);
          axonPulseInst.setMatrixAt(i, _mat4);
        }
        axonPulseInst.instanceMatrix.needsUpdate = true;
        conduitGroup.rotation.y = Math.sin(simTime * 0.25) * 0.35;
      }

      controls.update();
      renderer.render(scene, camera);
    };

    animate();

    const handleResize = () => {
      if (!container) return;
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(frameId);
      window.removeEventListener('resize', handleResize);
      controls.dispose();
      envTex.dispose();
      renderer.dispose();
    };
  }, []);

  const currentStage =
    activePathway.stages[stageIndex] || activePathway.stages[0];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
      {/* Left 7 Columns: Interactive 3D Molecular & Tissue Viewport */}
      <div className="lg:col-span-7 flex flex-col justify-between rounded-2xl overflow-hidden border border-slate-200 bg-[#0C1926] min-h-[500px] relative">
        <div
          ref={canvasMountRef}
          className="w-full h-[420px] sm:h-[480px] cursor-grab active:cursor-grabbing"
          aria-label={`3D Molecular Visualization for ${activePathway.title}`}
          role="img"
        />

        {/* Top-Left Clinical Telemetry Overlay */}
        <div className="absolute top-4 left-4 right-4 flex flex-wrap items-center justify-between gap-2 pointer-events-none">
          <div className="pointer-events-auto bg-slate-950/90 border border-slate-800 rounded-xl px-3.5 py-2.5 text-white max-w-md">
            <div className="flex items-center gap-2 text-xs text-teal-300 font-medium">
              <span>Stage {currentStage.phaseNumber} of 04</span>
              <span aria-hidden="true">·</span>
              <span className="font-mono tabular-nums">
                {currentStage.duration}
              </span>
            </div>
            <div className="text-sm font-semibold text-white mt-0.5">
              {currentStage.title}
            </div>
            <div className="text-xs text-slate-300 mt-0.5">
              {currentStage.molecularBehavior}
            </div>
          </div>

          <div className="pointer-events-auto flex items-center gap-1.5 bg-slate-950/90 border border-slate-800 rounded-lg p-1">
            <button
              type="button"
              onClick={() => setIsPlaying((p) => !p)}
              className="px-2.5 py-1.5 rounded text-xs font-medium text-slate-200 hover:text-white hover:bg-slate-800 flex items-center gap-1 cursor-pointer"
            >
              {isPlaying ? (
                <>
                  <Pause className="w-3.5 h-3.5 text-teal-400" />
                  <span>Pause</span>
                </>
              ) : (
                <>
                  <Play className="w-3.5 h-3.5 text-teal-400" />
                  <span>Play</span>
                </>
              )}
            </button>
            <button
              type="button"
              onClick={() => setStageIndex(0)}
              className="px-2 py-1.5 rounded text-xs text-slate-300 hover:text-white hover:bg-slate-800 cursor-pointer"
              title="Reset to Stage 01"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Bottom Dock inside 3D Simulator: Pathway Selector + 4-Stage Scrubber */}
        <div className="bg-slate-950 border-t border-slate-800 p-4 text-white">
          <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
            <span className="text-xs font-medium text-slate-400">
              Select Clinical Pathway (Drag 3D model to inspect):
            </span>
            <div className="flex flex-wrap items-center gap-1.5">
              <button
                type="button"
                onClick={() => {
                  setSelectedPathwayId('ipsc-cardiac');
                  setStageIndex(1);
                }}
                className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  selectedPathwayId === 'ipsc-cardiac'
                    ? 'bg-[#0D9488] text-white'
                    : 'bg-slate-900 text-slate-300 hover:text-white'
                }`}
              >
                <HeartPulse className="w-3.5 h-3.5" />
                <span>iPSC Cardiac Matrix</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setSelectedPathwayId('crispr-epigenetic');
                  setStageIndex(1);
                }}
                className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  selectedPathwayId === 'crispr-epigenetic'
                    ? 'bg-[#0D9488] text-white'
                    : 'bg-slate-900 text-slate-300 hover:text-white'
                }`}
              >
                <Dna className="w-3.5 h-3.5" />
                <span>CRISPR-Cas13 Tuning</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setSelectedPathwayId('vascular-conduit');
                  setStageIndex(1);
                }}
                className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  selectedPathwayId === 'vascular-conduit'
                    ? 'bg-[#0D9488] text-white'
                    : 'bg-slate-900 text-slate-300 hover:text-white'
                }`}
              >
                <Network className="w-3.5 h-3.5" />
                <span>Neuro-Vascular Bridge</span>
              </button>
            </div>
          </div>

          {/* 4-Stage Timeline Buttons */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {activePathway.stages.map((stg, idx) => {
              const active = idx === stageIndex;
              return (
                <button
                  key={stg.phaseNumber}
                  type="button"
                  onClick={() => setStageIndex(idx)}
                  className={`text-left p-2.5 rounded-lg border transition-colors cursor-pointer ${
                    active
                      ? 'bg-teal-950/80 border-teal-500 text-white'
                      : 'bg-slate-900/70 border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <div className="text-[11px] font-mono text-teal-400">
                    Phase {stg.phaseNumber} · {stg.duration}
                  </div>
                  <div className="text-xs font-semibold truncate mt-0.5">
                    {stg.title}
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Right 5 Columns: Clinical Details & Plain-Language Explainer */}
      <div className="lg:col-span-5 flex flex-col justify-between rounded-2xl border border-slate-200 bg-white p-6 sm:p-8">
        <div>
          <div className="flex items-center gap-2 text-xs text-[#0F766E] font-medium">
            <span>{activePathway.subtitle}</span>
          </div>

          <h3 className="text-2xl font-bold tracking-tight text-slate-900 mt-2">
            {activePathway.title}
          </h3>

          {/* Plain-Language Patient Summary (6th-8th grade accessible reading level) */}
          <div className="mt-4 p-4 rounded-xl bg-[#F8FAFC] border border-slate-200/80">
            <div className="text-xs font-semibold text-slate-700 mb-1">
              {calmMode
                ? 'Gentle Plain-Language Summary'
                : 'In Plain Language (Patient & Family Guide)'}
            </div>
            <p className="text-sm text-slate-700 leading-relaxed">
              {activePathway.plainLanguageSummary}
            </p>
          </div>

          {/* Active Stage Clinical Breakdown */}
          <div className="mt-6">
            <div className="flex items-center justify-between text-xs text-slate-500 pb-2 border-b border-slate-100">
              <span>
                Active Phase {currentStage.phaseNumber}: {currentStage.title}
              </span>
              <span className="font-mono tabular-nums text-[#0F766E] font-medium">
                {currentStage.duration}
              </span>
            </div>
            <p className="text-sm text-slate-600 leading-relaxed mt-3">
              {currentStage.explanation}
            </p>
          </div>

          {/* Clinical Outcome & Timeline Metrics */}
          <div className="mt-6 pt-5 border-t border-slate-100 space-y-3 text-xs">
            <div>
              <span className="text-slate-500 block">Primary Indication</span>
              <span className="font-semibold text-slate-900 text-sm">
                {activePathway.clinicalIndication}
              </span>
            </div>
            <div>
              <span className="text-slate-500 block">
                Published Clinical Trial Outcome
              </span>
              <span className="font-mono tabular-nums font-semibold text-[#0F766E] text-sm">
                {activePathway.trialOutcomeMetric}
              </span>
            </div>
            <div>
              <span className="text-slate-500 block">Expected Recovery Arc</span>
              <span className="text-slate-800 font-medium">
                {activePathway.recoveryTimeline}
              </span>
            </div>
          </div>
        </div>

        <div className="mt-8 pt-4 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3">
          <button
            type="button"
            onClick={() => setStageIndex((prev) => (prev + 1) % 4)}
            className="text-xs font-semibold text-[#0F766E] hover:text-[#0D9488] inline-flex items-center gap-1 cursor-pointer"
          >
            <span>Next Biological Phase</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>

          {onConsultPathway && (
            <button
              type="button"
              onClick={() => onConsultPathway(activePathway.title)}
              className="px-4 py-2.5 rounded-lg bg-[#0F766E] hover:bg-[#0D9488] text-white text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Request Pathway Eligibility Review
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
